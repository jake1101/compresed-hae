package com.customer.entity;

import javax.persistence.*;
import java.util.Date;
import lombok.Data;

/**
 * ServerJwt 엔티티 클래스
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@Entity
@Data
@Table(name="svr_jwt")
public class ServerJwt {

	/** 서버 아이피 주소 */
    @Id
    @Column(name="svr_ip")
    private String svrIp;

	/** 담당자 이름  */
    @Column(name="mng_nm")
    private String mngNm;

	/** 담당자 핸드폰 번호 */
    @Column(name="mng_phn")
    private String mngPhn;

	/** 담당자 이메일 */
    @Column(name="mng_eml")
    private String mngEml;

	/** 서버 AccessJWT  */
    @Column(name="acc_jwt")
    private String accJwt;

	/** accJwt 만료기간  */
    @Column(name="exp_dt")
    private Date expDt;

	/** 생성날짜시간  */
    @Column(name="iss_dt")
    private Date issDt;

	/** 삭제여부 */
    @Column(name="del_yn")
    private char delYn;
}
