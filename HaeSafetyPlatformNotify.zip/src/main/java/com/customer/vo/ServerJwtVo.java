package com.customer.vo;

import lombok.Data;

/**
 * 서버용 Access JWT 발급요청 VO
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class ServerJwtVo {
	
	/** 서버 이름 */
	private String serverName;
	
	/** 서버 아이피 주소 */
	private String serverIp;
	
	/** 담당자 이름 */
	private String mgrName;
	
	/** 담당자 핸드폰 번호 */
	private String mgrPhoneNo;
	
	/** 담당자 이메일 주소 */
	private String mgrEmail;
}
