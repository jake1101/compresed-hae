package com.customer.vo;

import lombok.Data;

/**
 *  이메일 상황전파 요청 VO
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class NotifyRequestVo {
	
	/** 전파 종류 */
	private String type;
	
	/** 전파 내용 */
	private String message;
	
	/** 수신자 */
	private String dest;
	
	/** 전파 범위 */
	private String scope;
}
