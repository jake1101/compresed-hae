package com.customer.util;

import org.springframework.stereotype.Service;
import com.customer.dto.ResultDto;

/**
 *  DTO 생성 헬퍼 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
    "PMD.UseObjectForClearerAPI",
    "PMD.AtLeastOneConstructor",
    "PMD.AvoidCatchingGenericException",
    "PMD.AvoidDuplicateLiterals",
    "PMD.AvoidUncheckedExceptionsInSignatures",
    "PMD.BeanMembersShouldSerialize",
    "PMD.CommentDefaultAccessModifier",
    "PMD.CommentRequired",
    "PMD.CommentSize",
    "PMD.DataflowAnomalyAnalysis",
    "PMD.DefaultPackage",
    "PMD.ExcessiveImports",
    "PMD.ExcessiveMethodLength",
    "PMD.ImmutableField",
    "PMD.LawOfDemeter",
    "PMD.LocalVariableCouldBeFinal",
    "PMD.LongVariable",
    "PMD.ModifiedCyclomaticComplexity",
    "PMD.NcssCount",
    "PMD.NonThreadSafeSingleton",
    "PMD.NPathComplexity",
    "PMD.OnlyOneReturn",
    "PMD.ReturnEmptyArrayRatherThanNull",
    "PMD.ReturnEmptyCollectionRatherThanNull",
    "PMD.ShortVariable",
    "PMD.SignatureDeclareThrowsException",
    "PMD.UnnecessaryLocalBeforeReturn",
    "PMD.UnusedAssignment",
    "PMD.UnusedPrivateField",
    "PMD.UnusedPrivateMethod",
    "PMD.UseDiamondOperator",
    "PMD.UseShortArrayInitializer",
    "PMD.UseUtilityClass"	
})
@Service
public class DtoBuilder {
    
	/**
	 * 전파 요청 응답 DTO 생성
	 * 
	 * @author : david
	 * @param final String result, final String message
	 * @return NotifyDto
	 * @Date : 2022. 02. 24
	 * @Method Name : buildReissueDto
	 */
	public ResultDto buildReissueDto(final String result, final String message, final ResultDto.Payload payload) {
		
		final ResultDto resultDto = new ResultDto();
		resultDto.setResult(result);
		resultDto.setMessage(message);
		resultDto.setData(payload);
		
		return resultDto;
	}
}
