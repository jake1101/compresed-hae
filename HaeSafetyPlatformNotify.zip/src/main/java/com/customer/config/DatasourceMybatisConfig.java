package com.customer.config;

import javax.sql.DataSource;

//import com.customer.domain.enums.YesNoType;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.TypeHandler;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;



/**
 * DatasourceMybatisConfig
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
    "PMD.GuardLogStatement",
    "PMD.AtLeastOneConstructor",
    "PMD.AvoidCatchingGenericException",
    "PMD.AvoidDuplicateLiterals",
    "PMD.AvoidUncheckedExceptionsInSignatures",
    "PMD.BeanMembersShouldSerialize",
    "PMD.CommentDefaultAccessModifier",
    "PMD.CommentRequired",
    "PMD.CommentSize",
    "PMD.DataflowAnomalyAnalysis",
    "PMD.DefaultPackage",
    "PMD.ExcessiveImports",
    "PMD.ExcessiveMethodLength",
    "PMD.ImmutableField",
    "PMD.LawOfDemeter",
    "PMD.LocalVariableCouldBeFinal",
    "PMD.LongVariable",
    "PMD.ModifiedCyclomaticComplexity",
    "PMD.NcssCount",
    "PMD.NonThreadSafeSingleton",
    "PMD.NPathComplexity",
    "PMD.OnlyOneReturn",
    "PMD.ReturnEmptyArrayRatherThanNull",
    "PMD.ReturnEmptyCollectionRatherThanNull",
    "PMD.ShortVariable",
    "PMD.SignatureDeclareThrowsException",
    "PMD.UnnecessaryLocalBeforeReturn",
    "PMD.UnusedAssignment",
    "PMD.UnusedPrivateField",
    "PMD.UnusedPrivateMethod",
    "PMD.UseDiamondOperator",
    "PMD.UseShortArrayInitializer",
    "PMD.UseUtilityClass"	
})
@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = { "com.customer.mapper" }, sqlSessionFactoryRef = "db2SqlSessionFactory")
public class DatasourceMybatisConfig {


	/**
	 * DataSource 및 Mapper 초기화
	 * 
	 * @author : david
	 * @param : DataSource, ApplicationContext
	 * @return SqlSessionFactory
	 * @Date : 2022. 02. 24
	 * @Method Name : db2SqlSessionFactory
	 */
	@Bean(name = "db2SqlSessionFactory")
	public SqlSessionFactory db2SqlSessionFactory(@Qualifier("dataSource") final DataSource db2DataSource,
			final ApplicationContext applicationContext) throws Exception {
		final SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(db2DataSource);
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/*.xml"));
		sqlSessionFactoryBean.setTypeHandlers(new TypeHandler[] { new org.apache.ibatis.type.LocalDateTypeHandler(),

		});
		return sqlSessionFactoryBean.getObject();
	}


	/**
	 * db2SqlSessionFactory 로부터 SqlSessionTemplate 생성 반환
	 * 
	 * @author : david
	 * @param : SqlSessionFactory
	 * @return SqlSessionTemplate
	 * @Date : 2022. 02. 24
	 * @Method Name : db2SqlSessionTemplate
	 */
	@Bean(name = "db2SqlSessionTemplate")
	public SqlSessionTemplate db2SqlSessionTemplate(final SqlSessionFactory db2SqlSessionFactory) {
		return new SqlSessionTemplate(db2SqlSessionFactory);
	}
}