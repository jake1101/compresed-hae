package com.customer.config;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.customer.job.NotifyEmailJob;
 

/**
 *  이메일만 페치하여 발송 요청하는 Quartz 설정
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
    "PMD.GuardLogStatement",
    "PMD.AtLeastOneConstructor",
    "PMD.AvoidCatchingGenericException",
    "PMD.AvoidDuplicateLiterals",
    "PMD.AvoidUncheckedExceptionsInSignatures",
    "PMD.BeanMembersShouldSerialize",
    "PMD.CommentDefaultAccessModifier",
    "PMD.CommentRequired",
    "PMD.CommentSize",
    "PMD.DataflowAnomalyAnalysis",
    "PMD.DefaultPackage",
    "PMD.ExcessiveImports",
    "PMD.ExcessiveMethodLength",
    "PMD.ImmutableField",
    "PMD.LawOfDemeter",
    "PMD.LocalVariableCouldBeFinal",
    "PMD.LongVariable",
    "PMD.ModifiedCyclomaticComplexity",
    "PMD.NcssCount",
    "PMD.NonThreadSafeSingleton",
    "PMD.NPathComplexity",
    "PMD.OnlyOneReturn",
    "PMD.ReturnEmptyArrayRatherThanNull",
    "PMD.ReturnEmptyCollectionRatherThanNull",
    "PMD.ShortVariable",
    "PMD.SignatureDeclareThrowsException",
    "PMD.UnnecessaryLocalBeforeReturn",
    "PMD.UnusedAssignment",
    "PMD.UnusedPrivateField",
    "PMD.UnusedPrivateMethod",
    "PMD.UseDiamondOperator",
    "PMD.UseShortArrayInitializer",
    "PMD.UseUtilityClass"	
})

@Configuration
public class NotifyEmailConfig
{
	/** 페치 주기 */
    @Value("${notify.cron.email}")
    private transient String cronTime;
    
	/**
	 * JobDetail 획득
	 * 
	 * @author : david
	 * @param 
	 * @return JobDetail
	 * @Date : 2022. 02. 24
	 * @Method Name : scheduleJobDetail
	 */
	@Bean
	public JobDetail scheduleJobDetail()
	{
		final JobDataMap jobMap = new JobDataMap();
		// Put some...
		
		return JobBuilder
				.newJob(NotifyEmailJob.class).withIdentity("scheduleJobEmail").usingJobData(jobMap).storeDurably()
				.build();
	}
	
	/**
	 * Trigger 획득
	 * 
	 * @author : david
	 * @param 
	 * @return JobDetail
	 * @Date : 2022. 02. 24
	 * @Method Name : scheduleEmailJobTrigger
	 */
	@Bean
	public Trigger scheduleEmailJobTrigger()
	{
		final CronScheduleBuilder cronBuilder = CronScheduleBuilder.cronSchedule(cronTime);
		
		return TriggerBuilder
				.newTrigger().forJob(scheduleJobDetail()).withIdentity("scheduleTriggerEmail").withSchedule(cronBuilder)
				.build();
	}
}