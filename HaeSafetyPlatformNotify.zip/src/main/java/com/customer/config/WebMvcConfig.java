package com.customer.config;

import org.springframework.boot.web.servlet.view.MustacheViewResolver;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


/**
 * WebMvcConfig 초기화
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
    "PMD.GuardLogStatement",
    "PMD.AtLeastOneConstructor",
    "PMD.AvoidCatchingGenericException",
    "PMD.AvoidDuplicateLiterals",
    "PMD.AvoidUncheckedExceptionsInSignatures",
    "PMD.BeanMembersShouldSerialize",
    "PMD.CommentDefaultAccessModifier",
    "PMD.CommentRequired",
    "PMD.CommentSize",
    "PMD.DataflowAnomalyAnalysis",
    "PMD.DefaultPackage",
    "PMD.ExcessiveImports",
    "PMD.ExcessiveMethodLength",
    "PMD.ImmutableField",
    "PMD.LawOfDemeter",
    "PMD.LocalVariableCouldBeFinal",
    "PMD.LongVariable",
    "PMD.ModifiedCyclomaticComplexity",
    "PMD.NcssCount",
    "PMD.NonThreadSafeSingleton",
    "PMD.NPathComplexity",
    "PMD.OnlyOneReturn",
    "PMD.ReturnEmptyArrayRatherThanNull",
    "PMD.ReturnEmptyCollectionRatherThanNull",
    "PMD.ShortVariable",
    "PMD.SignatureDeclareThrowsException",
    "PMD.UnnecessaryLocalBeforeReturn",
    "PMD.UnusedAssignment",
    "PMD.UnusedPrivateField",
    "PMD.UnusedPrivateMethod",
    "PMD.UseDiamondOperator",
    "PMD.UseShortArrayInitializer",
    "PMD.UseUtilityClass"	
})
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

	/**
	 * 디폴트 resolver  설정
	 * 
	 * @author : david
	 * @param
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : configureViewResolvers
	 */
	@Override
	public void configureViewResolvers(final ViewResolverRegistry registry) {
		final MustacheViewResolver resolver = new MustacheViewResolver();

		resolver.setCharset("UTF-8");
		resolver.setContentType("text/html;charset=UTF-8");
		resolver.setPrefix("classpath:/templates/");
		resolver.setSuffix(".html");

		registry.viewResolver(resolver);
	}
	

	/* 테스트 
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
	
		registry.addResourceHandler("/index.html").addResourceLocations("classpath:/static/index.html");
		registry.addResourceHandler("/manifest.json").addResourceLocations("classpath:/static/manifest.json");
		registry.addResourceHandler("/static/**").addResourceLocations("classpath:/static/static/");
		registry.addResourceHandler("/media/**").addResourceLocations("classpath:/static/media/");
		registry.addResourceHandler("/assets/**").addResourceLocations("classpath:/static/assets/");
		registry.addResourceHandler("/assets/icon/**").addResourceLocations("classpath:/static/assets/icon/");
		registry.addResourceHandler("/assets/others/**").addResourceLocations("classpath:/static/assets/others/");
	} */
}

