package com.customer.config.jwt;

/**
 *  JwtProperties
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
public class JwtProperties {
	/** 우리 서버만 알고 있는 비밀값 */
	public final static String SECRET = "Secret$#Key"; 

	/** Access JWT 만료시간 = 2시간 */
	public final static int ACS_EXP_TIME = 7_200_000;
	
	/** Refresh JWT 만료시간 = 10일  */
	public final static int REF_EXP_TIME = 864_000_000;
}
