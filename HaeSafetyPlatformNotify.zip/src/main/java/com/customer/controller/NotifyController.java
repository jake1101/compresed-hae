package com.customer.controller;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.customer.config.jwt.JwtProperties;
import com.customer.dto.ResultDto;
import com.customer.entity.NotifyHost;
import com.customer.entity.ServerJwt;
import com.customer.repository.NotifyRepository;
import com.customer.repository.ServerJwtRepository;
import com.customer.util.DtoBuilder;
import com.customer.vo.NotifyRequestVo;
import com.customer.vo.ServerJwtVo;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 상황전파 컨트롤러
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
    "PMD.GuardLogStatement",
    "PMD.AtLeastOneConstructor",
    "PMD.AvoidCatchingGenericException",
    "PMD.AvoidDuplicateLiterals",
    "PMD.AvoidUncheckedExceptionsInSignatures",
    "PMD.BeanMembersShouldSerialize",
    "PMD.CommentDefaultAccessModifier",
    "PMD.CommentRequired",
    "PMD.CommentSize",
    "PMD.DataflowAnomalyAnalysis",
    "PMD.DefaultPackage",
    "PMD.ExcessiveImports",
    "PMD.ExcessiveMethodLength",
    "PMD.ImmutableField",
    "PMD.LawOfDemeter",
    "PMD.LocalVariableCouldBeFinal",
    "PMD.LongVariable",
    "PMD.ModifiedCyclomaticComplexity",
    "PMD.NcssCount",
    "PMD.NonThreadSafeSingleton",
    "PMD.NPathComplexity",
    "PMD.OnlyOneReturn",
    "PMD.ReturnEmptyArrayRatherThanNull",
    "PMD.ReturnEmptyCollectionRatherThanNull",
    "PMD.ShortVariable",
    "PMD.SignatureDeclareThrowsException",
    "PMD.UnnecessaryLocalBeforeReturn",
    "PMD.UnusedAssignment",
    "PMD.UnusedPrivateField",
    "PMD.UnusedPrivateMethod",
    "PMD.UseDiamondOperator",
    "PMD.UseShortArrayInitializer",
    "PMD.UseUtilityClass"	
})
@RestController
@RequestMapping("/api/v1/notify")
@Api(tags = { "상황전파 API" })
public class NotifyController {

	/** 상황전파 저장용 */
	@Autowired
	private transient NotifyRepository notifyRepository;
	
	/** Server Jwt 관리용 */
	@Autowired
	private transient ServerJwtRepository serverJwtRepository;

	/** DTO 생성 헬퍼 */
	@Autowired
	private transient DtoBuilder dtoBuilder;

	/** 로거 */
	private final static Logger LOGGER = LoggerFactory.getLogger(NotifyController.class);

	/**
	 * 서버용 Access JWT 요청
	 * 
	 * @author : david
	 * @param : HttpServletRequest, HttpServletResponse
	 * @return ResultDto
	 * @Date : 2022. 02. 24
	 * @Method Name : reqAccessJwt
	 */
	@PostMapping("token/reqAccessJwt")
	@ApiOperation(value = "서버용 Access JWT 요청", response = ResultDto.class)
	public ResultDto reqAccessJwt(final HttpServletRequest request, final HttpServletResponse response) {

		final ObjectMapper omapper = new ObjectMapper();
		final StringBuffer sbuffer = new StringBuffer();
		ServerJwtVo serverJwtVo;

		try (InputStream istream = request.getInputStream();
				InputStreamReader isr = new InputStreamReader(istream);
				BufferedReader breader = new BufferedReader(isr)) {

			String line = null;
			
			while (true) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(">>> " + line);
				}
				line = breader.readLine();
				if(line != null) {
					sbuffer.append(line);
				} else { 
					break;
				}
			}
			
			/* OLD Style 
			while ((line = breader.readLine()) != null) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(">>> " + line);
				}
				sbuffer.append(line);
			} */

			/*
			 * {     "serverName" : "IoT 게이트웨이",     
			 * 		 "serverIp" : "10.5.35.116",
			 *       "mgrName" : "김민곤",
			 *       "mgrPhoneNo" : "010-0000-0000",
			 *       "mgrEmail" : "93960000@ict-companion.com" }
			 */

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("reqAccessJwt : " + sbuffer.toString());
			}

			serverJwtVo = omapper.readValue(sbuffer.toString(), ServerJwtVo.class);

			final String acsJwt = JWT.create().withSubject("AccessToken4Server")
					.withExpiresAt(new Date(System.currentTimeMillis() + JwtProperties.ACS_EXP_TIME))
					.withClaim("id", serverJwtVo.getServerName())
					.withClaim("username", serverJwtVo.getServerIp())
					.withClaim("realname", serverJwtVo.getMgrName())
					.withClaim("email", serverJwtVo.getMgrEmail())
					.withClaim("phoneNumber", serverJwtVo.getMgrPhoneNo())
					.sign(Algorithm.HMAC512(JwtProperties.SECRET));

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("SERVER JWT : " + acsJwt);
			}
			
			ServerJwt serverJwt = new ServerJwt();
			serverJwt.setAccJwt(acsJwt);
			serverJwt.setSvrIp(serverJwtVo.getServerIp());
			serverJwt.setMngNm(serverJwtVo.getMgrName());
			serverJwt.setMngPhn(serverJwtVo.getMgrPhoneNo());
			serverJwt.setMngEml(serverJwtVo.getMgrEmail());
			serverJwt.setIssDt(new Date());
			serverJwt.setExpDt(new Date(System.currentTimeMillis() + JwtProperties.ACS_EXP_TIME));
			serverJwt.setDelYn('N');

			serverJwtRepository.save(serverJwt);
		    
		} catch (Exception e) {

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(e.getMessage());
			}
		}

		return dtoBuilder.buildReissueDto("0003", "작업중 입니다", null);
	}

	private NotifyHost createNew() {
		return new NotifyHost();
	}

	/**
	 * 상황전파 요청
	 * 
	 * @author : david
	 * @param : HttpServletRequest
	 * @return ResultDto
	 * @Date : 2022. 02. 24
	 * @Method Name : notify
	 */
	@PostMapping("notify")
	@ApiOperation(value = "상황전파 요청", response = ResultDto.class)
	public ResultDto notify(final HttpServletRequest request,
			// @RequestHeader(value="acsJwt") final String acsJwt, 
			@RequestBody final List<NotifyRequestVo> notifyVos) {

		boolean errored = false;
		int errorCnt = 0;
		String errorMsg = null;
		
		/*
		try {
			DecodedJWT decodedJwt = JWT.require(Algorithm.HMAC512(JwtProperties.SECRET)).build().verify(acsJwt);
			Claim c = null;
			c = decodedJwt.getClaim("id");
			c = decodedJwt.getClaim("username");
			c = decodedJwt.getClaim("realname");
			c = decodedJwt.getClaim("email");
			c = decodedJwt.getClaim("phoneNumber");
		}
		catch(JWTVerificationException e) {
			return dtoBuilder.buildReissueDto("0001", "유효하지 않거나 만료된 JWT 입니다.", null);
		}
				
		if(serverJwtRepository.findByAccJwt(acsJwt).size() == 0) {
			return dtoBuilder.buildReissueDto("0001", "등록되지 않은 JWT 입니다.", null);
		}
		*/
		
		for (final NotifyRequestVo vo : notifyVos) {
			final NotifyHost entity = createNew();

			entity.setSvrIp(request.getRemoteAddr());
			entity.setMedTpCd(vo.getType());
			entity.setCtt(vo.getMessage());
			entity.setDst(vo.getDest());
			entity.setNtfScpCd(vo.getScope());

			try {
				notifyRepository.save(entity);
			} catch(Exception e) {
				LOGGER.debug(e.getMessage());
				errored = true;
				errorCnt++;
				errorMsg = e.getMessage();
			}
		}

		if(errored) {
			return dtoBuilder.buildReissueDto("0001", "(" + errorCnt + "/" + notifyVos.size() + " 건) " + errorMsg , null);
		}
		
		return dtoBuilder.buildReissueDto("0000", "저장되었습니다.", null);
	}
}
