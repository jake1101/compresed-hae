package com.customer.job;

import java.util.List;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.customer.entity.NotifyHost;
import com.customer.repository.NotifyRepository;
import com.customer.service.WisecanService;




/**
 * SMS 발송용 Quartz Job 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
    "PMD.AvoidPrintStackTrace",
    "PMD.GuardLogStatement",
    "PMD.AtLeastOneConstructor",
    "PMD.AvoidCatchingGenericException",
    "PMD.AvoidDuplicateLiterals",
    "PMD.AvoidUncheckedExceptionsInSignatures",
    "PMD.BeanMembersShouldSerialize",
    "PMD.CommentDefaultAccessModifier",
    "PMD.CommentRequired",
    "PMD.CommentSize",
    "PMD.DataflowAnomalyAnalysis",
    "PMD.DefaultPackage",
    "PMD.ExcessiveImports",
    "PMD.ExcessiveMethodLength",
    "PMD.ImmutableField",
    "PMD.LawOfDemeter",
    "PMD.LocalVariableCouldBeFinal",
    "PMD.LongVariable",
    "PMD.ModifiedCyclomaticComplexity",
    "PMD.NcssCount",
    "PMD.NonThreadSafeSingleton",
    "PMD.NPathComplexity",
    "PMD.OnlyOneReturn",
    "PMD.ReturnEmptyArrayRatherThanNull",
    "PMD.ReturnEmptyCollectionRatherThanNull",
    "PMD.ShortVariable",
    "PMD.SignatureDeclareThrowsException",
    "PMD.UnnecessaryLocalBeforeReturn",
    "PMD.UnusedAssignment",
    "PMD.UnusedPrivateField",
    "PMD.UnusedPrivateMethod",
    "PMD.UseDiamondOperator",
    "PMD.UseShortArrayInitializer",
    "PMD.UseUtilityClass"	
})
public class NotifySMSJob extends QuartzJobBean {
	/** 로거 */
	private final static Logger LOGGER = LoggerFactory.getLogger(NotifySMSJob.class);

	/** SMS 발신자 번호 */
	@Value("${auth.sms-sender}")
	private transient String smsSender;
	
    /** 상황전파 조회용 */
    @Autowired
    private transient NotifyRepository notifyRepository;

    /** Wisecan SMS 요청 */
    @Autowired
    private transient WisecanService wisecanService;

	@Override
	protected void executeInternal(final JobExecutionContext context) throws JobExecutionException {

		List<NotifyHost> list = notifyRepository.findByMedTpCdAndScsYn("SMS", null);

		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("Fetched SMS : " + list);
		}
		
		list.forEach(notify -> {
			
			try {
				
				try {
					wisecanService.insertSMS(smsSender, notify.getDst(), notify.getCtt());
				} catch(Exception e) {
					
					e.printStackTrace();
					// 200byte 넘는 경우에 발생함.
					wisecanService.insertLMS(smsSender, notify.getDst(), notify.getCtt(), "" /*"[안전관제플랫폼] 상황전파"*/);
				}
	
				notify.setPrcId("1"); 
				notify.setPrcRtrCnt(1);
				notify.setResMsg("Inserted");
				notify.setScsYn("Y");
				
				notifyRepository.save(notify);
			} catch(Exception e) {
				notify.setPrcId("1"); 
				notify.setPrcRtrCnt(1);
				notify.setResMsg(e.getMessage());
				notify.setScsYn("N");
				
				notifyRepository.save(notify);
			}
		});
	}
}