package com.customer.job;

import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.web.client.RestTemplate;

import com.customer.entity.NotifyHost;
import com.customer.repository.NotifyRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;




/**
 * WebSocker 발송용 Quartz Job 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
    "PMD.GuardLogStatement",
    "PMD.AtLeastOneConstructor",
    "PMD.AvoidCatchingGenericException",
    "PMD.AvoidDuplicateLiterals",
    "PMD.AvoidUncheckedExceptionsInSignatures",
    "PMD.BeanMembersShouldSerialize",
    "PMD.CommentDefaultAccessModifier",
    "PMD.CommentRequired",
    "PMD.CommentSize",
    "PMD.DataflowAnomalyAnalysis",
    "PMD.DefaultPackage",
    "PMD.ExcessiveImports",
    "PMD.ExcessiveMethodLength",
    "PMD.ImmutableField",
    "PMD.LawOfDemeter",
    "PMD.LocalVariableCouldBeFinal",
    "PMD.LongVariable",
    "PMD.ModifiedCyclomaticComplexity",
    "PMD.NcssCount",
    "PMD.NonThreadSafeSingleton",
    "PMD.NPathComplexity",
    "PMD.OnlyOneReturn",
    "PMD.ReturnEmptyArrayRatherThanNull",
    "PMD.ReturnEmptyCollectionRatherThanNull",
    "PMD.ShortVariable",
    "PMD.SignatureDeclareThrowsException",
    "PMD.UnnecessaryLocalBeforeReturn",
    "PMD.UnusedAssignment",
    "PMD.UnusedPrivateField",
    "PMD.UnusedPrivateMethod",
    "PMD.UseDiamondOperator",
    "PMD.UseShortArrayInitializer",
    "PMD.UseUtilityClass"	
})
public class NotifyWebJob extends QuartzJobBean {
	/** 로거 */
	private final static Logger LOGGER = LoggerFactory.getLogger(NotifyWebJob.class);

	/** 발송 서버 주소 : 레이컴 */
	@Value("${notify.push.web-url}")
    private transient String webUrl;	
	
	/** 발송에 사용할 서버 토큰 */
    @Value("${notify.push.user-token}")
    private transient String userToken;	

    /** 상황전파 조회용 */
    @Autowired
    private transient NotifyRepository notifyRepository;
    
	private void sendMessage(final NotifyHost notify) {

		ObjectMapper objectMapper = new ObjectMapper();
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();

	    headers.set("Content-Type", "application/json;");
	    headers.set("userToken", userToken);
		 
	    if(LOGGER.isDebugEnabled()) {
	    	LOGGER.debug("Raycom Web Push Request : " + notify.getCtt());	
	    }
 
	    HttpEntity<String> jsonRequest = new HttpEntity<String>(notify.getCtt(), headers);
	    
	    String personResultAsJsonStr = restTemplate.postForObject(webUrl, jsonRequest, String.class);
	    JsonNode root;
	
	    try {
			root = objectMapper.readTree(personResultAsJsonStr);
			JsonNode header = root.get("header");
			int code = header.get("code").asInt();
			String msg = header.get("message").asText();
			
		    if(LOGGER.isDebugEnabled()) {
		    	LOGGER.debug("Raycom Web Push Request : " +root);	
		    }
		    // Save Result
		    notify.setScsYn(code == 1 ? "Y" : "N");
		    notify.setResMsg(msg);
		    notify.setPrcRtrCnt(notify.getPrcRtrCnt() == null ? 1 : notify.getPrcRtrCnt() + 1);

		    notifyRepository.save(notify);
		} catch (Exception e) {
		    if(LOGGER.isDebugEnabled()) {
		    	LOGGER.debug(e.getMessage());	
		    }
		}     
	}
	

	@Override
	protected void executeInternal(final JobExecutionContext context) throws JobExecutionException {
		
		List<NotifyHost> list = notifyRepository.findByMedTpCdAndScsYn("WEB", null);
		
		list.forEach(notify -> {
			notify.setPrcId("1");
			notifyRepository.save(notify);
		});
		
		list.forEach(notify -> {
			sendMessage(notify);
		});
		
	}
}