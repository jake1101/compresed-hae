package com.customer.job;

import java.util.List;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.web.client.RestTemplate;

import com.customer.entity.NotifyHost;
import com.customer.repository.NotifyRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;



/**
 * 앱 푸시 발송용 Quartz Job 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
    "PMD.GuardLogStatement",
    "PMD.AtLeastOneConstructor",
    "PMD.AvoidCatchingGenericException",
    "PMD.AvoidDuplicateLiterals",
    "PMD.AvoidUncheckedExceptionsInSignatures",
    "PMD.BeanMembersShouldSerialize",
    "PMD.CommentDefaultAccessModifier",
    "PMD.CommentRequired",
    "PMD.CommentSize",
    "PMD.DataflowAnomalyAnalysis",
    "PMD.DefaultPackage",
    "PMD.ExcessiveImports",
    "PMD.ExcessiveMethodLength",
    "PMD.ImmutableField",
    "PMD.LawOfDemeter",
    "PMD.LocalVariableCouldBeFinal",
    "PMD.LongVariable",
    "PMD.ModifiedCyclomaticComplexity",
    "PMD.NcssCount",
    "PMD.NonThreadSafeSingleton",
    "PMD.NPathComplexity",
    "PMD.OnlyOneReturn",
    "PMD.ReturnEmptyArrayRatherThanNull",
    "PMD.ReturnEmptyCollectionRatherThanNull",
    "PMD.ShortVariable",
    "PMD.SignatureDeclareThrowsException",
    "PMD.UnnecessaryLocalBeforeReturn",
    "PMD.UnusedAssignment",
    "PMD.UnusedPrivateField",
    "PMD.UnusedPrivateMethod",
    "PMD.UseDiamondOperator",
    "PMD.UseShortArrayInitializer",
    "PMD.UseUtilityClass"	
})
public class NotifyAppJob extends QuartzJobBean {
	
	/** 로거 */
	private final static Logger LOGGER = LoggerFactory.getLogger(NotifyAppJob.class);

	/** 앱발송 서버 주소 : 레이컴 */
    @Value("${notify.push.app-url}")
    private transient String appUrl;	

	/** 앱발송에 사용할 서버 토큰 */
    @Value("${notify.push.user-token}")
    private transient String userToken;	

    /** 상황전파 조회용 */
    @Autowired
    private transient NotifyRepository notifyRepository;
    
	private void sendMessage(final NotifyHost notify) {

		ObjectMapper objectMapper = new ObjectMapper();
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
	    headers.set("Content-Type", "application/json;");
	    headers.set("userToken", userToken);
		
	    /* 레이컴 샘플
	    {
	    	"alarmType": "emergency",
			"siteId": 11,
			"alarmId": 1,
			"senderId": "lw0001099",
			"receiverId": "ADMIN",
			"data": {
				"to": "fbf5ce93-043b-4105-b96f-505bb20dd96efbf5ce93-043b-4105-b96f-505bb20dd96e",
				"noticeDate": "2022-03-07 14:11:11",
				"targetType": "emergency",
				"title": "����",
				"message": "����",
				"targetInfo": {
					"kind": "worker",
					"targetId": 111,
					"point": {
						"lat": 36.2323,
						"lon": 121.232
					}

				}
	    	}
	    } */

	    /* 레이컴 샘플 --> JSONObject 로 변환 
	    JSONObject jsonObject = new JSONObject();
	    jsonObject.put("alarmType", "emergency");
	    jsonObject.put("siteId", 11);
	    jsonObject.put("alarmId", 1);
	    jsonObject.put("senderId", "lw0001099");
	    jsonObject.put("receiverId", "ADMIN");
	    jsonObject.put("data", new HashMap() {{
	    	put("to", "fbf5ce93-043b-4105-b96f-505bb20dd96efbf5ce93-043b-4105-b96f-505bb20dd96e");
	    	put("noticeDate", "2022-03-07 14:11:11");
	    	put("targetType", "emergency");
	    	put("title", "����Ʈ ��������");
	    	put("message", notify.getCtt());
	    	put("targetInfo", new HashMap() {{
				put("kind", "worker");
				put("targetId", 111);
	    	
				put("point", new HashMap() {{
					put("lat", 36.2323);
					put("lon", 121.232);
		    	}});
	    	}});
	    }});
	    */

	    
	    
		if(LOGGER.isDebugEnabled()) {
			  LOGGER.debug("Raycom FB Push Request : " + notify.getCtt());		
		}
		
	    HttpEntity<String> jsonRequest = new HttpEntity<String>(notify.getCtt(), headers);
	    
	    String personResultAsJsonStr = restTemplate.postForObject(appUrl, jsonRequest, String.class);
	    JsonNode root;
	    
	    try {
			root = objectMapper.readTree(personResultAsJsonStr);
			JsonNode header = root.get("header");
			int code = header.get("code").asInt();
			String msg = header.get("message").asText();
			
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug("Raycom FB Push Result : " + root);	
			}
		    
		    // Save Result
		    notify.setScsYn(code == 1 ? "Y" : "N");
		    notify.setResMsg(msg);
		    notify.setPrcRtrCnt(notify.getPrcRtrCnt() == null ? 1 : notify.getPrcRtrCnt() + 1);

		    notifyRepository.save(notify);
		} catch (Exception e) {
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug(e.getMessage());	
			}
		} 
	    
	    
		LOGGER.info("============================================================================");

	}
	

	@Override
	protected void executeInternal(final JobExecutionContext context) throws JobExecutionException {
	
		List<NotifyHost> list = notifyRepository.findByMedTpCdAndScsYn("APP", null);
		
		list.forEach(notify -> {
			notify.setPrcId("1");
			notifyRepository.save(notify);
		});
		
		list.forEach(notify -> {
			sendMessage(notify);
		});
		
		
	}
}