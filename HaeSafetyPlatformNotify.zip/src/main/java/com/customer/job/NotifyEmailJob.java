package com.customer.job;

import java.util.List;

import org.json.simple.JSONObject;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.web.client.RestTemplate;

import com.customer.entity.NotifyHost;
import com.customer.repository.NotifyRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;




/**
 * 이메일 발송용 Quartz Job 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
    "PMD.GuardLogStatement",
    "PMD.AtLeastOneConstructor",
    "PMD.AvoidCatchingGenericException",
    "PMD.AvoidDuplicateLiterals",
    "PMD.AvoidUncheckedExceptionsInSignatures",
    "PMD.BeanMembersShouldSerialize",
    "PMD.CommentDefaultAccessModifier",
    "PMD.CommentRequired",
    "PMD.CommentSize",
    "PMD.DataflowAnomalyAnalysis",
    "PMD.DefaultPackage",
    "PMD.ExcessiveImports",
    "PMD.ExcessiveMethodLength",
    "PMD.ImmutableField",
    "PMD.LawOfDemeter",
    "PMD.LocalVariableCouldBeFinal",
    "PMD.LongVariable",
    "PMD.ModifiedCyclomaticComplexity",
    "PMD.NcssCount",
    "PMD.NonThreadSafeSingleton",
    "PMD.NPathComplexity",
    "PMD.OnlyOneReturn",
    "PMD.ReturnEmptyArrayRatherThanNull",
    "PMD.ReturnEmptyCollectionRatherThanNull",
    "PMD.ShortVariable",
    "PMD.SignatureDeclareThrowsException",
    "PMD.UnnecessaryLocalBeforeReturn",
    "PMD.UnusedAssignment",
    "PMD.UnusedPrivateField",
    "PMD.UnusedPrivateMethod",
    "PMD.UseDiamondOperator",
    "PMD.UseShortArrayInitializer",
    "PMD.UseUtilityClass"	
})
public class NotifyEmailJob extends QuartzJobBean {
	
	/** 결과 성공 코드 */
	private final static String SUCCESS = "0000";
	
	/** 로거 */
	private final static Logger LOGGER = LoggerFactory.getLogger(NotifyEmailJob.class);

	/** 이메일 전송 Agent 주소 */
    @Value("${notify.mail.request}")
    private transient String requestUrl;
  
    /** 상황전파 조회용 */
    @Autowired
    private transient NotifyRepository notifyRepository;

	private void sendMessage(final NotifyHost notify) {
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.add("Authorization", "HHHHHHHHHHH");
	    JsonNode root;
	    
		ObjectMapper objectMapper = new ObjectMapper();
	    JSONObject jsonObject = new JSONObject();
	    jsonObject.put("id", notify.getId());
	    jsonObject.put("title", notify.getTitle());
	    jsonObject.put("content", notify.getCtt());
	    jsonObject.put("tos", notify.getDst());
	    
	    HttpEntity<String> jsonRequest = new HttpEntity<String>(jsonObject.toString(), headers);

	    if(LOGGER.isDebugEnabled()) {
	    	LOGGER.debug("loginApiUrl : " + requestUrl);
		    LOGGER.debug("Payload : " + jsonObject.toString());
	    }
	
        try {
        	
    	    String jsonStr = restTemplate.postForObject(requestUrl, jsonRequest, String.class);  
        	
			root = objectMapper.readTree(jsonStr);
			
		    if(LOGGER.isDebugEnabled()) {
		    	LOGGER.debug("Result : " + root);
		    }
		    String result = root.get("result").asText();
		    String message = root.get("message").asText();
		    

		    notify.setResMsg(message);
		    notify.setScsYn(SUCCESS.equals(result) ? "Y" : "N");

		    if(LOGGER.isDebugEnabled()) {
		    	LOGGER.debug("Sent Email : " + notify.getDst() + " : " + notify.getCtt());
		    }

        } catch (Exception e) {
    	    if(LOGGER.isDebugEnabled()) {
    	    	LOGGER.debug(e.getMessage());
    	    }
		    notify.setScsYn("N");
		    notify.setResMsg(e.getMessage());
		    
        } finally {

		    notify.setPrcRtrCnt(notify.getPrcRtrCnt() == null ? 1 : notify.getPrcRtrCnt() + 1);
		    notifyRepository.save(notify);
        }
	}
	
	
	@Override
	protected void executeInternal(final JobExecutionContext context) throws JobExecutionException {

		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("Fetched EMAIL");
		}
		
		List<NotifyHost> list = notifyRepository.findByMedTpCdAndScsYn("EMAIL", null);
		
		list.forEach(notify -> {
			notify.setPrcId("1"); 
			notifyRepository.save(notify);
		});
		
		list.forEach(notify -> {
			sendMessage(notify);
		});
	}
}