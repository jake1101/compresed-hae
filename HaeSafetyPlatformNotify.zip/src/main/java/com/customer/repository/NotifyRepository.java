package com.customer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customer.entity.NotifyHost;

/**
 * 상황전파 DB 레파지토리
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

public interface NotifyRepository extends JpaRepository<NotifyHost, String>{

	/**  ProcessId 로 조회*/
	List<NotifyHost> findByPrcId(String prcId);
		 
	/**  MediaType 과 성공여부로 조회*/
	List<NotifyHost> findByMedTpCdAndScsYn(String medTpCd, String scsYn);

}
