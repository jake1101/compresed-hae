package com.customer.type;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
//import java.util.stream.Stream;


/**
 *   MediaTypeConverter 
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
    "PMD.AtLeastOneConstructor",
    "PMD.OnlyOneReturn"	
})
@Converter(autoApply = true)
public class MediaTypeConverter implements AttributeConverter<MediaType, String> {
 
    @Override
    public String convertToDatabaseColumn(final MediaType category) {
        if (category == null) {
            return null;
        }
        return category.getCode();
    }

    @Override
    public MediaType convertToEntityAttribute(final String code) {
        if (code == null) {
            return null;
        }

//        return Stream.of(MediaType.values())
//          .filter(c -> c.getCode().equals((code)))
//          .findFirst()
//          .orElseThrow(IllegalArgumentException::new);
        
        return null;
    }
}