package com.customer.dto;

import lombok.Data;

/**
 * ResultDto 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@Data
public class ResultDto extends BaseDto {

	/** Payload */
    public Payload data = new Payload();
    
	/** 서버용 토큰 */
	@Data
	public class Payload {
		
		/** Access JWT  */
	    private String acsJwt;
	    
		/** Access JWT Expired  */
	    private Long acsJwtExpired;

		/** Refresh JWT */
	    private String refJwt;

		/** Refresh JWT Expired */
	    private Long refJwtExpired;
	}

}

