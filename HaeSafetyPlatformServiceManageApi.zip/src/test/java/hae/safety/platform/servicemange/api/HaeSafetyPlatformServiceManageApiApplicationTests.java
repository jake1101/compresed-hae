package hae.safety.platform.servicemange.api;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

/**
 * Test Class
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.LawOfDemeter","PMD.AvoidCatchingGenericException","PMD.AtLeastOneConstructor","PMD.ImmutableField"})
@Slf4j
@SpringBootTest
class HaeSafetyPlatformServiceManageApiApplicationTests {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(HaeSafetyPlatformServiceManageApiApplicationTests.class);

	/**
	 * SqlSessionFactory
	 */
	@Autowired
    private transient SqlSessionFactory sqlSessionFactory;

	/**
	 * Test Method
	 *
	 * @author : hjh
	 * @Date : 2022. 02. 24
	 */
    @Test
    private void connectionTest(){  // NOPMD by 9396368 on 22. 4. 11. 오후 3:39, Test method
        try(Connection con = sqlSessionFactory.openSession().getConnection()){
        	assertNotNull("bar not found", con);
        }catch(Exception e){
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
        }
    }
}
