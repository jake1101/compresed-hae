package hae.safety.platform.servicemange.api.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

/**
 * 1:1 서비스요청용 Mapper Interface
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize"})
@Mapper
public interface ServiceInquiryManageMapper {
 
	/**
	 * 1:1 서비스 요청 조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 17
	 * @Method Name : searchHotLine
	 */
    List<Map<String,Object>> searchHotLine(Map param);
    /**
	 * 1:1 서비스 요청 상세 조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 17
	 * @Method Name : searchHotLineDetail
	 */
    List<Map<String,Object>> searchHotLineDetail(Map param);
    /**
	 * 1:1 서비스 요청 신규 요청
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 17
	 * @Method Name : addHotLine
	 */
    int addHotLine(Map param);
    /**
	 * 1:1 서비스 요청 삭제
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 17
	 * @Method Name : deleteHotLine
	 */
    int deleteHotLine(Map param);
    /**
	 * 1:1 서비스 요청 답변 등록
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 30
	 * @Method Name : resHotLine
	 */
    int resHotLine(Map param);
    /**
  	 * 서비스 문의 : 조회
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 03. 30
  	 * @Method Name : getQNAList
  	 */
    List<Map<String,Object>> getQNAList(Map param);
    /**
  	 * 서비스 문의 : 답변 등록
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 03. 30
  	 * @Method Name : resQNA
  	 */
    int resQNA(Map param);
    /**
  	 * 서비스 문의 : 조회
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 03. 30
  	 * @Method Name : getQNAList
  	 */
    List<Map<String,Object>> searchQNADetail(Map param);
    /**
  	 * 서비스 문의 : 문의 등록
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 04. 06
  	 * @Method Name : resQNA
  	 */
    int reqQNA(Map param);
}
