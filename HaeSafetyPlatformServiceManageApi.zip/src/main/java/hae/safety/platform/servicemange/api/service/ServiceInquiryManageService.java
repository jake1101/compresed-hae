package hae.safety.platform.servicemange.api.service;

import java.util.List;
import java.util.Map;

//import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hae.safety.platform.servicemange.api.mapper.ServiceInquiryManageMapper;

/**
 * Service
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.AtLeastOneConstructor", "PMD.ImmutableField"})
@Service
@Transactional(rollbackFor = {Exception.class})
public class ServiceInquiryManageService {
	
	/**
	 * Mapper
	 */
    @Autowired
    private transient ServiceInquiryManageMapper mapper;
    
	/**
	 * 1:1 서비스 요청 조회
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 16
	 * @Method Name : searchHotLine
	 */
    public List<Map<String,Object>> searchHotLine(final Map param) {
		
		return mapper.searchHotLine(param);
	}
    
    /**
	 * 1:1 서비스 요청 상세 조회
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 17
	 * @Method Name : searchHotLineDetail
	 */
    public List<Map<String,Object>> searchHotLineDetail(final Map param) {
		
		return mapper.searchHotLineDetail(param);
	}
    
    /**
	 * 1:1 서비스 요청 신규요청
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 17
	 * @Method Name : addHotLine
	 */
    public int addHotLine(final Map param) {
		
		return mapper.addHotLine(param);
	}
    
    /**
	 * 1:1 서비스 요청 삭제
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 17
	 * @Method Name : deleteHotLine
	 */
    public int deleteHotLine(final Map param) {
		
		return mapper.deleteHotLine(param);
	}
    
    /**
   	 * 1:1 서비스 요청 답변 등록
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 30
   	 * @Method Name : resHotLine
   	 */
       public int resHotLine(final Map param) {
   		
   		return mapper.resHotLine(param);
   	}
       
	/**
  	 * 서비스 문의 : 조회
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 03. 30
  	 * @Method Name : getQNAList
  	 */
      public List<Map<String,Object>> getQNAList(final Map param) {
  		
  		return mapper.getQNAList(param);
  	}
      
 	/**
 	 * 서비스 문의 : 답변 등록
 	 *
 	 * @author : hjh
 	 * @param 
 	 * @return 
 	 * @Date : 2022. 03. 30
 	 * @Method Name : resQNA
 	 */
     public int resQNA(final Map param) {
 		
 		return mapper.resQNA(param);
 	}
     
     /**
   	 * 서비스 문의 : 상세 조회
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 30
   	 * @Method Name : searchQNADetail
   	 */
       public List<Map<String,Object>> searchQNADetail(final Map param) {
   		
   		return mapper.searchQNADetail(param);
   	}
       
   /**
	 * 서비스 문의 : 문의 하기
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 04. 06
	 * @Method Name : reqQNA
	 */
    public int reqQNA(final Map param) {
		
		return mapper.reqQNA(param);
	}
    
}
