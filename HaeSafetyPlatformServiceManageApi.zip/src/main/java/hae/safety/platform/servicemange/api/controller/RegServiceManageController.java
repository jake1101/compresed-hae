package hae.safety.platform.servicemange.api.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import hae.safety.platform.servicemange.api.dto.BaseDto;
import hae.safety.platform.servicemange.api.service.BaseServiceManageService;
import hae.safety.platform.servicemange.api.service.RegServiceManageService;
import hae.safety.platform.servicemange.api.util.DtoBuilder;
import hae.safety.platform.servicemange.api.util.DtoJsonArray;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


/**
 * 조회용 Controller
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.LinguisticNaming", "PMD.CommentSize", "PMD.ShortVariable", "PMD.LongVariable", "PMD.AvoidCatchingGenericException", "PMD.AvoidLiteralsInIfCondition"})
@Slf4j
@RestController
@RequiredArgsConstructor
//@RequestMapping("api/v1")
@RequestMapping("${apiConfig.path}")
@Api(tags = {"등록 서비스 관리"})
// @CrossOrigin  // CORS 허용 
public class RegServiceManageController {
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(RegServiceManageController.class);
	
    /**
	 * 그룹관리자용 service
	 */
	@Autowired
	private RegServiceManageService regServiceManageService;
	
    /**
	 * 기초정보조회용 service
	 */
	@Autowired
	private BaseServiceManageService baseServiceManageService;
	
    /**
	 * 조회결과 return DTO
	 */
	@Autowired
	private DtoJsonArray dtoJsonArray;
	
    /**
	 * DtoBuilder
	 */
	@Autowired
	private DtoBuilder dtoBuilder;
	
	/**
	 * 조회 결과 key
	 */
	@Value("${key.listKey}")
	private transient String listKey;
	
	/**
	 * update 결과 key
	 */
	@Value("${key.cntKey}")
	private transient String cntKey;
	
	/**
	 * 조회 성공 message key
	 */
	@Value("${msg.searchSuccess}")
	private transient String searchSuccess;
	
    /**
	 * 조회 실패 message key
	 */
	@Value("${msg.searchFail}")
	private transient String searchFail;
	
    /**
	 * 처리 성공 message key
	 */
	@Value("${msg.processSuccess}")
	private transient String processSuccess;
	
    /**
	 * 처리 실패 message key
	 */
	@Value("${msg.processFail}")
	private transient String processFail;
	
	/**
	 * 처리 실패 사유 message key
	 */
	@Value("${msg.noticeMsg1}")
	private transient String noticeMsg1;
	
	/**
	 * 처리 성공 message key
	 */
	@Value("${msg.delSuccess}")
	private transient String delSuccess;
	
    /**
	 * 처리 실패 message key
	 */
	@Value("${msg.delFail}")
	private transient String delFail;
	
	/**
	 * 등록서비스그룹전체조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : searchAllSvcGrpList
	 */
	@PostMapping("searchAllSvcGrpList")
	@ApiOperation(value = "등록서비스그룹전체조회", response = BaseDto.class)
    public void searchAllSvcGrpList() {
		
		final List<Map<String,Object>> svcGrpList = regServiceManageService.getSvcGrpAll();
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(svcGrpList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", processSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 등록서비스검색조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : findRegSafetyServiceList
	 */
	@PostMapping("findRegSafetyServiceList")
	@ApiOperation(value = "등록서비스검색조회", response = BaseDto.class)
    public void findRegSafetyServiceList(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> svcGroups = regServiceManageService.findRegSafetyServiceList(param);
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String response = om.writeValueAsString(svcGroups);
			final JSONArray jo = (JSONArray) JSONValue.parse(response);
			dtoBuilder.writeResultPayload("1", processSuccess, jo);
		} catch (JsonProcessingException e) {
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
		
    }
	
	/**
	 * 등록서비스 사용상태 변경
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : updateServiceUseYn
	 */
	@PostMapping("updateServiceUseYn")
	@ApiOperation(value = "등록서비스 사용상태 변경", response = BaseDto.class)
    public void updateServiceUseYn(@RequestBody final Map param) {
		
		final int cudCnt = regServiceManageService.updateServiceUseYn(param);
		
		final Map<String, Object> reParam = new ConcurrentHashMap<>();
		
		reParam.put(cntKey, cudCnt);
		
		try {
			dtoBuilder.writeResultPayload("1", processSuccess, reParam);
		} catch (Exception e) {
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 서비스 신청 관리 : 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprList
	 */
	@PostMapping("getServiceAprList")
	@ApiOperation(value = "서비스 신청 관리 : 조회", response = BaseDto.class)
    public void getServiceAprList(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resList = regServiceManageService.getServiceAprList(param);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", processSuccess, dtoJsonArray.toJSONArray(resList));
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 서비스 신청 관리 : 상세조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprListDetail
	 */
	@PostMapping("getServiceAprListDetail")
	@ApiOperation(value = "서비스 신청 관리 : 상세조회", response = BaseDto.class)
    public void getServiceAprListDetail(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resList = regServiceManageService.getServiceAprListDetail(param);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", processSuccess, dtoJsonArray.toJSONArray(resList));
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 서비스 신청 관리 : 상세조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprListDvcDetail
	 */
	@PostMapping("getServiceAprListDvcDetail")
	@ApiOperation(value = "서비스 신청 관리 : 서비스별 장비 상세 조회", response = BaseDto.class)
    public void getServiceAprListDvcDetail(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resList = regServiceManageService.getServiceAprListDvcDetail(param);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", processSuccess, dtoJsonArray.toJSONArray(resList));
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 서비스 신청 관리 : 변경신청 상세조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprChgListDetail
	 */
	@PostMapping("getServiceAprChgListDetail")
	@ApiOperation(value = "서비스 신청 관리 : 변경신청 상세조회", response = BaseDto.class)
    public void getServiceAprChgListDetail(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resList = regServiceManageService.getServiceAprChgListDetail(param);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", processSuccess, dtoJsonArray.toJSONArray(resList));
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 서비스 신청 관리 : 신규 신청 승인
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @throws ParseException 
	 * @throws Exception 
	 * @Date : 2022. 03. 23
	 * @Method Name : serviceAplAprProcess
	 */
	@PostMapping("serviceAplAprProcess")
	@ApiOperation(value = "서비스 신청 관리 : 승인", response = BaseDto.class)
    public void serviceAplAprProcess(@RequestBody final Map param) throws ParseException {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final int cudCnt = regServiceManageService.serviceAplAprProcess(param);
		
		final Map<String, Object> reParam = new ConcurrentHashMap<>();
		
		reParam.put(cntKey, cudCnt);
		
		if(cudCnt >= 1) { 
			dtoBuilder.writeResultPayload("1", processSuccess, reParam);
		} else {
			dtoBuilder.writeResultPayload("0", processFail, reParam);
		}
    }
	
	/**
	 * 서비스 신청 관리 : 변경신청 상세조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : grpAdmServiceUseList
	 */
	@PostMapping("grpAdmServiceUseList")
	@ApiOperation(value = "그룹 관리자 서비스 이용 현황 : 변경신청 상세조회 ", response = BaseDto.class)
    public void grpAdmServiceUseList(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resList = regServiceManageService.grpAdmServiceUseList(param);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", processSuccess, dtoJsonArray.toJSONArray(resList));
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 구독료 납부 관리 : 구독료 관리 목록 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 25
	 * @Method Name : serviceSstList
	 */
	@PostMapping("serviceSstList")
	@ApiOperation(value = "그룹 관리자 서비스 이용 현황 : 구독료 관리 목록 조회", response = BaseDto.class)
    public void serviceSstList(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resList = regServiceManageService.serviceSstList(param);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", processSuccess, dtoJsonArray.toJSONArray(resList));
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 그룹 관리자 서비스 이용 현황 : 구독료 관리 목록 상세 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 25
	 * @Method Name : serviceSstListDetail
	 */
	@PostMapping("serviceSstListDetail")
	@ApiOperation(value = "그룹 관리자 서비스 이용 현황 : 구독료 관리 목록 조회", response = BaseDto.class)
    public void serviceSstListDetail(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resList = regServiceManageService.serviceSstListDetail(param);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", processSuccess, dtoJsonArray.toJSONArray(resList));
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 구독료 납부 관리 : 구독료 관리 목록 상세 조회 : 날짜 수정
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 25
	 * @Method Name : serviceSstListDetailChgDay
	 */
	@PostMapping("serviceSstListDetailChgDay")
	@ApiOperation(value = "구독료 납부 관리 : 구독료 관리 목록 상세 조회 : 날짜 수정", response = BaseDto.class)
    public void serviceSstListDetailChgDay(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final int cudCnt = regServiceManageService.serviceSstListDetailChgDay(param);
		
		final Map<String, Object> reParam = new ConcurrentHashMap<>();
		
		reParam.put(cntKey, cudCnt);
		
		if(cudCnt == 1) { 
			dtoBuilder.writeResultPayload("1", processSuccess, reParam);
		} else {
			dtoBuilder.writeResultPayload("0", processFail, reParam);
		}
    }
	
	/**
	 * 구독료 납부 관리 : 구독료 관리 목록 상세 조회 : 납부 확인
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : serviceSstListDetailChgFee
	 */
	@PostMapping("serviceSstListDetailChgFee")
	@ApiOperation(value = "구독료 납부 관리 : 구독료 관리 목록 상세 조회 : 납부 확인", response = BaseDto.class)
    public void serviceSstListDetailChgFee(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final int cudCnt = regServiceManageService.serviceSstListDetailChgFee(param);
		
		final Map<String, Object> reParam = new ConcurrentHashMap<>();
		
		reParam.put(cntKey, cudCnt);
		
		if(cudCnt == 1) { 
			dtoBuilder.writeResultPayload("1", processSuccess, reParam);
		} else {
			dtoBuilder.writeResultPayload("0", processFail, reParam);
		}
    }
	
	/**
	 * 구독료 통계 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 30
	 * @Method Name : getMonFeeStatistics
	 */
	@PostMapping("getMonFeeStatistics")
	@ApiOperation(value = "구독료 통계 조회", response = BaseDto.class)
    public void getMonFeeStatistics(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		
		try {
			final List<Map<String,Object>> resList = regServiceManageService.getMonFeeStatistics(param);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", processSuccess, dtoJsonArray.toJSONArray(resList));
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", processFail, e.getMessage());
		}
    }
	
	/**
	 * 구독료 납부 관리 : 구독료 관리 목록 상세 조회 -> 기간 변경
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 25
	 * @Method Name : serviceSstListDetail
	 
	@PostMapping("serviceAplAprProcess")
	@ApiOperation(value = "서비스 신청 관리 : 승인", response = BaseDto.class)
    public void serviceAplAprProcess(@RequestBody Map param) {
		
		// 권한별 사업자 정보 조회
		List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		int cudCnt = regServiceManageService.serviceAplAprProcess(param);
		
		Map<String, Object> reParam = new HashMap<String, Object>();
		
		reParam.put(cntKey, cudCnt);
		
		if(cudCnt == 1) {
			dtoBuilder.writeResultPayload("1", "처리 성공", reParam);
		} else {
			dtoBuilder.writeResultPayload("0", "이미 처리된 서비스입니다.", reParam);
		}
    }
	*/
	
	
//	@PostMapping("searchAllSvcGrpList")
//	@ApiOperation(value = "등록서비스그룹전체조회", response = BaseDto.class)
//    public void searchAllSvcGrpList() {
//		
//		List<SvcGrp> svcGroups = svcGrpRepository.findAll();
//		
//		ObjectMapper om = new ObjectMapper();
//		
//		String reParam;
//		
//		try {
//			reParam = om.writeValueAsString(svcGroups);
//			JSONArray jo = (JSONArray) JSONValue.parse(reParam);
//			// (code : 1 or 0, massage , data)
//			dtoBuilder.writeResultPayload("1", processSuccess, jo);
//		} catch (JsonProcessingException e) {
//			dtoBuilder.writeResultPayload("0", processSuccess, e.getMessage());
//		}
//    }
//	
//	@PostMapping("searchSvcGrpListParam")
//	@ApiOperation(value = "등록서비스그룹검색조회", response = BaseDto.class)
//    public void searchSvcGrpListParam(@RequestBody SvcGrp SvcGrp) {
//		
//		List<SvcGrp> svcGroups = svcGrpRepository.searchSvcGrpRepo(SvcGrp.getSvc_grp_id());
//				
//		ObjectMapper om = new ObjectMapper();
//		
//		String reParam;
//		
//		try {
//			reParam = om.writeValueAsString(svcGroups);
//			JSONArray jo = (JSONArray) JSONValue.parse(reParam);
//			dtoBuilder.writeResultPayload("1", processSuccess, jo);
//		} catch (JsonProcessingException e) {
//			dtoBuilder.writeResultPayload("0", processSuccess, e.getMessage());
//		}
//		
//    }
//	
//	@PostMapping("findRegSafetyServiceList")
//	@ApiOperation(value = "등록서비스검색조회", response = BaseDto.class)
//    public void findRegSafetyServiceList(@RequestBody Map param) {
//		
////		String svcGrpNm = (String) param.get("search");
////		String svcGrpId = (String) param.get("id");
//		
////		List<SvcList> svcGroups = svcListRepository.findRegSafetyServiceList(svcGrpId, svcGrpNm );
//		
//		List<SvcList> svcGroups = svcListRepository.findRegSafetyServiceList(param);
//		
//		ObjectMapper om = new ObjectMapper();
//		
//		String reParam;
//		
//		try {
//			reParam = om.writeValueAsString(svcGroups);
//			JSONArray jo = (JSONArray) JSONValue.parse(reParam);
//			dtoBuilder.writeResultPayload("1", processSuccess, jo);
//		} catch (JsonProcessingException e) {
//			dtoBuilder.writeResultPayload("0", processSuccess, e.getMessage());
//		}
//		
//    }
	
}
