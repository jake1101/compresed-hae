package hae.safety.platform.servicemange.api.util;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import lombok.extern.slf4j.Slf4j;

/**
 * 조회데이터 리턴 공통 Service
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.AtLeastOneConstructor", "PMD.AvoidCatchingGenericException", "PMD.ShortVariable", "PMD.LawOfDemeter", "PMD.DataflowAnomalyAnalysis"})
@Slf4j
@Service
public class DtoBuilder {
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DtoBuilder.class);

    /**
   	 * Return Json Data Set
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 18
   	 * @Method Name : writeResultPayload
   	 */
	public void writeResultPayload(
			final String code, 
			final String message, 
			final Object data
	) {

		final ServletRequestAttributes attr = (ServletRequestAttributes)RequestContextHolder.currentRequestAttributes();
		final HttpServletResponse response = attr.getResponse();

		response.setContentType("application/json");

		final JSONObject responseData = new JSONObject();
//		JsonObject status = new JsonObject();
//		JsonArray statusArray = new JsonArray();
//		
//		status.addProperty("code", code);
//		status.addProperty("message", message);
//		statusArray.add(status);

//		responseData.put("result", result);
//		responseData.put("message", message);

		if(data != null) {
			//responseData.put("header", statusArray);
			responseData.put("code", code);
			responseData.put("message", message);
			responseData.put("data", data);
		}

		
		try (PrintWriter w = response.getWriter()) {
			w.print(responseData.toJSONString());
			w.flush();
		} catch(Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
		} 
	}
	
	
}
