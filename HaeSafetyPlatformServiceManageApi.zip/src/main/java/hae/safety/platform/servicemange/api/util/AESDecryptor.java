package hae.safety.platform.servicemange.api.util;

import java.nio.charset.StandardCharsets;
import java.security.DigestException;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

/**
 * Decryptor
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({"PMD.CommentSize", "PMD.AtLeastOneConstructor", "PMD.AvoidCatchingGenericException", "PMD.ShortVariable", "PMD.LawOfDemeter", "PMD.DataflowAnomalyAnalysis"})
@Slf4j
@Service
public class AESDecryptor {
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AESDecryptor.class);

	/**
	 * Decrypt message encrypted using AES
	 *
	 * @author : hjh
	 * @param : String cipherText, String secret
	 * @return : String
	 * @Date : 2022. 03. 11
	 * @Method Name : decryptText
	 */
	public String decryptText(final String cipherText, final String secret) {

		String decryptedText = null;
		final byte[] cipherData = java.util.Base64.getDecoder().decode(cipherText);
		final byte[] saltData = Arrays.copyOfRange(cipherData, 8, 16);
		try {
			final MessageDigest md5 = MessageDigest.getInstance("MD5");
			final byte[][] keyAndIV = generateKeyAndIV(32, 16, 1, saltData, secret.getBytes(StandardCharsets.UTF_8), md5);
			final SecretKeySpec key = new SecretKeySpec(keyAndIV[0], "AES");
			final IvParameterSpec iv = new IvParameterSpec(keyAndIV[1]);
			final byte[] encrypted = Arrays.copyOfRange(cipherData, 16, cipherData.length);
			final Cipher aesCBC = Cipher.getInstance("AES/CBC/PKCS5Padding");
			
			aesCBC.init(Cipher.DECRYPT_MODE, key, iv);
			
			final byte[] decryptedData = aesCBC.doFinal(encrypted);
			
			decryptedText = new String(decryptedData, StandardCharsets.UTF_8);
		} catch (Exception ex) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(ex.getMessage());
			}
		}

		return decryptedText;

	}

	/**
	 * generateKey And IV
	 *
	 * @author : hjh
	 * @param : int keyLength, int ivLength, int iterations, byte[] salt, byte[]
	 *          password, MessageDigest md
	 * @return : String
	 * @Date : 2022. 03. 11
	 * @Method Name : generateKeyAndIV
	 */
	public byte[][] generateKeyAndIV(final int keyLength, final int ivLength, final int iterations, final byte[] salt,
			final byte[] password, final MessageDigest md) throws DigestException {

		final int digestLength = md.getDigestLength();
		final int requiredLength = (keyLength + ivLength + digestLength - 1) / digestLength * digestLength;
		final byte[] generatedData = new byte[requiredLength];
		int generatedLength = 0;

		try {
			md.reset();

			// Repeat process until sufficient data has been generated
			while (generatedLength < keyLength + ivLength) {

				// Digest data (last digest if available, password data, salt if available)
				if (generatedLength > 0) {
					md.update(generatedData, generatedLength - digestLength, digestLength);
				}
				md.update(password);

				if (salt != null) {
					md.update(salt, 0, 8);
				}
				md.digest(generatedData, generatedLength, digestLength);

				// additional rounds
				for (int i = 1; i < iterations; i++) {
					md.update(generatedData, generatedLength, digestLength);
					md.digest(generatedData, generatedLength, digestLength);
				}

				generatedLength += digestLength;
			}

			// Copy key and IV into separate byte arrays
			byte[][] result = new byte[2][];
			result[0] = Arrays.copyOfRange(generatedData, 0, keyLength);
			if (ivLength > 0) {
				result[1] = Arrays.copyOfRange(generatedData, keyLength, keyLength + ivLength);
			}
			return result;

		} finally {
			// Clean out temporary data
			Arrays.fill(generatedData, (byte) 0);
		}
	}

}
