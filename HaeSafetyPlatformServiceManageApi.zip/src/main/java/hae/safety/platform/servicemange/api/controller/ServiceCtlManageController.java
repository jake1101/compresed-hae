package hae.safety.platform.servicemange.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import hae.safety.platform.servicemange.api.dto.BaseDto;
import hae.safety.platform.servicemange.api.service.BaseServiceManageService;
import hae.safety.platform.servicemange.api.service.ServiceCtlManageService;
import hae.safety.platform.servicemange.api.util.AESDecryptor;
import hae.safety.platform.servicemange.api.util.DtoBuilder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * 계열사 관리자용 Controller
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.LinguisticNaming", "PMD.CommentSize", "PMD.ShortVariable", "PMD.LongVariable", "PMD.AvoidCatchingGenericException", 
	"PMD.AvoidLiteralsInIfCondition", "PMD.LawOfDemeter", "PMD.ImmutableField", "PMD.ForLoopCanBeForeach", "PMD.AtLeastOneConstructor", "PMD.DataflowAnomalyAnalysis"})
@Slf4j
@RestController
//@RequestMapping("api/v1")
@RequestMapping("${apiConfig.path}")
@Api(tags = {"서비스 카테고리 관리"})
// @CrossOrigin  // CORS 허용 
public class ServiceCtlManageController {
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceCtlManageController.class);

    /**
	 * 복호화 공유 SECRETKEY
	 */
	@Value("${AESDecryptor.secret}")
	private transient String secretKey;
	
	/**
	 * 조회 결과 key
	 */
	@Value("${key.listKey}")
	private transient String listKey;
	
	/**
	 * update 결과 key
	 */
	@Value("${key.cntKey}")
	private transient String cntKey;
	
	/**
	 * 조회 성공 message key
	 */
	@Value("${msg.searchSuccess}")
	private transient String searchSuccess;
	
    /**
	 * 조회 실패 message key
	 */
	@Value("${msg.searchFail}")
	private transient String searchFail;
	
    /**
	 * 처리 성공 message key
	 */
	@Value("${msg.processSuccess}")
	private transient String processSuccess;
	
    /**
	 * 처리 실패 message key
	 */
	@Value("${msg.processFail}")
	private transient String processFail;
	
	/**
	 * 처리 실패 사유 message key
	 */
	@Value("${msg.noticeMsg1}")
	private transient String noticeMsg1;
	
	/**
	 * 처리 성공 message key
	 */
	@Value("${msg.delSuccess}")
	private transient String delSuccess;
	
    /**
	 * 처리 실패 message key
	 */
	@Value("${msg.delFail}")
	private transient String delFail;
	
    /**
	 * 계열사관리자용 service
	 */
	@Autowired
	private transient ServiceCtlManageService serviceCtlManageService;

    /**
	 * 복호화 service
	 */
	@Autowired
	private transient AESDecryptor descryptor;
	
    /**
	 * 기초정보조회용 service
	 */
	@Autowired
	private transient BaseServiceManageService baseServiceManageService;
	
    /**
	 * DtoBuilder
	 */
	@Autowired
	private transient DtoBuilder dtoBuilder;
	
   
	
	/**
	 * 서비스카타로그별 디바이스 목록 조회
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 11
	 * @Method Name : getDevicesByCatalogId
	 */
	@PostMapping ("getDevicesByCatalogId")
	@ApiOperation(value = "서비스 카타로그별 디바이스 목록 조회", response = BaseDto.class)
	public void getDevicesByCatalogId(@RequestBody final Map param) {
		
		final List<Map<String,Object>> svcGrpList = serviceCtlManageService.getDevicesByCatalogId(param);
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(svcGrpList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * 예상 구독료 월조회
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 14
	 * @Method Name : estimateMonthlyFee
	 */	 
	@PostMapping ("estimateMonthlyFee")
	@ApiOperation(value = "예상 구독료 월조회", response = BaseDto.class)
	public void estimateMonthlyFee(@RequestBody final Map param) {
		
		try {
			final Map<String,Object> resultMap = serviceCtlManageService.getDeviceMonthlyFee(param);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, resultMap);
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * 서비스 신청하기. 
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 3. 8
	 * @Method Name : applyService
	 */ 
	@PostMapping ("applyService")
	@ApiOperation(value = "서비스 신청하기", response = BaseDto.class)
	public void applyService(@RequestBody final Map param) {
		
		final Map<String,Object> resultMap = serviceCtlManageService.applyService(param);
		
		dtoBuilder.writeResultPayload(resultMap.get("code").toString(), resultMap.get("message").toString(), resultMap); 
		
	}
	
	/**
	 * C-서비스 이용 현황 - 사업장별 신청 서비스 그룹핑 조회
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 11
	 * @Method Name : getWpcServiceList
	 */
	@PostMapping ("getWpcServiceList")
	@ApiOperation(value = "C-서비스 이용 현황 - 사업장별 신청 서비스 그룹핑 조회", response = BaseDto.class)
	public void getWpcServiceList(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resultList = serviceCtlManageService.getWpcServiceList(param);
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(resultList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * C-서비스 이용 현황 - 사업장별 신청 서비스 전체 조회
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 11
	 * @Method Name : getWpcServiceList
	 */
	@PostMapping ("getWpcServiceListAll")
	@ApiOperation(value = "C-서비스 이용 현황 - 사업장별 신청 서비스 전체 조회", response = BaseDto.class)
	public void getWpcServiceListAll(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resultList = serviceCtlManageService.getWpcServiceListAll(param);
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(resultList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * C-서비스 이용 현황 - 조회 ( 비회원 장바구니 정보 등록 처리)
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 08
	 * @Method Name : getServiceUseList
	 */
	@PostMapping ("getServiceUseList")
	@ApiOperation(value = "C-서비스 이용 현황 - 조회", response = BaseDto.class)
	public void getServiceUseList(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put("wpc", svcGrpList);
		
		final String sessionBasket = (String) param.get("sessionBasket");

		String desParam;
		JSONArray jo;
		
		if(sessionBasket != null && !"".equals(sessionBasket)) {
			
			// 세션에 값이 있다면 세션을 통해 전달된 서비스 장바구니 저장
			desParam = descryptor.decryptText(sessionBasket,secretKey);
			
			jo = (JSONArray) JSONValue.parse(desParam);
			
			final List<Map<String,Object>> dataList =  new ArrayList<>();
			final Map<String, Object> dataMap = new ConcurrentHashMap<>();
    		
    		dataList.addAll(jo);
    		
    		for(int i = 0 ; i < dataList.size(); i++) {
    			
    			dataMap.putAll(dataList.get(i));
    			
    			// 비로그인 장바구니 담기
        		dataMap.put("bsk_itm_yn", "1");
        		dataMap.put("stt_cd", "0");
        		dataMap.put("usr_id", param.get("usr_id"));
        		dataMap.put("user_company_id", param.get("user_company_id"));
        		
    			serviceCtlManageService.applyService(dataMap);
    		}
		}
		
		// 세션에 값이 없다면 조회 만 실행
		final List<Map<String,Object>> resultList = serviceCtlManageService.getServiceUseList(param);
					
		try {
			
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(resultList);
			jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
			
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
			
		}
	}
	
	/**
	 * 서비스 이용 현황 / 서비스 이용 상세 내역
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 18
	 * @Method Name : getServiceUseListDetail
	 */
	@PostMapping ("getServiceUseListDetail")
	@ApiOperation(value = "C-서비스 이용 현황 / 서비스 이용 상세 내역 ", response = BaseDto.class)
	public void getServiceUseListDetail(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resultList = serviceCtlManageService.getServiceUseListDetail(param);
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(resultList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * C-서비스 이용 현황 / 서비스 이용 상세 내역 구독료 납부 현황
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 18
	 * @Method Name : getServiceUseListDetailPayList
	 */
	@PostMapping ("getServiceUseListDetailPayList")
	@ApiOperation(value = "C-서비스 이용 현황 / 서비스 이용 상세 내역 구독료 납부 현황", response = BaseDto.class)
	public void getServiceUseListDetailPayList(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		final List<Map<String,Object>> svcGrpList = baseServiceManageService.getWPCList(param);
		
		param.put(listKey, svcGrpList);
		
		final List<Map<String,Object>> resultList = serviceCtlManageService.getServiceUseListDetailPayList(param);
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(resultList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * C-서비스 이용 현황 - 서비스 변경
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 11
	 * @Method Name : serviceUseChange
	 */
	@PostMapping ("serviceUseChange")
	@ApiOperation(value = "C-서비스 이용 현황 - 서비스 변경", response = BaseDto.class)
	public void serviceUseChange(@RequestBody final Map param) {
		
		final int checked = serviceCtlManageService.serviceUseChange(param);
		
		final Map<String, Object> reParam = new ConcurrentHashMap<>();
		
		reParam.put(cntKey, checked);
		
		if(checked == 1) { 
			dtoBuilder.writeResultPayload("1", processSuccess, reParam);
		}else if(checked == 2) { 
			dtoBuilder.writeResultPayload("0", noticeMsg1, reParam);
		}else {
			dtoBuilder.writeResultPayload("0", processFail, reParam);
		}
	}
	
	/**
	 *  C-서비스 이용 현황 - 서비스 삭제(사용여부 변경)
	 *
	 * @author : hjh
	 * @param : @RequestBody Map param
	 * @return : the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 11
	 * @Method Name : changeApplyService
	 */
	@PostMapping ("changeApplyService")
	@ApiOperation(value = " C-서비스 이용 현황 - 서비스 삭제(사용여부 변경)", response = BaseDto.class)
	public void changeApplyService(@RequestBody final Map param) {
		
		param.put("stt_cd", 9);
		
		final int cudCnt = serviceCtlManageService.changeApplyService(param);
		
		final Map<String, Object> reParam = new ConcurrentHashMap<>();
		
		reParam.put(cntKey, cudCnt);
		
		if(cudCnt >= 1) { 
			dtoBuilder.writeResultPayload("1", delSuccess, reParam);
		}else {
			dtoBuilder.writeResultPayload("0", delFail, reParam);
		}
	}
}
