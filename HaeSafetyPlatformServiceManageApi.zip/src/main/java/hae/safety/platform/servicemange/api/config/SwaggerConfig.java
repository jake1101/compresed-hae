package hae.safety.platform.servicemange.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * Configuration for Swagger
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.AtLeastOneConstructor", "PMD.CommentSize", "PMD.LawOfDemeter"})
@Configuration
@EnableWebMvc
public class SwaggerConfig extends WebMvcConfigurationSupport {

	/**
	 * Swagger configuration
	 *
	 * @author : hjh
	 * @param HttpSecurity http
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : restAPI
	 */	
	@Bean
	public Docket restAPI() {
		return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select()
				.apis(RequestHandlerSelectors.basePackage("hae.safety.platform.servicemange.api"))
//                .paths(PathSelectors.any())
				.paths(PathSelectors.ant("/**/api/**/**")) // /v1/api/** 인 URL들만 필터링
				.build();
	}

	/**
	 * API 정보
	 *
	 * @author : hjh
	 * @param HttpSecurity http
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : apiInfo
	 */	
	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("HAE 안전관제 플랫폼 서비스관리 API").version("0.0.1").description("HAE 안전관제 플랫폼 서비스관리 API")
				.build();
	}

	/**
	 * Swagger configuration
	 *
	 * @author : hjh
	 * @param HttpSecurity http
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : addResourceHandlers
	 */	
	@Override
	protected void addResourceHandlers(final ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources"); 
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/"); 
	}

}
