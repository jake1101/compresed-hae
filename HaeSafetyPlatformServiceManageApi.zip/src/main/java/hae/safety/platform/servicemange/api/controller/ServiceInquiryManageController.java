package hae.safety.platform.servicemange.api.controller;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import hae.safety.platform.servicemange.api.dto.BaseDto;
import hae.safety.platform.servicemange.api.service.BaseServiceManageService;
import hae.safety.platform.servicemange.api.service.ServiceInquiryManageService;
import hae.safety.platform.servicemange.api.util.DtoBuilder;
import hae.safety.platform.servicemange.api.util.RestfulUtilService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;


/**
 * 조회용 Controller
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.LawOfDemeter", "PMD.ShortVariable", "PMD.LongVariable", "PMD.AvoidLiteralsInIfCondition", 
	"PMD.DataflowAnomalyAnalysis", "PMD.AvoidDuplicateLiterals", "PMD.UseCollectionIsEmpty", "PMD.LinguisticNaming", "PMD.AvoidCatchingGenericException"})
@RestController
@RequiredArgsConstructor
//@RequestMapping("api/v1")
@RequestMapping("${apiConfig.path}")
@Api(tags = {"서비스 문의 관리"})
// @CrossOrigin  // CORS 허용 
public class ServiceInquiryManageController {
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceInquiryManageController.class);

    /**
	 * 1:1서비스요청용 service
	 */
	@Autowired
	private ServiceInquiryManageService serviceInquiryManageService;
	
    /**
	 * 기초정보조회용 service
	 */
	@Autowired
	private BaseServiceManageService baseServiceManageService;
	
    /**
	 * 외부서비스 호출욜 service
	 */
	@Autowired
	private RestfulUtilService restfulUtilService;
	
    /**
	 * DtoBuilder
	 */
	@Autowired
	private DtoBuilder dtoBuilder;
	
	/**
	 * 조회 결과 key
	 */
	@Value("${key.listKey}")
	private transient String listKey;
	
	/**
	 * update 결과 key
	 */
	@Value("${key.cntKey}")
	private transient String cntKey;
	
	/**
	 * 조회 성공 message 
	 */
	@Value("${msg.searchSuccess}")
	private transient String searchSuccess;
	
    /**
	 * 조회 실패 message 
	 */
	@Value("${msg.searchFail}")
	private transient String searchFail;
	
	/**
	 * 처리 성공 message 
	 */
	@Value("${msg.processSuccess}")
	private transient String processSuccess;
	
    /**
	 * 처리 실패 message 
	 */
	@Value("${msg.processFail}")
	private transient String processFail;
	
	/**
	 * 삭제 성공 message
	 */
	@Value("${msg.delSuccess}")
	private transient String delSuccess;
	
    /**
	 * 삭제 실패 message
	 */
	@Value("${msg.delFail}")
	private transient String delFail;
	
	/**
	 * 메일 발송 성공 message
	 */
	@Value("${msg.processFail}")
	private transient String sendMailSuccess;
	
	/**
	 * 메일 발송 실패 message 
	 */
	@Value("${msg.processFail}")
	private transient String sendMailFail;
	
	/**
	 * 1:1 서비스 요청 조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 17
	 * @Method Name : getWPCList
	 */
	@PostMapping ("searchHotLine")
	@ApiOperation(value = "1:1 서비스 : 조회", response = BaseDto.class)
	public void searchHotLine(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final List<Map<String,Object>> svcGrpList = serviceInquiryManageService.searchHotLine(param);
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(svcGrpList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * 1:1 서비스 요청 상세 조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 17
	 * @Method Name : searchHotLineDetail
	 */
	@PostMapping ("searchHotLineDetail")
	@ApiOperation(value = "1:1 서비스 : 상세 조회", response = BaseDto.class)
	public void searchHotLineDetail(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final List<Map<String,Object>> svcGrpList = serviceInquiryManageService.searchHotLineDetail(param);
		
		try {
			
			if(svcGrpList != null && svcGrpList.size() > 0) {
				svcGrpList.get(0).put("login_usr_id", param.get("usr_id"));
			}
			
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(svcGrpList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * 1:1 서비스 요청 신규 요청
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 17
	 * @Method Name : addHotLine
	 */
	@PostMapping ("addHotLine")
	@ApiOperation(value = "1:1 서비스 : 신규 등록", response = BaseDto.class)
	public void addHotLine(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final int cudCnt = serviceInquiryManageService.addHotLine(param);
		
		final Map<String, Object> reParam = new ConcurrentHashMap<>();
		
		reParam.put(cntKey, cudCnt);
		
		if(cudCnt >= 1) { 
			dtoBuilder.writeResultPayload("1", processSuccess, reParam);
		}else {
			dtoBuilder.writeResultPayload("0", processFail, reParam);
		}
	}
	
	/**
	 * 1:1 서비스 요청 삭제
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 17
	 * @Method Name : deleteHotLine
	 */
	@PostMapping ("deleteHotLine")
	@ApiOperation(value = "1:1 서비스 : 내역 삭제(답변완료 전)", response = BaseDto.class)
	public void deleteHotLine(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final int cudCnt = serviceInquiryManageService.deleteHotLine(param);
		
		final Map<String, Object> reParam = new ConcurrentHashMap<>();
		
		reParam.put(cntKey, cudCnt);
		
		if(cudCnt >= 1) { 
			dtoBuilder.writeResultPayload("1", delSuccess, reParam);
		}else {
			dtoBuilder.writeResultPayload("0", delFail, reParam);
		}
	}
	
	/**
	 * 1:1 서비스 요청 답변 등록
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 30
	 * @Method Name : resHotLine
	 */
	@PostMapping ("resHotLine")
	@ApiOperation(value = "1:1 서비스 : 답변 등록", response = BaseDto.class)
	public void resHotLine(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final int cudCnt = serviceInquiryManageService.resHotLine(param);
		
		final Map<String, Object> reParam = new ConcurrentHashMap<>();
		
		reParam.put(cntKey, cudCnt);
		
		if(cudCnt >= 1) { 
			dtoBuilder.writeResultPayload("1", processSuccess, reParam);
		}else {
			dtoBuilder.writeResultPayload("0", processFail, reParam);
		}
	}
	
	/**
  	 * 서비스 문의 : 조회
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 03. 30
  	 * @Method Name : getQNAList
  	 */
	@PostMapping ("getQNAList")
	@ApiOperation(value = "서비스 문의 : 조회", response = BaseDto.class)
	public void getQNAList(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final List<Map<String,Object>> svcGrpList = serviceInquiryManageService.getQNAList(param);
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(svcGrpList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
  	 * 서비스 문의 : 답변 등록
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 03. 30
  	 * @Method Name : resQNA
  	 */
	@PostMapping ("resQNA")
	@ApiOperation(value = "서비스 문의 : 답변 등록", response = BaseDto.class)
	public void resQNA(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final int cudCnt = serviceInquiryManageService.resQNA(param);
		
		final Map<String, Object> sendParam = new ConcurrentHashMap<>();
		
		
		String sendMailTextArea = "<p style='font-weight:bold;'>{ANSCTT}</p><hr>문의 제목: {QSTTTL}<p>문의 일시: {QSTDTTEXT}<p>문의 내용: <br>{QSTCTT}";
		final String qstTtl = (String)param.get("qst_ttl");
		final String qstDtText = (String)param.get("qst_dt_text");
		String qstCtt = (String)param.get("qst_ctt");
		qstCtt = qstCtt.replace("\n", "<br>");

		String ansCtt = (String) param.get("ans_ctt");
		ansCtt = ansCtt.replace("\n", "<br>");
		
		sendMailTextArea = sendMailTextArea.replace("{ANSCTT}", ansCtt)
				.replace("{QSTTTL}", qstTtl)
				.replace("{QSTDTTEXT}", qstDtText)
				.replace("{QSTCTT}", qstCtt);
		
		sendParam.put("title", param.get("qst_ttl"));		// 문의 제목
		
		sendParam.put("content", sendMailTextArea);		// 답변 본문
		
		sendParam.put("tos", param.get("qst_usr_eml"));		// 문의자 메일

		final Map<String, Object> reParam = restfulUtilService.callAgentApi("reqEmail", sendParam);
		
		reParam.put(cntKey, cudCnt); 
		
		if(cudCnt >= 1) { 
			dtoBuilder.writeResultPayload("1", processSuccess, reParam);
		}else {
			dtoBuilder.writeResultPayload("0", processFail, reParam);
		}
	}
	
	/**
  	 * 서비스 문의 : 조회
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 03. 30
  	 * @Method Name : getQNAList
  	 */
	@PostMapping ("searchQNADetail")
	@ApiOperation(value = "서비스 문의 : 조회", response = BaseDto.class)
	public void searchQNADetail(@RequestBody final Map param) {
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final List<Map<String,Object>> svcGrpList = serviceInquiryManageService.searchQNADetail(param);
		
		try {
			final ObjectMapper om = new ObjectMapper();
			final String userInJson = om.writeValueAsString(svcGrpList);
			final JSONArray jo = (JSONArray) JSONValue.parse(userInJson);
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, jo);
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
  	 * 서비스 문의 : 답변 메일 발송
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 04. 01
  	 * @Method Name : resEmail
  	 */
	@PostMapping("resEmail")
	@ApiOperation(value = "서비스 문의 답변메일 전송 ", response = BaseDto.class)
	public void resEmail(@RequestBody final Map param){
		
		try {
			
			final Map<String, Object> reParam = restfulUtilService.callAgentApi("reqEmail", param);
			
			dtoBuilder.writeResultPayload("1", sendMailSuccess, reParam);
			
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", sendMailFail, e.getMessage());
		}
		
    }
	
	/**
  	 * 서비스 문의 : 문의 등록
  	 *
  	 * @author : hjh
  	 * @param 
  	 * @return 
  	 * @Date : 2022. 04. 06
  	 * @Method Name : resQNA
  	 */
	@PostMapping ("reqQNA")
	@ApiOperation(value = "서비스 문의 : 문의 등록", response = BaseDto.class)
	public void reqQNA(@RequestBody final Map param) {
		
		final int cudCnt = serviceInquiryManageService.reqQNA(param);
		
		if(cudCnt >= 1) { 
			dtoBuilder.writeResultPayload("1", processSuccess, cudCnt);
		}else {
			dtoBuilder.writeResultPayload("0", processFail, cudCnt);
		}
		
	}
}
