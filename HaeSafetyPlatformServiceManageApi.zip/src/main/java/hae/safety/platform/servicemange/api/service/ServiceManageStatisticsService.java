package hae.safety.platform.servicemange.api.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hae.safety.platform.servicemange.api.mapper.ServiceManageStatisticsMapper;

/**
 * Service
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.AtLeastOneConstructor", "PMD.ImmutableField"})
@Service
@Transactional(rollbackFor = {Exception.class})
public class ServiceManageStatisticsService {
	
	/**
	 * Mapper
	 */
    @Autowired
    private transient ServiceManageStatisticsMapper mapper;
    
    /**
	 * 그룹 관리자 : 통계 자료 : 서비스 구독 통계
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 18
	 * @Method Name : searchSvcSubStatistics
	 */
    public List<Map<String,Object>> searchSvcSubStatistics(final Map param) {
		
		return mapper.searchSvcSubStatistics(param);
	}
    
    /**
	 * 그룹 관리자 : 통계 자료 : 안전 관제 통계
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 19
	 * @Method Name : searchSafetyCtlStatistics
	 */
    public List<Map<String,Object>> searchSafetyCtlStatistics(final Map param) {
		
		return mapper.searchSafetyCtlStatistics(param);
	}
    
    
}
