package hae.safety.platform.servicemange.api;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import hae.safety.platform.servicemange.api.service.BaseServiceManageService;
import hae.safety.platform.servicemange.api.service.RegServiceManageService;


/**
 * 만료서비스 확인 Batch
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.AtLeastOneConstructor", "PMD.AvoidCatchingGenericException", "PMD.LawOfDemeter", "PMD.DataflowAnomalyAnalysis"
	, "PMD.AvoidDuplicateLiterals", "PMD.ImmutableField", "PMD.ShortVariable", "PMD.LongVariable", "PMD.LoggerIsNotStaticFinal", "PMD.ForLoopCanBeForeach"})
@EnableScheduling
@SpringBootApplication
public class CheckedServiceExpDay extends SpringBootServletInitializer {
	
	/**
	 * Logger
	 */
	private transient final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * Service
	 */
	@Autowired
	private transient BaseServiceManageService baseServiceManageService ;
	
	/**
	 * Service
	 */
	@Autowired
	private transient RegServiceManageService regServiceManageService ;

	/**
	 * Batch - 경과된 서비스에 대한 상태 값 업데이트
	 */
	@Scheduled(cron = "${batch.cycle}")
//	@Scheduled(fixedDelay = 10000)
	public void checkedServiceExpDay() throws InterruptedException {
		
		List<Map<String,Object>> expSvc;
		
		final Map<String, Object> dataMap = new ConcurrentHashMap<>();
		
		final int cnt = baseServiceManageService.checkedServiceExpDayCnt();
		
		if(cnt > 0) {
			
			// 경과된 서비스 정보를 가져온다.
			expSvc = baseServiceManageService.checkedServiceExpDaySvcId();
			
			// 경과된 서비스에 대한 상태 값 업데이트 (STT_CD : 11) 
			baseServiceManageService.chgServiceExpDaySttCd(expSvc);
			
			for(int i = 0 ; i < expSvc.size() ; i++ ) {
				
				if (logger.isDebugEnabled()) {
					logger.debug("checkedServiceExpDay : "+ expSvc.get(i));
				}
				
				dataMap.put("saveType", "delete");
				dataMap.put("ptl_rol_cd", expSvc.get(i).get("ptl_rol_cd"));
				dataMap.put("apply_group_id", expSvc.get(i).get("cmp_cd"));
				dataMap.put("apply_wpc_cd", expSvc.get(i).get("wpc_cd"));
				
				//서비스 이용 롤 회수				
				final int resCode = regServiceManageService.serviceAuthorization(dataMap);
				
				if (logger.isDebugEnabled()) {
					logger.debug("checkedServiceExpDay resCode : "+ resCode);
				}
				
				dataMap.clear();
			}
		}
	}
}




