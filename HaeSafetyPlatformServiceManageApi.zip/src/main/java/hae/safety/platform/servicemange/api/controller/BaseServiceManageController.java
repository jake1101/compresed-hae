package hae.safety.platform.servicemange.api.controller;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import hae.safety.platform.servicemange.api.dto.BaseDto;
import hae.safety.platform.servicemange.api.service.BaseServiceManageService;
import hae.safety.platform.servicemange.api.service.RegServiceManageService;
import hae.safety.platform.servicemange.api.util.DtoBuilder;
import hae.safety.platform.servicemange.api.util.DtoJsonArray;
import hae.safety.platform.servicemange.api.util.RestfulUtilService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;


/**
 * 조회용 Controller
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.GuardLogStatement", "PMD.LinguisticNaming", "PMD.CommentSize", "PMD.AvoidFinalLocalVariable", 
	"PMD.LongVariable", "PMD.AvoidCatchingGenericException", "PMD.LawOfDemeter", "PMD.DataflowAnomalyAnalysis", "PMD.AvoidLiteralsInIfCondition"})
@RestController
@RequiredArgsConstructor
//@RequestMapping("api/v1")
@RequestMapping("${apiConfig.path}")
@Api(tags = {"기초 정보 조회"})
// @CrossOrigin  // CORS 허용 
public class BaseServiceManageController {
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BaseServiceManageController.class);
	
	/**
	 * 서비스관리 서비스
	 */
	@Autowired
	private BaseServiceManageService baseServiceManageService;
	
	/**
	 * 서비스신청 서비스
	 */
	@Autowired
	private RegServiceManageService regServiceManageService;
	
	/**
	 * DtoBuilder
	 */
	@Autowired
	private DtoBuilder dtoBuilder;
	
	
	/**
	 * return data
	 */
	@Autowired
	private DtoJsonArray dtoJsonArray;
	
	
//	@PersistenceContext
//	private EntityManager entityManager;
	
	/**
	 * 조회 성공 message key
	 */
	@Value("${msg.searchSuccess}")
	private transient String searchSuccess;
	
    /**
	 * 조회 실패 message key
	 */
	@Value("${msg.searchFail}")
	private transient String searchFail;
	
	/**
	 * remote API 호출
	 */
	@Autowired
	private RestfulUtilService restfulUtilService;
	
	/**
	 * 계열사 정보 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : getWPCList
	 */
	@PostMapping ("getCompanyList")
	@ApiOperation(value = "계열사 정보 조회", response = BaseDto.class)
	public void getCompanyList(@RequestBody final Map param) {
		
		final List<Map<String,Object>> companyList = baseServiceManageService.getCompanyList(param);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, dtoJsonArray.toJSONArray(companyList));
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * 권한별 사업자 정보 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list 
	 * @Date : 2022. 02. 24
	 * @Method Name : getWPCList
	 */
	@PostMapping ("getWPCList")
	@ApiOperation(value = "권한별 사업자 정보 조회", response = BaseDto.class)
	public void getWPCList(@RequestBody final Map param) {
		
		List<Map<String,Object>> svcGrpList;
		svcGrpList = baseServiceManageService.getWPCList(param);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, dtoJsonArray.toJSONArray(svcGrpList));
		} catch (JsonProcessingException e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * 비계열사 회원가입
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list 
	 * @Date : 2022. 02. 24
	 * @Method Name : joinMemberAction
	 */
	@PostMapping("joinMemberAction")
	public Map<String,Object> joinMemberAction(@RequestBody final Map param){
		return restfulUtilService.callRaycomApi("has/if/company/insert", param);
    }
	
	/**
	 * initConersSafetyPlatform
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list 
	 * @throws UnsupportedEncodingException 
	 * @Date : 2022. 04. 22
	 * @Method Name : initConersSafetyPlatform
	 */
	@PostMapping("initConersSafetyPlatform")
	public void initConersSafetyPlatform(@RequestBody final Map param) throws UnsupportedEncodingException{
		
		final String getParam;
		
		if(null == param.get("usr_id") || "".equals((String)param.get("usr_id"))) {
			param.put("usr_id", "USRIDBLANK");
		}
		
		getParam = baseServiceManageService.initConersSafetyPlatform(param);
		
		
//		final String inItParam = Base64.getEncoder().encodeToString(getParam.getBytes(StandardCharsets.UTF_8));
			
		final ObjectMapper mapper = new ObjectMapper();
		
		try {

			final Map<String, String> map = mapper.readValue(getParam, Map.class);
			
			final String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(map);

			final String inItParam = Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8)); 
				
//			final byte[] test2 = Base64.getDecoder().decode(inItParam);
//			if(LOGGER.isDebugEnabled()) {
//				LOGGER.debug("initConersSafetyPlatform Encoder : "+ inItParam);
//				LOGGER.debug("initConersSafetyPlatform Decoder : "+ new String(test2, StandardCharsets.UTF_8));
//			}
			
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, inItParam);
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
    }
}
