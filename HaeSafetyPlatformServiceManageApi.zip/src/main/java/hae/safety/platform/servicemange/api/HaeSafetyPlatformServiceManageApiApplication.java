package hae.safety.platform.servicemange.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * SpringBootApplication
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.AtLeastOneConstructor"})
@SpringBootApplication
public class HaeSafetyPlatformServiceManageApiApplication {

	/** Password Encoder
	 * 
	 * @param url
	 * @param param
	 * @return
	 */
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
	/** main
	 * 
	 * @param url
	 * @param param
	 * @return
	 */
	public static void main(final String[] args) {
		SpringApplication.run(HaeSafetyPlatformServiceManageApiApplication.class, args);
	}
}
