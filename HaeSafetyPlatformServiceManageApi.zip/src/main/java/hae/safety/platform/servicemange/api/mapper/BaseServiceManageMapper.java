package hae.safety.platform.servicemange.api.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

/**
 * 기초정보 조회용 Mapper Interface
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize"})
//@Component
@Mapper
public interface BaseServiceManageMapper {
	
    /**
	 * 계열사 정보 조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : CheckedServiceExpDay
	 */
	List<Map<String,Object>> getCompanyList(Map param);
	
    /**
	 * 사업장 정보 조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : CheckedServiceExpDay
	 */
    List<Map<String,Object>> getWPCList(Map param);
    
    /**
	 * 서비스 만료일 경과 여부 확인
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 06
	 * @Method Name : CheckedServiceExpDay
	 */
    int checkedServiceExpDayCnt();
    
    /**
	 * 서비스 만료일 경과 SVC_ID 가져온다.
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 06
	 * @Method Name : CheckedServiceExpDay
	 */
    List<Map<String,Object>> checkedServiceExpDaySvcId();
    
    /**
	 * 서비스 만료일 경과 건 만료 처리 SVC_REQ / STT_CD (11) UPDATE
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 06
	 * @Method Name : CheckedServiceExpDay
	 */
    int chgServiceExpDaySttCd(List<Map<String, Object>> expSvcId);
    
    /**
	 * initConersSafetyPlatform
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list 
	 * @Date : 2022. 04. 22
	 * @Method Name : initConersSafetyPlatform
	 */
    String initConersSafetyPlatform(Map param);
    
}
