package hae.safety.platform.servicemange.api.dto;

import lombok.Data;

/**
 * 서비스 결과 리턴용 DTO
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */

@Data
public class BaseDto {

    /**
	 * 서비스결과 데이터
	 */
	private String result;
	
    /**
	 * 서비스 실행 결과 메세지
	 */
    private String message;
    
    /**
	 * 조회 param
	 */
    private String search;
    
    /**
	 * 결과 건수
	 */
    private String rownum;
    
    /**
	 * 변경 건수
	 */
    private int cudCnt;
    
}
