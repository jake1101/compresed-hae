package hae.safety.platform.servicemange.api.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 그룹관리자용 Mapper Interface
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.TooManyMethods"})
//@Component
@Mapper
public interface RegServiceManageMapper { 
	
    /**
	 * 등록서비스그룹전체조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : findAll
	 */
	@Select("SELECT * FROM CORNERS.SVC_GRP")
    List<Map<String,Object>> findAll();
    
	/**
	 * 등록서비스 사용상태 변경
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : updateServiceUseYn
	 */
	@Insert("INSERT INTO CORNERS.rollbacktesttable (column1, column2) values (#{column1}, #{column2})")
	void rollbacktesttable(@Param("column1") String column1, @Param("column2") String column2);
	
	/**
	 * 등록서비스검색조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : findRegSafetyServiceList
	 */
    List<Map<String,Object>> findRegSafetyServiceList(Map param);
    
    /**
	 * 등록서비스 사용상태 변경
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : updateServiceUseYn
	 */
    int updateServiceUseYn(Map param);
    
    /**
	 * 서비스 신청 관리 : 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprList
	 */
    List<Map<String,Object>> getServiceAprList(Map param);
    
    /**
	 * 서비스 신청 관리 : 상세조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprListDetail
	 */
    List<Map<String,Object>> getServiceAprListDetail(Map param);
    
    /**
	 * 서비스 신청 관리 : 서비스 이용 장비 리스트
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprListDvcDetail
	 */
    List<Map<String,Object>> getServiceAprListDvcDetail(Map param);
    
    /**
   	 * 서비스 신청 관리 : 신청 테이블 서비스 상테 업데이트
   	 *
   	 * @author : hjh
   	 * @param @RequestBody Map param
   	 * @return the JSONArray : code String, message String,  result_data list
   	 * @Date : 2022. 03. 31
   	 * @Method Name : checkedChgApr
   	 */
     int checkedChgApr(Map param);
    
    /**
	 * 서비스 신청 관리 : 변경신청 상세조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprChgListDetail
	 */
    List<Map<String,Object>> getServiceAprChgListDetail(Map param);
    
    /**
	 * 서비스 신청 관리 : 변경 신청 장비 리스트
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprChgListDvcDetail
	 */
    List<Map<String,Object>> getServiceAprChgListDvcDetail(Map param);
    
    /**
	 * 서비스 신청 관리 : 기 등록 여부 확인
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : checkedService
	 */
    int checkedService(Map param);
    
    /**
	 * 서비스 신청 관리 : 신청 테이블 서비스 상테 업데이트
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : updateSvcReq
	 */
    int updateSvcReq(Map param);
    
    /**
	 * 서비스 신청 관리 : 승인테이블 등록
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : insertSvcApr
	 */
    int insertSvcApr(Map param);
    
    /**
	 * 서비스 신청 관리 : 서비스 테스트 테이블 등록
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : insertSvcTst
	 */
    int insertSvcTst(Map param);
    
    /**
	 * 서비스 신청 관리 : 서비스 구독 테이블 등록
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : insertSvcSst
	 */
    int insertSvcSst(Map param);
    
    /**
	 * 서비스 신청 관리 : 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 24
	 * @Method Name : grpAdmServiceUseList
	 */
    List<Map<String,Object>> grpAdmServiceUseList(Map param);
    
    /**
	 * 구독료 납부 관리 : 구독료 관리 목록 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 25
	 * @Method Name : serviceSstList
	 */
    List<Map<String,Object>> serviceSstList(Map param);
    
    /**
	 * 구독료 납부 관리 : 구독료 관리 목록 상세 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 25
	 * @Method Name : serviceSstListDetail
	 */
    List<Map<String,Object>> serviceSstListDetail(Map param);
    
    /**
	 * 서비스 구독료 테이블 저장
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 25
	 * @Method Name : serviceSstListDetail
	 */
    int insertFeePmt(Map param);
    
    /**
	 * 구독료 납부 관리 : 구독료 관리 목록 상세 조회 : 날짜 수정
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 25
	 * @Method Name : serviceSstListDetailChgDay
	 */
    int serviceSstListDetailChgDay(Map param);
    
    /**
	 * 구독료 납부 관리 : 구독료 관리 목록 상세 조회 : 납부 확인
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 25
	 * @Method Name : serviceSstListDetailChgFee
	 */
    int serviceSstListDetailChgFee(Map param);
    
    /**
	 * 구독료 통계 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 25
	 * @Method Name : serviceSstListDetailChgFee
	 */
    List<Map<String,Object>>  getMonFeeStatistics(Map param);
    
    /**
	 * 서비스 신청 관리 : 변경 승인 : 서비스 변경 내역 저장
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 01
	 * @Method Name : addSvcChgHst
	 */
    int addSvcChgHst(Map param);
    
    /**
   	 * 서비스 신청 관리 : 변경 승인 : 서비스 변경 내역 저장 (신청장비리스트)
   	 *
   	 * @author : hjh
   	 * @param @RequestBody Map param
   	 * @return the JSONArray : code String, message String,  result_data list
   	 * @Date : 2022. 04. 01
   	 * @Method Name : addDvcChgHst
   	 */
	int addDvcChgHst(Map param);
       
	/**
   	 * 서비스 신청 관리 : 변경 승인 : 구독 기간 변경
   	 *
   	 * @author : hjh
   	 * @param @RequestBody Map param
   	 * @return the JSONArray : code String, message String,  result_data list
   	 * @Date : 2022. 04. 01
   	 * @Method Name : serviceChgDt
   	 */
	int serviceChgDt(Map param);
	
	/**
   	 * 서비스 신청 관리 : 변경 승인 : 구독 기간 변경 : 서비스 중단
   	 *
   	 * @author : hjh
   	 * @param @RequestBody Map param
   	 * @return the JSONArray : code String, message String,  result_data list
   	 * @Date : 2022. 04. 01
   	 * @Method Name : serviceChgSvcReqSttCd
   	 */
	int serviceChgSvcReqSttCd(Map param);
	
	/**
   	 * 서비스 신청 관리 : 변경 승인 : 구독 기간 변경 : 이용 장비 수량 변경
   	 *
   	 * @author : hjh
   	 * @param @RequestBody Map param
   	 * @return the JSONArray : code String, message String,  result_data list
   	 * @Date : 2022. 04. 01
   	 * @Method Name : serviceChgSvcDvc
   	 */
	int serviceChgSvcDvc(Map param);
	
	/**
   	 * 서비스 신청 관리 : 변경 승인 : 구독 기간 변경 : 최종 월 구독료 변경
   	 *
   	 * @author : hjh
   	 * @param @RequestBody Map param
   	 * @return the JSONArray : code String, message String,  result_data list
   	 * @Date : 2022. 04. 01
   	 * @Method Name : serviceChgSvcAprMonFee
   	 */
	int serviceChgSvcAprMonFee(Map param);
	
	/**
   	 * 서비스 신청 관리 : 변경 승인 : 구독 기간 변경 : 변경 처리 완료
   	 *
   	 * @author : hjh
   	 * @param @RequestBody Map param
   	 * @return the JSONArray : code String, message String,  result_data list
   	 * @Date : 2022. 04. 01
   	 * @Method Name : serviceChgSvcReqAp
   	 */
	int serviceChgSvcReqApr(Map param);
	
	/**
   	 * 서비스 신청 관리 : 변경 승인 : 구독 기간 변경 : 변경 처리 완료
   	 *
   	 * @author : hjh
   	 * @param @RequestBody Map param
   	 * @return the JSONArray : code String, message String,  result_data list
   	 * @Date : 2022. 04. 04
   	 * @Method Name : serviceChgSvcReqAprSubFee
   	 */
	int serviceChgSvcReqAprSubFee(Map param);
	
}
