package hae.safety.platform.servicemange.api.config;

import org.springframework.boot.web.servlet.view.MustacheViewResolver;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Configuration for View Resolver
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.AtLeastOneConstructor", "PMD.CommentSize"})
@Configuration
public class WebMvcConfig implements WebMvcConfigurer{  

	
	/**
	 * View Resolver configuration
	 *
	 * @author : hjh
	 * @param HttpSecurity http
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : configureViewResolvers
	 */	
  @Override
  public void configureViewResolvers(final ViewResolverRegistry registry) {
      final MustacheViewResolver resolver = new MustacheViewResolver();

      resolver.setCharset("UTF-8");
      resolver.setContentType("text/html;charset=UTF-8");
      resolver.setPrefix("classpath:/templates/");
      resolver.setSuffix(".html");

      registry.viewResolver(resolver);
  }
}
