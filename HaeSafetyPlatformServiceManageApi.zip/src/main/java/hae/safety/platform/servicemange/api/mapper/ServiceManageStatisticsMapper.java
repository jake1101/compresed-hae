package hae.safety.platform.servicemange.api.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

/**
 * 1:1 서비스요청용 Mapper Interface
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize"})
@Mapper
public interface ServiceManageStatisticsMapper {
 
	/**
	 * 그룹 관리자 : 통계 자료 : 서비스 구독 통계
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 18
	 * @Method Name : searchSvcSubStatistics
	 */
    List<Map<String,Object>> searchSvcSubStatistics(Map param);
    
    /**
	 * 그룹 관리자 : 통계 자료 : 안전 관제 통계
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 19
	 * @Method Name : searchSafetyCtlStatistics
	 */
    List<Map<String,Object>> searchSafetyCtlStatistics(Map param);
}
