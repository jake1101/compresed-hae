package hae.safety.platform.servicemange.api.mapper;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Mapper;

/**
 * 계열사관리자용 Mapper Interface
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize"})
//@Component
@Mapper
public interface ServiceCtlManageMapper {
    
    /**
	 * 카테고리별 디바이스 조회 
	 *
	 * @author : 
	 * @param param the param
	 * @Date : 2022. 2. 18
	 * @Method Name : getDevicesByCatalogId
	 */ 
	List<Map<String,Object>> getDevicesByCatalogId(Map param);
    
    /**
   	 *  예상 월 구독료 조회
   	 *
   	 * @author : 
   	 * @param param the param
   	 * @Date : 2022. 3. 14
   	 * @Method Name : getDeviceMonthlyFee
   	 */ 
	List<Map<String,Object>> getDeviceMonthlyFee(Map param);
    
    /**
	 * 기신청 서비스 건수 조회 
	 *
	 * @author : 
	 * @param param the param
	 * @Date : 2022. 3. 8
	 * @Method Name : getExistingServiceCnt
	 */ 
	int getExistingServiceCnt(Map param);
    
    /**
	 * svc_id 채번 
	 *
	 * @author : 
	 * @param param the param
	 * @Date : 2022. 3. 8
	 * @Method Name : getNextSVCId
	 */ 
    int getNextSVCId(Map param);
    
    /**
	 * svc_req 등록 
	 *
	 * @author : 
	 * @param param the param
	 * @Date : 2022. 3. 8
	 * @Method Name : insertSVCREQ
	 */ 
    int insertSVCREQ(Map param);
    
    /**
	 * svc_dvc 등록 
	 *
	 * @author : 
	 * @param param the param
	 * @Date : 2022. 3. 8
	 * @Method Name : insertSVCDVC
	 */ 
    int insertSVCDVC(Map param);

	/**
	 * C-서비스 이용 현황 - 사업장별 신청 서비스 그룹핑 조회
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 11
	 * @Method Name : getWpcServiceList
	 */
    List<Map<String,Object>> getWpcServiceList(Map param);
    
    /**
	 * C-서비스 이용 현황 - 사업장별 신청 서비스 전체 조회
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 17
	 * @Method Name : getWpcServiceListAll
	 */
    List<Map<String,Object>> getWpcServiceListAll(Map param);
    
    /**
	 * C-서비스 이용 현황 - 조회
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 11
	 * @Method Name : getServiceUseList
	 */
    List<Map<String,Object>> getServiceUseList(Map param);
    
    /**
	 *  C-서비스 이용 현황 - 서비스 삭제(사용여부 변경)
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 11
	 * @Method Name : changeApplyService
	 */
    int changeApplyService(Map param);
    
	/**
	 * C-서비스 이용 현황 / 서비스 이용 상세 내역
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 18
	 * @Method Name : getServiceUseListDetail
	 */
    List<Map<String,Object>> getServiceUseListDetail(Map param);
    
	/**
	 * 서비스 이용 장비 리스트
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 18
	 * @Method Name : getServiceUseDeviceListDetail
	 */
    List<Map<String,Object>> getServiceUseDeviceListDetail(Map param);
 
	/**
	 * 월 서비스 이용 금액
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 18
	 * @Method Name : getServiceUseListDetailPayList
	 */
    List<Map<String,Object>> getServiceUseListDetailPayList(Map param);
    
    /**
   	 * C-서비스 이용 현황 - 서비스 신청 변경
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 18
   	 * @Method Name : serviceUseChange
   	 */
    int serviceUseChange(Map param);
    
    /**
   	 * svc_chg_req : chg_req_seq 채번
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 18
   	 * @Method Name : getNextCHGREQID
   	 */
    int getNextCHGREQID(Map param);
    
    /**
   	 * C-서비스 이용 현황 - 서비스 신청 변경 등록
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 18
   	 * @Method Name : insertSvcChgReq
   	 */
    int insertSvcChgReq(Map param);
    
    /**
   	 * DvcChqReq 등록
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 18
   	 * @Method Name : getNextCHGREQID
   	 */
    int insertDvcChqReq(Map param);
    
    /**
   	 * 장바구니 장비 변경
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 18
   	 * @Method Name : getNextCHGREQID
   	 */
    int changeSvcDvc(Map param);
    
    /**
   	 *  서비스 변경 요청 테이블 select chg_req_seq
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 04. 18
   	 * @Method Name : getSvcChgReqSeq
   	 */
    int getSvcChgReqSeq(Map param);
    
    /**
   	 *  서비스 변경 요청 테이블 상태값 변경
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 18
   	 * @Method Name : getNextCHGREQID
   	 */
    int serviceUseChangeSvcChgReq(Map param);
    
}
