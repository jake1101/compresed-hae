package hae.safety.platform.servicemange.api.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hae.safety.platform.servicemange.api.mapper.ServiceCtlManageMapper;

/**
 * 계열사관리자용 Service
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.LoggerIsNotStaticFinal", "PMD.AvoidLiteralsInIfCondition", "PMD.LawOfDemeter", "PMD.UnusedAssignment"
	, "PMD.AvoidDuplicateLiterals", "PMD.NcssCount", "PMD.SwitchDensity", "PMD.ImmutableField", "PMD.SimpleDateFormatNeedsLocale", "PMD.DataflowAnomalyAnalysis"
	, "PMD.ShortVariable", "PMD.LongVariable", "PMD.AtLeastOneConstructor", "PMD.ModifiedCyclomaticComplexity", "PMD.ExcessiveMethodLength", "PMD.ModifiedCyclomaticComplexity"})
@Service
@Transactional(rollbackFor = {Exception.class})
public class ServiceCtlManageService {
	
	/**
	 * Logger
	 */
	private transient final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 계열사관리자용 Mapper
	 */
    @Autowired
    private transient ServiceCtlManageMapper mapper;
    
    /**
	 * 카테고리별 디바이스 조회 
	 *
	 * @author : 
	 * @param param the param
	 * @Date : 2022. 2. 18
	 * @Method Name : getDevicesByCatalogId
	 */ 
    public List<Map<String,Object>> getDevicesByCatalogId(final Map param) {
		
		return mapper.getDevicesByCatalogId(param);
	}
    
    /**
   	 *  예상 월 구독료 조회
   	 *
   	 * @author : 
   	 * @param param the param
   	 * @Date : 2022. 3. 14
   	 * @Method Name : getDeviceMonthlyFee
   	 */ 
    public Map<String,Object> getDeviceMonthlyFee(final Map param) {
		
    	
    	int estimatedMonthlyFee = 0;
		
    	final ArrayList devices = (ArrayList)param.get("dvc_list");
		
    	final Map<String,Object> resultMap = new ConcurrentHashMap<>();
		
    	final List<Map<String,Object>> list =  mapper.getDeviceMonthlyFee(param);
		
		if (list != null && !list.isEmpty()) {
			
			for (int i = 0; i < devices.size(); i++) { // NOPMD by 9396368 on 22. 4. 11. 오후 3:37, can't use foreach
				
				final HashMap<String, Object> device = (HashMap<String, Object>)devices.get(i);
				
				for (final Map<String, Object> row : list) {
					
					if((Integer)device.get("dvc_id") == ((Long)row.get("dvc_id")).intValue()) {
						
						estimatedMonthlyFee += (Integer)device.get("qtt") * (Integer)row.get("mon_fee") * (Integer)param.get("sst_trm");
						break;
					}
				}
			}
		}
		
		resultMap.put("estimatedMonthlyFee", estimatedMonthlyFee);
			
		return resultMap;
    }
    
    /**
   	 *  서비스 신청하기
   	 *
   	 * @author : 
   	 * @param param the param
   	 * @Date : 2022. 3. 14
   	 * @Method Name : applyService
   	 */ 
    public Map<String,Object> applyService(final Map param) {
		
    	final Map<String, Object> resultMap = new ConcurrentHashMap<>();
    	
		//1. 기등록 서비스 존재여부 조회 (신청하기이면)
		if (isExistingService(param) && "1".equals(param.get("stt_cd"))) {
			resultMap.put("message", "이미 신청된 서비스가 있습니다.");
			resultMap.put("code", "0");
		}  else {
			
//			Map<String,Object> userInfo = Auth.getCurrentUserInfo();
//			param.put("usr_id", userInfo.get("usr_id"));

			//2. svc_id 채번
			final int nextSVCId = mapper.getNextSVCId(param);
			param.put("svc_id", nextSVCId);
			
			//3. svc_req 등록
			mapper.insertSVCREQ(param);
			
			//4. svc_dvc 등록 (멀티)
			mapper.insertSVCDVC(param);
			
			resultMap.put("message", "정상 처리 되었습니다.");
			resultMap.put("code", "1");
			resultMap.put("nextSVCId", nextSVCId);
		}
		
		return resultMap;
		
	}
    
    /**
	 * 기신청 서비스 존재여부 조회 
	 *
	 * @author : 
	 * @param param the param
	 * @Date : 2022. 3. 8
	 * @Method Name : isExistingService
	 */ 
	private boolean isExistingService(final Map param) {
		
		final int cnt = mapper.getExistingServiceCnt(param);
		
		return cnt > 0;
		
	}
	
	/**
	 * C-서비스 이용 현황 - 사업장별 신청 서비스 그룹핑 조회
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 11
	 * @Method Name : getWpcServiceList
	 */
    public List<Map<String,Object>> getWpcServiceList(final Map param) {
		
		return mapper.getWpcServiceList(param);
	}
    
    /**
	 * C-서비스 이용 현황 - 사업장별 신청 서비스 전체 조회
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 17
	 * @Method Name : getWpcServiceListAll
	 */
    public List<Map<String,Object>> getWpcServiceListAll(final Map param) {
		
		return mapper.getWpcServiceListAll(param);
	}
    
    /**
	 * C-서비스 이용 현황 - 조회
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 11
	 * @Method Name : getServiceUseList
	 */
    public List<Map<String,Object>> getServiceUseList(final Map param) {
		
		return mapper.getServiceUseList(param);
	}
    

	/**
	 * C-서비스 이용 현황 / 서비스 이용 상세 내역
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 18
	 * @Method Name : getServiceUseListDetail
	 */
    public List<Map<String,Object>> getServiceUseListDetail(final Map param) {
    	
    	final Map<String, Object> resultMap = new ConcurrentHashMap<>();
    	
    	// 서비스 이용 내역 상세
    	resultMap.put("serviceUseListDetail", mapper.getServiceUseListDetail(param));
    	// 서비스 이용 장비 리스트
    	resultMap.put("serviceUseDeviceListDetail", mapper.getServiceUseDeviceListDetail(param));
    	// 월 서비스 이용 금액
    	resultMap.put("serviceUseListDetailPayList", mapper.getServiceUseListDetailPayList(param));
    	
    	final List<Map<String,Object>> resultList = new ArrayList<>();
    	
    	resultList.add(resultMap);
    	
		return resultList;
	}
    

	/**
	 * C-서비스 이용 현황 / 서비스 이용 상세 내역 구독료 납부 현황
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 18
	 * @Method Name : getServiceUseListDetailPayList
	 */
    public List<Map<String,Object>> getServiceUseListDetailPayList(final Map param) {
		
		return mapper.getServiceUseListDetailPayList(param);
	}
    
    /**
   	 * C-서비스 이용 현황 - 서비스 변경 신청
   	 *
   	 * @author : hjh
   	 * @param 
   	 * @return 
   	 * @Date : 2022. 03. 18
   	 * @Method Name : serviceUseChange
   	 */
       public int serviceUseChange(final Map param) { 
       	
       	int checked = 0;
       	
       	// 현재 상태 값
       	final String sttCd = (String) param.get("stt_cd"); 
       	// 요청 상태 값
       	final String status = (String) param.get("status_code");

       	switch(status) {
	        case "0" : // 신청장바구니 없음 상태 일 경우 장바구니를 업데이트 한다.
	        	
	        	// Add this for performance
	        	if (logger.isDebugEnabled()) {
	        		logger.debug("=========>>>" + status);
	        	}
	        	
//	        	if (isExistingService(param)) {
//        			// 중복 저장으로 신청 불가
//	        		checked = 2;
//        		}else {
//        			param.put("stt_cd", status); // 신청 중 상태
//    	        	
//    	        	mapper.serviceUseChange(param);
//    	        	
//    	        	checked = mapper.changeSvcDvc(param);
//        		}
	        	
	        	param.put("stt_cd", status); // 신청 중 상태
	        	
	        	mapper.serviceUseChange(param);
	        	
	        	checked = mapper.changeSvcDvc(param);
	        	
	            break;
        	case "1" : // 신청 장바구니 등록 상태 일 경우 상태 값만 1로 변경한다.
	        	
        		if (isExistingService(param)) {
        			// 중복 저장으로 신청 불가
        			checked = 2;
        		}else {
        			param.put("stt_cd", status); // 신청완료 / 미승인 상태
    	        	
    	        	mapper.serviceUseChange(param); // 입력받은 값으로 업데이트
    	        	
    	        	checked = mapper.changeSvcDvc(param);
        		}
	        	
	        	break;
        	case "5": // 변경일 경우 현재 상태에 따라 데이터를 생성 or 수정 한다.
	        	
	        	// 신청 완료 전 상태는 업데이트만 진행 한다.
	        	if("1".equals(sttCd)) {
	        		
		        	mapper.serviceUseChange(param); // 입력받은 값으로 업데이트
		        	checked = mapper.changeSvcDvc(param);
	        		
	        	}else {
	        		// 신청 테이블 상태 변경
		        	//param.put("stt_cd", status);
		        	
		        	// 1. SVC_REQ (stt_cd : 5) 변경요청 상태로 변경
		        	//int svcReqChk =  mapper.serviceUseChange(param);
		        	
		        	//2. svc_chg_req : chg_req_seq 채번
	        		final int nextChgReqId = mapper.getNextCHGREQID(param);
					
					param.put("chg_req_seq", nextChgReqId); // 변경 요청 seq set
					param.put("apr_yn", "0"); // 미승인 상태
//		        	param.put("stt_cd", sttCd); // 변경 요청 테이블 기존 값 등록
					param.put("stt_cd", "0"); // 정상 상태 등록
		        	
					//3. SvcChgReq 등록
					mapper.insertSvcChgReq(param);
					
					final ArrayList devices = (ArrayList)param.get("dvc_list");
					
					HashMap<String, Object> device;
					
					for (int i = 0; i < devices.size(); i++) {  // NOPMD by 9396368 on 22. 4. 11. 오후 3:37, can't use foreach
						
						device = (HashMap<String, Object>)devices.get(i);
						
						device.put("chg_req_seq", nextChgReqId);
						
					}
					
					param.put("dvc_list", devices);
					
					//4. DvcChqReq 등록 (멀티)
					final int svcDvcChk = mapper.insertDvcChqReq(param);
		        	
		        	// 승인 완료 2, 개시 대기 3, 이용중 4	        	
//		        	if(sttCd == "2" || sttCd == "3" || sttCd == "4") {
//		        		apr_yn  승인여부 0
//		        	}
					checked = checkedService(svcDvcChk);
	        	}
				
	            break;
	        case "8": // 취소 일 경우 변경 신청 취소 신청 취소 인지 판단하여 처리 한다.
	        	// 신청 테이블 요청 상태로 변경
	        	param.put("stt_cd", status);
	        	
	        	// 신청 취소일경우 T SVC_REQ -> C STT_CD 를 취소(8)로 변경한다.
	        	if("1".equals(sttCd)) {
	        		checked = mapper.serviceUseChange(param);
	        	// 변경 취소일 경우 T SVC_CHG_REQ -> C STT_CD 를 취소(8)로 변경한다.
	        	}else {
	        		
	        		// select chg_req_seq
	        		final int chgReqSeq = mapper.getSvcChgReqSeq(param);
	        		
	        		param.put("chg_req_seq", chgReqSeq);
	        		
	        		checked = mapper.serviceUseChangeSvcChgReq(param);
	        	}
	        	break;     
	        case "9": // 삭제 ( stt_cd 9) 일 경우 상태 값만 9로 변경한다.
	        	// 신청 테이블 상태 변경
	        	param.put("stt_cd", status);
	        	checked = mapper.serviceUseChange(param);
	        	break;
	        	
	        //TODO: default 구문필요
	        default : 
	        	checked = 0;
	        	break;
       	}
       	
       	//신청 -> 승인(개시대기) : 1 -> 2
       	// table svc_req , col stt_cd val = 2 , table svc_tst insert row
       	
       	//승인(개시대기) -> 변경 or 테스트 -> 1 -> 5 or 3
       	// table svc_req , col stt_cd val = 2 , table svc_tst insert row
       	
       	//테스트 -> 구독 : 3 -> 4
       	//장바구니 -> 삭제 : 99 -> 9
   		
   		return checked;
   	}
    
    /**
	 *  C-서비스 이용 현황 - 서비스 삭제(사용여부 변경)
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 03. 11
	 * @Method Name : changeApplyService
	 */
    public int changeApplyService(final Map param) {
		
		return mapper.changeApplyService(param);
	}
    
    /**
	 *  C-서비스 이용 현황 - 서비스 정상 처리 여부
	 *
	 * @author : hjh
	 * @param 
	 * @return 
	 * @Date : 2022. 04. 18
	 * @Method Name : changeApplyService
	 */
    public int checkedService(final int cnt) {
    	
    	int checked = 0;
    	
    	if(cnt > 0 ) {
    		checked = 1;
    	}
		
		return checked;
	}
}
