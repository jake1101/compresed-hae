package hae.safety.platform.servicemange.api;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * SpringBootServletInitializer
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.AtLeastOneConstructor"})
@SpringBootApplication
public class ServletInitializer extends SpringBootServletInitializer {

	/**
	 * SpringApplicationBuilder
	 * @param url
	 * @param param
	 * @return
	 */
	@Override
	protected SpringApplicationBuilder configure(final SpringApplicationBuilder application) {
		return application.sources(HaeSafetyPlatformServiceManageApiApplication.class);
	}
}
