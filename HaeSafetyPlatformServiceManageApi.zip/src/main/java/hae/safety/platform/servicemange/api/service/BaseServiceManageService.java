package hae.safety.platform.servicemange.api.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hae.safety.platform.servicemange.api.mapper.BaseServiceManageMapper;

/**
 * 기조정보 조회용 Service
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.AtLeastOneConstructor", "PMD.ImmutableField"})
@Service
@Transactional(rollbackFor = {Exception.class})
public class BaseServiceManageService {
	
	/**
	 * 기조정보 조회용 Mapper
	 */
    @Autowired
    private transient BaseServiceManageMapper mapper;
    
    /**
	 * 계열사 정보 조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : CheckedServiceExpDay
	 */
    public List<Map<String,Object>> getCompanyList(final Map param) {
		return mapper.getCompanyList(param);
	}
    
    /**
	 * 사업장 정보 조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : CheckedServiceExpDay
	 */
    public List<Map<String,Object>> getWPCList(final Map param) {
		return mapper.getWPCList(param);
	}
    
    /**
	 * 서비스 만료일 경과 여부 확인
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 06
	 * @Method Name : CheckedServiceExpDay
	 */
    public int checkedServiceExpDayCnt() {
		return mapper.checkedServiceExpDayCnt();
    }
    
    /**
	 * 서비스 만료일 경과 SVC_ID 가져온다.
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 06
	 * @Method Name : CheckedServiceExpDay
	 */
    public List<Map<String,Object>> checkedServiceExpDaySvcId() {
		return mapper.checkedServiceExpDaySvcId();
    }
    
    /**
	 * 서비스 만료일 경과 건 만료 처리 SVC_REQ / STT_CD (11) UPDATE
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 06
	 * @Method Name : CheckedServiceExpDay
	 */
    public int chgServiceExpDaySttCd(final List<Map<String, Object>> expSvcId) {
		return mapper.chgServiceExpDaySttCd(expSvcId);
    }
    
    /**
	 * initConersSafetyPlatform
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list 
	 * @Date : 2022. 04. 22
	 * @Method Name : initConersSafetyPlatform
	 */
    public String initConersSafetyPlatform(final Map param) {
		return mapper.initConersSafetyPlatform(param);
    }
	
}
