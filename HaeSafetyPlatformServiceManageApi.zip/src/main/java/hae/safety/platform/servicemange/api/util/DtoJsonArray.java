package hae.safety.platform.servicemange.api.util;

import java.util.List;
import java.util.Map;


import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * A util class to convert List to JSONArray 
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.AtLeastOneConstructor", "PMD.ShortVariable"})
@Service
public class DtoJsonArray {


	/**
	 * Convert List to JSONArray 
	 *
	 * @author : hjh
	 * @Date : 2022. 02. 24
	 */
    public JSONArray toJSONArray(final List<Map<String, Object>> companyList) throws JsonProcessingException {

    	final ObjectMapper om = new ObjectMapper();
    	final String toStrOmgJson = om.writeValueAsString(companyList);
		
		return (JSONArray) JSONValue.parse(toStrOmgJson);
	}
	
}
