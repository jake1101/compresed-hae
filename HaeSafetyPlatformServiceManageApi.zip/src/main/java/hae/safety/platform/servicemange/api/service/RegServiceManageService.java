package hae.safety.platform.servicemange.api.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hae.safety.platform.servicemange.api.mapper.RegServiceManageMapper;
import hae.safety.platform.servicemange.api.util.RestfulUtilService;

/**
 * 그룹관리자용 Service
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.LoggerIsNotStaticFinal", "PMD.AvoidLiteralsInIfCondition", "PMD.LawOfDemeter", "PMD.UnusedAssignment"
	, "PMD.AvoidDuplicateLiterals", "PMD.NcssCount", "PMD.SwitchDensity", "PMD.ImmutableField", "PMD.SimpleDateFormatNeedsLocale", "PMD.DataflowAnomalyAnalysis"
	, "PMD.ShortVariable", "PMD.LongVariable", "PMD.AtLeastOneConstructor", "PMD.ModifiedCyclomaticComplexity", "PMD.ExcessiveMethodLength", "PMD.ModifiedCyclomaticComplexity"})
@Service
@Transactional(rollbackFor = {Exception.class})
public class RegServiceManageService { 
	
	/**
	 * Logger
	 */
	private transient final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * 그룹관리자용 Mapper
	 */
    @Autowired
    private transient RegServiceManageMapper mapper;
    
    /**
	 * remote API 호출
	 */
	@Autowired
	private transient RestfulUtilService restfulUtilService;
    
//    @Autowired
//    private ModelMapper modelMapper;
    
    /**
	 * 등록서비스그룹전체조회
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : getSvcGrpAll
	 */
    public List<Map<String,Object>> getSvcGrpAll() {
		
		return mapper.findAll();
	}
    
    /**
	 * 등록서비스검색조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : findRegSafetyServiceList
	 */
    public List<Map<String,Object>> findRegSafetyServiceList(final Map param) {
		
		return mapper.findRegSafetyServiceList(param);
	}
    
    /**
	 * 등록서비스 사용상태 변경
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : updateServiceUseYn
	 */
    public int updateServiceUseYn(final Map param) {
		
		return mapper.updateServiceUseYn(param);
	}
    
//	public Optional<User> getUserById(long userId) {
//		
//		return Optional.ofNullable(mapper.getUserInfo(userId));
//	}
//	
//	public List<User> getUserAll() {
//		
//		return mapper.getUserAll();
//	}
    /**
	 * 서비스 신청 관리 : 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprList
	 */
    public List<Map<String,Object>> getServiceAprList(final Map param) {
		
		return mapper.getServiceAprList(param);
	}
    
    /**
	 * 서비스 신청 관리 : 상세조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprListDetail
	 */
    public List<Map<String,Object>> getServiceAprListDetail(final Map param) {
    	
    	final Map<String, Object> resultMap = new ConcurrentHashMap<>();
    	
    	// 서비스 이용 내역 상세
    	resultMap.put("getServiceAprListDetail", mapper.getServiceAprListDetail(param));
    	// 서비스 이용 장비 리스트
    	resultMap.put("getServiceAprListDvcDetail", mapper.getServiceAprListDvcDetail(param));
    	
    	final int checked = mapper.checkedChgApr(param);
    	
    	// 변경 신청 여부 확인
    	if(checked == 1) { 
    		// 변경 건이 있으면 변경 신청 전송한다.
        	resultMap.put("getServiceAprChgListDetail", mapper.getServiceAprChgListDetail(param));
        	// 변경 건이 있으면 전송한다.
        	resultMap.put("getServiceAprChgListDvcDetail", mapper.getServiceAprChgListDvcDetail(param));
    	}    	
    	
    	final List<Map<String,Object>> resultList = new ArrayList<>();
    	
    	resultList.add(resultMap);
    	
		return resultList;
	}
    
    /**
	 * 서비스 신청 관리 : 상세조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprListDetail
	 */
    public List<Map<String,Object>> getServiceAprListDvcDetail(final Map param) {
    	
    	final Map<String, Object> resultMap = new ConcurrentHashMap<>();
    	
    	// 서비스 이용 장비 리스트
    	resultMap.put("getServiceAprListDvcDetail", mapper.getServiceAprListDvcDetail(param));
    	
    	final List<Map<String,Object>> resultList = new ArrayList<>();
    	
    	resultList.add(resultMap);
    	
		return resultList;
	}
    
    /**
	 * 서비스 신청 관리 : 변경신청 상세조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 23
	 * @Method Name : getServiceAprChgListDetail
	 */
    public List<Map<String,Object>> getServiceAprChgListDetail(final Map param) {
    	
    	final Map<String, Object> resultMap = new ConcurrentHashMap<>();
    	
    	// 서비스 이용 내역 상세
    	resultMap.put("getServiceAprChgListDetail", mapper.getServiceAprChgListDetail(param));
    	// 서비스 이용 장비 리스트
    	resultMap.put("getServiceAprChgListDvcDetail", mapper.getServiceAprChgListDvcDetail(param));
    	
    	final List<Map<String,Object>> resultList = new ArrayList<>();
    	
    	resultList.add(resultMap);
    	
		return resultList;
	}
        
    /**
	 * 서비스 신청 관리 : 신규 신청 승인
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
     * @throws ParseException 
     * @throws Exception 
	 * @Date : 2022. 03. 23
	 * @Method Name : serviceAplAprProcess
     */	
    public int serviceAplAprProcess(final Map param) throws ParseException { 
    	
    	//프로세스 성공 여부
    	int cudCnt = 0;
    	int checked;
    	
    	final String serviceGbCd = (String) param.get("service_gb_cd");
    	final String sttCd = (String) param.get("stt_cd"); 
    	
    	switch(serviceGbCd) { 
    	
	        case "1": // 신규
	        	
	        	// 승인 요청 단계를 확인하여 다음 상태 값으로 업데이트
	        	if("1".equals(sttCd)) {
	        		
	        		param.put("stt_cd","2");
	        		checked = mapper.checkedService(param);	// 기 등록 여부 확인
	        		
	        		if(checked == 1) {
	        			break;
	        		}
	        		
	        		mapper.updateSvcReq(param);				// 신청 테이블 서비스 상테 업데이트
		        	cudCnt = mapper.insertSvcApr(param);	// 승인테이블 등록
		        	break;
	        	}
	        	if("2".equals(sttCd)) {
	        		
	        		param.put("stt_cd","3");
	        		checked = mapper.checkedService(param);
	        		
	        		if(checked == 1) {
	        			break;
	        		}
	        		
	        		mapper.updateSvcReq(param);
	        		checked = mapper.insertSvcTst(param);	// 서비스 테스트 테이블 등록
		        	
		        	if(checked == 0) {
		        		break;
		        	}
		        	
	        		//서비스 이용 롤 부여
		        	param.put("saveType", "save");	        		
	        		cudCnt = serviceAuthorization(param);
	        		
		        	break;
	        	}
	        	if("3".equals(sttCd)) {
	        		
	        		param.put("stt_cd","4");
	        		checked = mapper.checkedService(param);
	        		
	        		if(checked == 1) { 
	        			break;
	        		}
	        		
	        		mapper.updateSvcReq(param);
	        		
		        	mapper.insertSvcSst(param);	// 서비스 구독 테이블 등록
		        	
		        	// 구독 기간에 따라
		        	final int cnt = (int) param.get("sst_trm");

		        	final Calendar cal = Calendar.getInstance();
		        	
		        	final DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); 

		        	final List<Map<String,Object>> feePmtList =  new ArrayList<>();
	        		
		        	final Date date = new Date();
        	        
		        	for(int i = 0 ; i < cnt ; i++ ) {

		        		final Map<String,Object> feePmtMap =  new ConcurrentHashMap<>(); // NOPMD by 9396368 on 22. 4. 11. 오후 3:37, can't use clear Method
	        			
	        	        // 서비스 개시 승인일(today)
	        	        cal.setTime(date);
	        	        
	        	        cal.add(Calendar.MONTH, i + 1);
	        	        
	        	        final int dayOfMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

	        	        // 개시요청월 마지막일
	        	        cal.set(Calendar.DAY_OF_MONTH , dayOfMonth);
	        	        
	        	        feePmtMap.put("svc_id", param.get("svc_id")); 
	        			feePmtMap.put("sst_mon", i + 1); 

	        			//서비스 계시 요청월의 말일로 셋팅
	        			feePmtMap.put("exp_pmt_dt", df.format(cal.getTime()));
	        			
	        			feePmtList.add(feePmtMap);
	        		}
	        		
	        		param.put("feePmtList", feePmtList);
		        	cudCnt = mapper.insertFeePmt(param);	// 서비스 구독료 테이블 저장
		        	
		        	break;
	        	}
	        	
        		if("99".equals(sttCd)) { // 테스트 코드
	        		
//        				String t1 = (String) param.get("column1");
//        				String t2 = (String) param.get("column2");
        				
//        				mapper.rollbacktesttable(t1,t2);	// 롤백 테스트
        				
//        			
//	        			// 구독 기간에 따라
//		        		final int cnt = Integer.parseInt((String) param.get("sst_trm"));
//	
//		        		final List<Map<String,Object>> feePmtList =  new ArrayList<>();
//		        			        		
//		        		final String string = (String) param.get("dsr_str_dt");
//		        		final DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);	// 정상 코드
////		        		DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.KOREA);		// Date Parser Exception 코드
//		        		
//		        		final Calendar cal = Calendar.getInstance();
//		        		final Date date = format.parse(string);
//						
//		        		final DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); 
//		        		
//		        		for(int i = 0 ; i < cnt ; i++ ) {
//		        			
//		        			final Map<String,Object> feePmtMap =  new ConcurrentHashMap<>(); // NOPMD by 9396368 on 22. 4. 11. 오후 3:37, can't use clear Method
//		        			
//		        			// 개시요청년월일
//		        	        cal.setTime(date);
//		        	        
//		        	        final int dayOfMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
//
//		        	        // 개시요청월 마지막일
//		        	        cal.set(Calendar.DAY_OF_MONTH , dayOfMonth);
//		        	        
//		        	        feePmtMap.put("svc_id", param.get("svc_id"));
//		        			feePmtMap.put("sst_mon", i + 1);
//		        			
//		        			cal.add(Calendar.MONTH, i + 1);
//		        			
//		        			//서비스 계시 요청월의 말일로 셋팅
//		        			feePmtMap.put("exp_pmt_dt", df.format(cal.getTime()));
//		        			
//		        			feePmtList.add(feePmtMap);
//		        			
//		        		}
						
		        		param.put("saveType", param.get("saveType"));
		        		param.put("ptl_rol_cd", param.get("ptl_rol_cd"));
//		        		param.put("user_id", param.get("usr_id"));
		        		param.put("user_id", "");
		        		param.put("apply_group_id", param.get("apply_group_id"));
		        		param.put("siteId", param.get("siteId"));
		        		param.put("saveType", "delete");
		        		
		        		cudCnt = serviceAuthorization(param);
		        		
		        	break;
	        	}
	        	
	        case "5": // 변경
	        	
	        	// 서비스 승인 단계, 변경 승인시 SVC_REQ, SVC_DVC Table을 update 한다.	        		
	        	final List<Map<String,Object>> dataList =  new ArrayList<>();
	        	final Map<String, Object> dataMap = new ConcurrentHashMap<>();
        		
        		dataList.addAll(mapper.getServiceAprListDetail(param));
        		
        		dataMap.putAll(dataList.get(0));
        		dataMap.putAll(param);
        		
        		final Date sstStrDt = (Date) dataMap.get("sst_str_dt");
        		
        		final int chgSeq = mapper.addSvcChgHst(dataMap);	// 서비스 변경 내역 테이블 등록
        		
        		final int asIsSstTrm = (int) dataMap.get("sst_trm");	// 변경 전 서비스 구독 기간
        		int toBeSstTrm = 0;	// 변경 서비스 구독 기간
        		
        		dataMap.clear();
        		dataList.clear();
        		
        		dataList.addAll(mapper.getServiceAprListDvcDetail(param));
        		
        		dataMap.put("dvc_list", dataList);
        		dataMap.put("chg_seq", chgSeq);
        		
        		// 기존 이용 장비 리스트 저장
        		cudCnt = mapper.addDvcChgHst(dataMap);
        		
        		dataMap.clear();
        		dataList.clear();
        		
        		// 변경 등록된 서비스 정보를 현재 정보로 업데이트
        		// 기간 / 장비 / 구독료 업데이트
        		dataList.addAll(mapper.getServiceAprChgListDetail(param));
        		dataMap.putAll(dataList.get(0));
        		
        		// 구독변경 여부 dvc_chg_yn 
        		// 구독변경 사유(e01:기간변경,d01:중단,d00:해당없음)
        		// 구독기간변경 사유가 기간 변경이면
    			if("e01".equals(dataList.get(0).get("trm_chg_cd"))) {
    				
    				toBeSstTrm = (int) dataMap.get("sst_trm");
    				//변경에 따른 서비스 만료 예정일 변경
    				//변경에 따른 예상 월 구독료 변경
    				//변경에 따른 최종 월 구독료 변경
    				cudCnt = mapper.serviceChgDt(dataMap);
    			
    			// 구독 중단 처리
    			}else if("d01".equals(dataList.get(0).get("trm_chg_cd"))) {
    				
    				// 서비스 중단
    				dataMap.put("stt_cd", "10");
    				
    				//서비스 사용 중지 상태로 변경
    				cudCnt = mapper.serviceChgSvcReqSttCd(dataMap);
    				
    				//서비스 이용 롤 회수
		        	param.put("saveType", "delete");	        		
	        		cudCnt = serviceAuthorization(param);
    			}
    			
    			// 디바이스 수량 변경 사유 (1:수량변경, 0:해당없음)
        		if("1".equals(dataList.get(0).get("dvc_chg_yn"))) {
        			
        			dataMap.clear();
            		dataList.clear();
            		
            		// 변경 등록된 서비스 정보를 현재 정보로 업데이트
            		// 기간 / 장비 / 구독료 업데이트
            		dataList.addAll(mapper.getServiceAprChgListDvcDetail(param));
            		dataMap.put("dvc_list",dataList);
            		dataMap.put("svc_id", param.get("svc_id"));
            		
            		cudCnt = mapper.serviceChgSvcDvc(dataMap);
        		}
        		
        		// 승인테이블 최종 월 구독료 저장
        		cudCnt = mapper.serviceChgSvcAprMonFee(param);
        		
        		// 서비스 변경 요청 : 서비스 이용중 처리
        		if("4".equals(sttCd)) {
        			
        			// 이용중인 서비스 변경 건에 대한 구독 기간 정보 변경
        			// 변경 전보다 변경 후 구독 기간이 길다면
        			if(asIsSstTrm < toBeSstTrm) {
        				
        				final Calendar cal = Calendar.getInstance();
		        		
//	        			Date date = format.parse(sstStrDt);
        				final DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); 

	        			// 늘어난 기간 만큼 구독 기간 add
	        			final List<Map<String,Object>> feePmtList =  new ArrayList<>();
	        			
	        			for(int i = asIsSstTrm ; i < toBeSstTrm ; i++ ) {

	        				final Map<String,Object> feePmtMap =  new ConcurrentHashMap<>(); // NOPMD by 9396368 on 22. 4. 11. 오후 3:37, can't use clear Method
    	        			
    	        	        cal.setTime(sstStrDt);
    	        	        
    	        	        cal.add(Calendar.MONTH, i + 1);
    	        	        
    	        	        final int dayOfMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

		        	        // 개시요청월 마지막일
		        	        cal.set(Calendar.DAY_OF_MONTH , dayOfMonth);

    	        			feePmtMap.put("svc_id", param.get("svc_id"));
    	        			feePmtMap.put("sst_mon", i + 1);

    	        			//서비스 계시 요청월의 말일로 셋팅
    	        			feePmtMap.put("exp_pmt_dt", df.format(cal.getTime()));
    	        			
    	        			feePmtList.add(feePmtMap);
    	        		}
    	        		
    	        		param.put("feePmtList", feePmtList);
    		        	cudCnt = mapper.insertFeePmt(param);	// 서비스 구독료 테이블 저장
        				
            		// 변경 전보다 구독 기간이 짧다면        				
        			}else if(asIsSstTrm > toBeSstTrm) {
        				
        				// 줄어든 기간 만큼 구독 기간 del
        				// pmt_seq, svc_id 기준 차이나는 sst_mon 삭제
    	        		param.put("sst_mon", toBeSstTrm);    	        		
    		        	cudCnt = mapper.serviceChgSvcReqAprSubFee(param);	// 서비스 구독료 테이블 저장
        				
        			}
        			
        		}
        		
        		// 변경신청 등록 테이블 승인 완료 처리
        		cudCnt = mapper.serviceChgSvcReqApr(param);
        		
        		break;
	        		
        		//TODO: default case 필요
        		default : cudCnt = 0;
	   	}
		return cudCnt;
	}

    
    /**
	 * 서비스 신청 관리 : 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 24
	 * @Method Name : grpAdmServiceUseList
	 */
    public List<Map<String,Object>> grpAdmServiceUseList(final Map param) {
		
		return mapper.grpAdmServiceUseList(param);
	}
    
    /**
	 * 구독료 납부 관리 : 구독료 관리 목록 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 25
	 * @Method Name : serviceSstList
	 */
    public List<Map<String,Object>> serviceSstList(final Map param) {
		
		return mapper.serviceSstList(param);
	}
    
    /**
	 * 구독료 납부 관리 : 구독료 관리 목록 상세 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 25
	 * @Method Name : serviceSstListDetail
	 */
    public List<Map<String,Object>> serviceSstListDetail(final Map param) {
    	
    	final List<Map<String,Object>> resultList = mapper.serviceSstListDetail(param);
    	
    	/*
    	for(int i = 0 ; i < resultList.size() ; i++ ) { 
    		
    		final String expStt = (String) resultList.get(i).get("exp_stt");
    		
    		// 납부 가능 상태 여부 
    		if("0".equals(expStt) || "1".equals(expStt)) { 
    			resultList.get(i).put("exp_stt_yn","1");
    			break;
    		}
    		
    	}
    	*/
    	
    	String expStt;
        for (final Map<String, Object> result : resultList) {
        	
    		expStt = (String)result.get("exp_stt");
    		
    		// 납부 가능 상태 여부 
    		if("0".equals(expStt) || "1".equals(expStt)) { 
    			result.put("exp_stt_yn","1");
    			break;
    		}
          }    	
    	
		return resultList;
	}
    
    /**
	 * 구독료 납부 관리 : 구독료 관리 목록 상세 조회 : 날짜 수정
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 28
	 * @Method Name : serviceSstListDetailChgDay
	 */
    public int serviceSstListDetailChgDay(final Map param) {
		
		return mapper.serviceSstListDetailChgDay(param);
	}
    
    /**
	 * 구독료 납부 관리 : 구독료 관리 목록 상세 조회 : 납부 확인
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 03. 28
	 * @Method Name : serviceSstListDetailChgFee
	 */
    public int serviceSstListDetailChgFee(final Map param) {
		
		return mapper.serviceSstListDetailChgFee(param);
	}
    
    /**
	 * 구독료 통계 조회
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
     * @throws ParseException 
	 * @Date : 2022. 03. 28
	 * @Method Name : serviceSstListDetailChgFee
	 */
    public  List<Map<String,Object>>  getMonFeeStatistics(final Map<String, String> param) throws ParseException {
		
		final String sstStrDt = (String) param.get("sst_str_dt");
		final String sstEndDt = (String) param.get("sst_end_dt");
		
		if (sstStrDt != null && sstEndDt != null) {
			final DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);	
			final DateFormat formatStrDt = new SimpleDateFormat("MMM d, yyyy 00:00:00", Locale.ENGLISH);
			final DateFormat formatEndDt = new SimpleDateFormat("MMM d, yyyy 23:59:59", Locale.ENGLISH);
			
			final Date strDt = format.parse(sstStrDt);
			final Date endDt = format.parse(sstEndDt);
			
			param.put("sst_str_dt", formatStrDt.format(strDt));
			param.put("sst_end_dt", formatEndDt.format(endDt));
		}
		
		return mapper.getMonFeeStatistics(param);
	}
    
    /**
	 * 서비스 롤 권한 부여
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list 
	 * @Date : 2022. 04. 15
	 * @Method Name : joinMemberAction
	 */
	public int serviceAuthorization(final Map param){
		
		final List siteList = new ArrayList<>();
		
		siteList.add(param.get("apply_wpc_cd"));
		
		final Map<String,Object> serviceAuthorizationMap =  new ConcurrentHashMap<>();
		
		Map<String,Object> raycomApiResMap =  new ConcurrentHashMap<>();

		serviceAuthorizationMap.put("saveType", param.get("saveType"));
		serviceAuthorizationMap.put("roleCd", param.get("ptl_rol_cd"));
//		serviceAuthorizationMap.put("user_id", param.get("usr_id"));
		serviceAuthorizationMap.put("user_id", "");
		serviceAuthorizationMap.put("companyId", param.get("apply_group_id"));
		serviceAuthorizationMap.put("siteIds", siteList);

//		raycomApiResMap = serviceAuthorization(serviceAuthorizationMap);
		raycomApiResMap = restfulUtilService.callRaycomApi("has/if/user/role/save", serviceAuthorizationMap);
		
		final int resCode = Integer.parseInt((String) raycomApiResMap.get("code"));
		
		if (logger.isDebugEnabled()) {
			logger.debug("serviceAuthorization : resCode :" + resCode + " | param : " + serviceAuthorizationMap);
		}
		
		return resCode;
    }
}
