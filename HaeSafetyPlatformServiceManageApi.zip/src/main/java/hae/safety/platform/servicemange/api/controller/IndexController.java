package hae.safety.platform.servicemange.api.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * view 서비스용 Controller
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.AtLeastOneConstructor", "PMD.CommentSize"})
@Controller
@RequestMapping("/")
public class IndexController {
	
	/**
	 * 비계열사 회원가입 화면
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 02. 24
	 * @Method Name : index
	 */
	@GetMapping("joinMember")
    public String index(){
        return "joinMember";
    }
}
