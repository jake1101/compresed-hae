package hae.safety.platform.servicemange.api.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hae.safety.platform.servicemange.api.dto.BaseDto;
import hae.safety.platform.servicemange.api.service.BaseServiceManageService;
import hae.safety.platform.servicemange.api.service.ServiceCtlManageService;
import hae.safety.platform.servicemange.api.service.ServiceManageStatisticsService;
import hae.safety.platform.servicemange.api.util.DtoBuilder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;


/**
 * 조회용 Controller
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.AvoidDuplicateLiterals", "PMD.CommentSize", "PMD.ShortVariable", "PMD.LongVariable", "PMD.LawOfDemeter",
	"PMD.AvoidCatchingGenericException", "PMD.DataflowAnomalyAnalysis", "PMD.AvoidLiteralsInIfCondition", "PMD.LinguisticNaming", "PMD.AvoidInstantiationgCondition",
	"PMD.ExcessiveImports", "PMD.AvoidInstantiatingObjectsInLoops"})
@RestController
@RequiredArgsConstructor
//@RequestMapping("api/v1")
@RequestMapping("${apiConfig.path}")
@Api(tags = {"서비스 관리 통계"})
// @CrossOrigin  // CORS 허용 
public class ServiceManageStatisticsController {
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceManageStatisticsController.class);

    /**
	 * 1:1서비스요청용 service
	 */
	@Autowired
	private ServiceCtlManageService serviceCtlManageService;
	
	/**
	 * 통계용service
	 */
	@Autowired
	private ServiceManageStatisticsService serviceManageStatisticsService;
	
    /**
	 * 기초정보조회용 service
	 */
	@Autowired
	private BaseServiceManageService baseServiceManageService;
	
    /**
	 * DtoBuilder
	 */
	@Autowired
	private DtoBuilder dtoBuilder;
	
	/**
	 * 조회 결과 key
	 */
	@Value("${key.listKey}")
	private transient String listKey;
	
	
	/**
	 * 조회 성공 message 
	 */
	@Value("${msg.searchSuccess}")
	private transient String searchSuccess;
	
    /**
	 * 조회 실패 message 
	 */
	@Value("${msg.searchFail}")
	private transient String searchFail;
	
	/**
	 * 그룹 관리자 : 통계 자료 : 서비스 구독 통계
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 18
	 * @Method Name : searchSvcSubStatistics
	 */
	@PostMapping ("searchSvcSubStatistics")
	@ApiOperation(value = "통계 자료 : 서비스 구독 통계", response = BaseDto.class)
	public void searchSvcSubStatistics(@RequestBody final Map param)  throws ParseException{
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final List<Map<String,Object>> ctlList = serviceCtlManageService.getWpcServiceList(param);
		
		final Locale locale = Locale.getDefault();
		
		param.put("lang_cd",locale.toString());
		
		param.put("ctlList",ctlList);
		
		final String sstStrDt = (String) param.get("sst_str_dt");
		final String sstEndDt = (String) param.get("sst_end_dt");
		
		if (sstStrDt != null && sstEndDt != null) {
			final DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);	
			final DateFormat formatStrDt = new SimpleDateFormat("MMM d, yyyy 00:00:00", Locale.ENGLISH);
			final DateFormat formatEndDt = new SimpleDateFormat("MMM d, yyyy 23:59:59", Locale.ENGLISH);
			
			final Date strDt = format.parse(sstStrDt);
			final Date endDt = format.parse(sstEndDt);
			
			param.put("sst_str_dt", formatStrDt.format(strDt));
			param.put("sst_end_dt", formatEndDt.format(endDt));
		}
		
		final List<Map<String,Object>> resultList = serviceManageStatisticsService.searchSvcSubStatistics(param);
		
		final Map<String,Object> resultMap = new ConcurrentHashMap<>();
		
		resultMap.put("header", ctlList);
		
		resultMap.put("body", resultList);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, resultMap);
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * 그룹 관리자 : 통계 자료 : 안전 관제 통계
	 *
	 * @author : hjh
	 * @param 
	 * @param 
	 * @return the JSONArray : code String, message String,  result_data list
	 * @Date : 2022. 04. 18
	 * @Method Name : searchSafetyCtlStatistics
	 */
	@PostMapping ("searchSafetyCtlStatistics")
	@ApiOperation(value = "통계 자료 : 안전관제통계", response = BaseDto.class)
	public void searchSafetyCtlStatistics(@RequestBody final Map param) throws ParseException{
		
		// 권한별 사업자 정보 조회
		param.put(listKey, baseServiceManageService.getWPCList(param));
		
		final Locale locale = Locale.getDefault();
		
		param.put("lang_cd",locale.toString());
		
		final String sstStrDt = (String) param.get("sst_str_dt");
		final String sstEndDt = (String) param.get("sst_end_dt");
		
		if (sstStrDt != null && sstEndDt != null) {
			final DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);	
			final DateFormat formatStrDt = new SimpleDateFormat("MMM d, yyyy 00:00:00", Locale.ENGLISH);
			final DateFormat formatEndDt = new SimpleDateFormat("MMM d, yyyy 23:59:59", Locale.ENGLISH);
			
			final Date strDt = format.parse(sstStrDt);
			final Date endDt = format.parse(sstEndDt);
			
			param.put("sst_str_dt", formatStrDt.format(strDt));
			param.put("sst_end_dt", formatEndDt.format(endDt));
		}
//		int cnt = 0;
		
		int selectMwtCd = 0;
		
		if(param.get("mwt") != null) {
			selectMwtCd = (int) param.get("mwt");
		}
		
		if(0 == selectMwtCd) { // 월
			param.put("cntList",setMwtArray(12));
		}else if(1 == selectMwtCd) { // 주
			param.put("cntList",setMwtArray(7));
		}
//		else if(2 == selectMwtCd) { // 시간
//			param.put("cntList",setMwtArray(23));
//		}
		
		final List<Map<String,Object>> resultList = serviceManageStatisticsService.searchSafetyCtlStatistics(param);
		
		final Map<String,Object> resultMap = new ConcurrentHashMap<>();
		
		resultMap.put("body", resultList);
		
		try {
			// (code : 1 or 0, massage , data)
			dtoBuilder.writeResultPayload("1", searchSuccess, resultMap);
		} catch (Exception e) {
			if(LOGGER.isErrorEnabled()) {
				LOGGER.error(e.getMessage());
			}
			dtoBuilder.writeResultPayload("0", searchFail, e.getMessage());
		}
	}
	
	/**
	 * 서비스 기간 조회 배열 생성
	 *
	 * @author : hjh
	 * @param @RequestBody Map param
	 * @return the JSONArray : code String, message String,  result_data list 
	 * @Date : 2022. 04. 18
	 * @Method Name : joinMemberAction
	 */
	public List<Map<String,Object>> setMwtArray(final int cnt){
		
		final List<Map<String,Object>> mwtList =  new ArrayList<>();
		
		int startCnt = 1;
		
		if(cnt == 23) {
			startCnt = 0;
		}
		
		for(int i = startCnt ; i <= cnt ; i++ ) {
			
			final Map<String,Object> cntMap =  new ConcurrentHashMap<>();
	        
			cntMap.put("cnt", i);
			
			mwtList.add(cntMap);
			
		}
		
		return mwtList;
    }
	
}
