package hae.safety.platform.servicemange.api.util;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * 외부 서비스 호출욜 Service
 *
 * @author : hjh
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({"PMD.CommentSize", "PMD.AtLeastOneConstructor", "PMD.AvoidCatchingGenericException", "PMD.ShortVariable", "PMD.LawOfDemeter", "PMD.DataflowAnomalyAnalysis"
	, "PMD.AvoidDuplicateLiterals", "PMD.ImmutableField"})
@Service
public class RestfulUtilService {
	
	/**
	 * raycom api url
	 */
	@Value("${raycom.apiurl}")
	private transient String raycomURL;
    
	/**
	 * raycom api 호출 인증 토큰
	 */
	@Value("${raycom.usertoken}")
	private transient String userToken;
	
	/**
	 * email api url
	 */
	@Value("${agent.apiurl}")
	private transient String agent;
	
	/**
	 * email api 호출 인증 토큰
	 */
	@Value("${agent.authorization}")
	private transient String authorization;

	/**
	 * Raycom API 호출
	 * @param url
	 * @param param
	 * @return
	 */
	public Map<String, Object> callRaycomApi(final String uri, final Object param){
		final Map<String, Object> resultMap = new ConcurrentHashMap<>();
		
		final Gson gson = new GsonBuilder().serializeNulls().create();
		
		final Charset utf8 = StandardCharsets.UTF_8; 
		final MediaType mediaType = new MediaType("application", "json", utf8);
	    
	    /**
		 * Header 세팅
		 */
		final HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(mediaType);
	    headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
	    headers.set("userToken", userToken);

	    HttpEntity<String> request;
	    if(param == null){
	    	request = new HttpEntity<>("{}", headers);
	    }else{
	    	request = new HttpEntity<>(gson.toJson(param), headers);
	    }
		
	    final RestTemplate restTemplate = new RestTemplate();
	    
	    final String customerUrl = raycomURL + uri;
	    final ResponseEntity<String> result = restTemplate.exchange(customerUrl, HttpMethod.POST, request, String.class);
		
	    final Gson resultGson = new Gson();
	    final HashMap<String, Object> jsonResponse = resultGson.fromJson(result.getBody(), new TypeToken<HashMap<String, Object>>(){}.getType());  // NOPMD by 9396368 on 22. 4. 11. 오후 3:38, can't use ConcurrentHaspMap
	    final Map<String, Object> jsonHeader = (Map<String, Object>)jsonResponse.get("header"); // NOPMD by 9396368 on 22. 4. 11. 오후 3:38, can't use ConcurrentHaspMap
		
		final String checked =  Integer.toString(((Double)jsonHeader.get("code")).intValue());

		if( "1".equals(checked)){
			resultMap.put("result_status", "S");
			if(null != jsonResponse.get("data") && !"".equals(jsonResponse.get("data")) ) {
				resultMap.put("result_data", jsonResponse.get("data") );
			}
		}else{
			resultMap.put("result_status", "E");
		}
		
		resultMap.put("code", checked);
		resultMap.put("result_message", jsonHeader.get("message").toString() ); 

		return resultMap;
	}

	/**
	 * 상황전파 API 호출
	 * @param url
	 * @param param
	 * @return
	 */
	public Map<String, Object> callAgentApi(final String uri, final Object param){
		
		final Map<String, Object> resultMap = new HashMap<>(); // NOPMD by 9396368 on 22. 4. 11. 오후 3:38, can't use ConcurrentHaspMap
		
		final Gson gson = new GsonBuilder().serializeNulls().create();
		
//		final Charset utf8 = StandardCharsets.UTF_8; 
//		final MediaType mediaType = new MediaType("application", "json", utf8);
	    
	    /**
		 * Header 세팅
		 */
		final HttpHeaders headers = new HttpHeaders();
//	    headers.setContentType(mediaType);
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
	    headers.set("Authorization", authorization);

	    HttpEntity<String> request;
	    if(param == null){
	    	request = new HttpEntity<>("{}", headers);
	    }else{
	    	request = new HttpEntity<>(gson.toJson(param), headers);
	    }
		
	    final RestTemplate restTemplate = new RestTemplate();
	    
	    final String customerUrl = agent + uri;
	    final ResponseEntity<String> result = restTemplate.exchange(customerUrl, HttpMethod.POST, request, String.class);
		
	    final Gson resultGson = new Gson();
	    final Map<String, Object> jsonObject = resultGson.fromJson(result.getBody(), new TypeToken<Map<String, Object>>(){}.getType());  // NOPMD by 9396368 on 22. 4. 11. 오후 3:38, can't use ConcurrentHaspMap
	
	    final String checked = (String) jsonObject.get("result");

		if( "0000".equals(checked)){
			resultMap.put("code", "1");
			resultMap.put("data", (String) jsonObject.get("message") );
		}else{
			resultMap.put("code", "0");
		}
		
		resultMap.put("message", (String) jsonObject.get("message") );

		return resultMap;
	}
}
