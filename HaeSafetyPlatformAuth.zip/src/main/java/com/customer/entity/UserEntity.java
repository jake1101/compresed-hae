package com.customer.entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/**
 * 사용자 정보 Entity 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

@Entity
@Data
@Table(name="usr_info")
public class UserEntity {

	/** 사용자 정보 식별자  */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

	/** 사용자 이름  */
    @Column(name="username")
    private String username;

	/** 사용자 이름  */
    @Column(name="realname")
    private String realname;

	/** 비밀번호  */
    @Column(name="password")
    private String password;

	/** 핸드폰 번호  */
    @Column(name="phn") 
    private String phoneNumber;

	/** 사용자 토큰   */
    @Column(name="user_token")
    private String userToken;

	/** 사용권한  */
    @Column(name="access_level")
    private String accessLevel;

	/** 이메일 주소  */
    @Column(name="email")
    private String email;

	/** 사이트 식별자  */
    @Column(name="siteId")
    private String siteId;

	/** 회사 코드  */
    @Column(name="cmp_cd")
    private String cmpCd;

	/** 역할  */
    @Column(name="roles")
    private String roles;
    
	/** 게열사 식별자 1  */
    @Column(name="instituteId1")
    private String instituteId1;
    
	/** 게열사 식별자 2  */
    @Column(name="instituteId2")
    private String instituteId2;
    
	/**
	 * Role 목록 조회
	 * 
	 * @author : david
	 * @param : void
	 * @return List<String>
	 * @Date : 2022. 02. 24
	 * @Method Name : reqAccessJwt
	 */
    public List<String> getRoleList(){
        if(this.roles != null && this.roles.length() > 0){
            return Arrays.asList(this.roles.split(","));
        }
        return new ArrayList<>();
    }
}
