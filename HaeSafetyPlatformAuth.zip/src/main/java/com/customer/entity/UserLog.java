package com.customer.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/**
 * 사용자 인증 로그 Entity 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@Entity
@Data@Table(name="usr_log")
public class UserLog {
	
	/** 사용자 로그 발생 날짜시간 */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="evt_seq")
    private long evtSeq;
    
    /** 사용자 식별자 */
    @Column(name="usr_nm")
    private String userName;
    
    /** 로그인 or 로그아웃 */
    @Column(name="evt_tp_cd")
    private int evtTpCd;
    
    /** 클라이언트 종류 코드 */
    @Column(name="clt_tp_cd")
    private int cltTpCd;
    
    /** 이벤트 발생 날짜 */
    @Column(name="evt_dt")
    private Date evtDate;
}
