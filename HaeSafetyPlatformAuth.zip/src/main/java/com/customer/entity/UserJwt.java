package com.customer.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/**
 * 사용자 JWT 정보 Entity 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@Entity
@Data@Table(name="usr_jwt")
public class UserJwt {

	/** 사용자 이름 */
    @Id
    @Column(name="usr_name")
    private String userName;

	/** Access JWT  */
    @Column(name="acc_jwt", length=1024)
    private String accJwt;

	/** Access JWT Expire */
    @Column(name="acc_jwt_exp")
    private Date accJwtExp;

	/** Refresh JWT */
    @Column(name="ref_jwt", length=1024)
    private String refJwt;

	/** Refresh JWT Expire */
    @Column(name="ref_jwt_exp")
    private Date refJwtExp;

	/** 생성날짜 */
    @Column(name="iss_dt")
    private Date issDate;

	/** 갱신날짜 */
    @Column(name="ref_dt")
    private Date refDate;
}
