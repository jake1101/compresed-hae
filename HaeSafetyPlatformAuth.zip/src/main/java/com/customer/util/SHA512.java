package com.customer.util;

import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Encoder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *  SHA512 헬퍼 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

public class SHA512 {
	/** 로거 */
	private final static Logger LOGGER = LoggerFactory.getLogger(SHA512.class);
	
	/** encrypt */
    public String encrypt(final String text)  {
    	MessageDigest md;
    	byte[] hash;
    	
    	try {
	        md = MessageDigest.getInstance("SHA-512");
	    	hash = md.digest(text.getBytes("UTF-8"));
    	} catch(Exception e) {
    		
    		if(LOGGER.isDebugEnabled()) {
    			LOGGER.debug(e.getMessage());
    		}
    		return "password-" + e.getMessage();
    	}
    	
    	Encoder encoder = Base64.getEncoder(); 
    	byte[] encodedBytes = encoder.encode(hash);

    	return new String(encodedBytes);
    }
}