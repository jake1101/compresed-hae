package com.customer.util;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.customer.dto.Check2AuthDto;
import com.customer.dto.LogoutDto;
import com.customer.dto.ReissueDto;
import com.customer.dto.UserInfoDto;

/**
 *  DTO 생성 헬퍼 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

@Service
public class DtoBuilder {
	/** 로거 */
	private final static Logger LOGGER = LoggerFactory.getLogger(DtoBuilder.class);
	
	/**
	 * 로그아웃 DTO 생성
	 * 
	 * @author : david
	 * @param final String result, final String message
	 * @return LogoutDto
	 * @Date : 2022. 02. 24
	 * @Method Name : buildLogoutDto
	 */
	public LogoutDto buildLogoutDto(final String result, final String message) {

		LogoutDto dto = new LogoutDto();
		dto.setResult(result);
		dto.setMessage(message);

		return dto;
	}
	
	/**
	 * 사용자정보 DTO 생성
	 * 
	 * @author : david
	 * @param final String result, final String message
	 * @return UserInfoDto
	 * @Date : 2022. 02. 24
	 * @Method Name : buildUserInfoDto
	 */
	public UserInfoDto buildUserInfoDto(final String result, final String message, final UserInfoDto.Payload payload) {

		UserInfoDto dto = new UserInfoDto();
		dto.setResult(result);
		dto.setMessage(message);
		dto.setData(payload);

		return dto;
	}
	
	/**
	 * 사용자 JWT 갱신 DTO 생성
	 * 
	 * @author : david
	 * @param final String result, final String message
	 * @return ReissueDto
	 * @Date : 2022. 02. 24
	 * @Method Name : buildReissueDto
	 */
	public ReissueDto buildReissueDto(final String result, final String message, final ReissueDto.Payload payload) {

		ReissueDto dto = new ReissueDto();
		dto.setResult(result);
		dto.setMessage(message);
		dto.setData(payload);

		return dto;
	}

	/**
	 * 2차인증 결과 DTO 생성
	 * 
	 * @author : david
	 * @param final String result, final String message
	 * @return ReissueDto
	 * @Date : 2022. 02. 24
	 * @Method Name : buildCheck2AuthDto
	 */
	public Check2AuthDto buildCheck2AuthDto(final String result, final String message,
			final Check2AuthDto.Payload payload) {

		Check2AuthDto dto = new Check2AuthDto();
		dto.setResult(result);
		dto.setMessage(message);
		dto.setData(payload);

		return dto;
	}

	/** writeResultPayload */
	public void writeResultPayload(final String result, final String message, final Object data) {

		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpServletResponse response = attr.getResponse();

		response.setContentType("application/json");

		JSONObject responseData = new JSONObject();

		responseData.put("result", result);
		responseData.put("message", message);
		if (data != null) {
			responseData.put("data", data);
		}
		
		try (PrintWriter w = response.getWriter();) {

			w.print(responseData.toJSONString());
			w.flush();
		} catch (Exception e) {
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug(e.getMessage());
			}
		} 
	}
}
