package com.customer.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

/**
 *   사용자정보 임시저장 헬퍼 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.BeanMemberShouldSerialize",
	"PMD.UseDiamondOperator"
})

@Service
public class UserCacheService {

	/** hmPassword  */
	private Map<String, String> hmPassword = new ConcurrentHashMap<String, String>();
	/** hmAuthType  */
	private Map<String, String> hmAuthType = new ConcurrentHashMap<String, String>();
	/** hmOtpCode  */
	private Map<String, String> hmOtpCode = new ConcurrentHashMap<String, String>();
	/** hmSmsCode  */
	private Map<String, String> hmSmsCode = new ConcurrentHashMap<String, String>();
	/** hmSmsTime  */
	private Map<String, Long> hmSmsTime = new ConcurrentHashMap<String, Long>();
	/** hmFidoResult  */
	private Map<String, String> hmFidoResult = new ConcurrentHashMap<String, String>();
	/** hmFidoTime  */
	private Map<String, Long> hmFidoTime = new ConcurrentHashMap<String, Long>();
	
	/** setPassword  */
	public void setPassword(final String userKey, final String value) {
		hmPassword.put(userKey, value);
	}
	/** getPassword  */
	public String getPassword(final String userKey) {
		return hmPassword.get(userKey);
	}	
	/** unsetPassword  */
	public String unsetPassword(final String userKey) {
		return hmPassword.remove(userKey);
	}
	/** setAuthType  */
	public void setAuthType(final String userKey, final String value, final String otpCode) {
		hmAuthType.put(userKey, value);
		if(otpCode != null) {
			hmOtpCode.put(userKey, otpCode);
		}
	}
	/** getAuthType  */
	public String getAuthType(final String userKey) {
		return hmAuthType.get(userKey);
	}	
	/** getOtpCode  */
	public String getOtpCode(final String userKey) {
		return hmOtpCode.get(userKey);
	}	
	/** unsetAuthType  */
	public String unsetAuthType(final String userKey) {
		return hmAuthType.remove(userKey);
	}
	/** setSMSCode  */
	public void setSMSCode(final String refJwt, final String value) {
		hmSmsCode.put(refJwt, value);
		hmSmsTime.put(refJwt, System.currentTimeMillis());
	}
	/** getSMSCode  */
	public String getSMSCode(final String refJwt) {
		return hmSmsCode.get(refJwt);
	}	
	/** unsetSmsCodefinal  */
	public String unsetSmsCodefinal (final String refJwt) {
		hmSmsTime.remove(refJwt);
		
		return hmSmsCode.remove(refJwt);
	}	
	/** setFidoResult  */
	public void setFidoResult(final String refJwt, final String value) {
		hmFidoResult.put(refJwt, value);
		hmFidoTime.put(refJwt, System.currentTimeMillis());
	}
	/** getFidoResult  */
	public String getFidoResult(final String refJwt) {
		return hmFidoResult.get(refJwt);
	}	
	/** unsetFidoResult  */
	public String unsetFidoResult(final String refJwt) {
		hmFidoTime.remove(refJwt);
		
		return hmFidoResult.remove(refJwt);
	}
	/** cleanOlds  */
	public void cleanOlds() {
		// hmFidoResult.notifyAll();
	}
}
