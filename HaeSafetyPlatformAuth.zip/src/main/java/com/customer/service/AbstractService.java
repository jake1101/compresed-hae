package com.customer.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

/**
 *  AbstractService
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

public abstract class AbstractService<T, K extends Serializable> {

	/** Singletone */
	protected abstract JpaRepository<T, K> getRepository();
	
	/** save */
	public T save(final T t) {
		return getRepository().saveAndFlush(t);
	}

	/** delete */
	public void delete(final K id) {
		getRepository().deleteById(id);
	}

	/** list */
	public List<T> list() {
		return getRepository().findAll();
	}

	/** findFirst */
	public Optional<T> findFirst() {
		final List<T> list = getRepository().findAll();
		
		return list.isEmpty() ? Optional.empty() : Optional.of(list.get(0));
	}

	/** fetchById */
	public Optional<T> fetchById(final K id) {
		return getRepository().findById(id);
	}

	/** fetchAll */
	public Page<T> fetchAll(final Pageable pageable) {
		return getRepository().findAll(pageable);
	}

}
