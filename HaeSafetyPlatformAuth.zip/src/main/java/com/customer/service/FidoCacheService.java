package com.customer.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

/**
 *   FIDO 정보 임시저장 헬퍼 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

@Service
public final class FidoCacheService {

	private static FidoCacheService singletone;
	/** hmFidoResult  */
	private Map<String, String> hmFidoResult = new ConcurrentHashMap<String, String>();
	/** hmFidoTime  */
	private Map<String, Long> hmFidoTime = new ConcurrentHashMap<String, Long>();

	private FidoCacheService() {

	}
	
	public static FidoCacheService getSingletoneService() {
		if(singletone == null) {
			singletone = new FidoCacheService();
		}
		return singletone;
	}
	
	/** setFidoResult  */
	public void setFidoResult(final String refJwt, final String value) {
		hmFidoResult.put(refJwt, value);
		hmFidoTime.put(refJwt, System.currentTimeMillis());
	}
	/** getFidoResult  */
	public String getFidoResult(final String refJwt) {
		return hmFidoResult.get(refJwt);
	}	
	/** unsetFidoResult  */
	public String unsetFidoResult(final String refJwt) {
		hmFidoTime.remove(refJwt);
		
		return hmFidoResult.remove(refJwt);
	}
	/** cleanOlds  */
	public void cleanOlds() {
		// hmFidoResult.notifyAll();
	}
}
