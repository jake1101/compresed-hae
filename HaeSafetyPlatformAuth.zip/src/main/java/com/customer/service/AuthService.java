package com.customer.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.customer.entity.UserEntity;
import com.customer.mapper.AuthMapper;
import com.customer.repository.UserRepository;

/**
 *   사용자 인증 서비스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

@Service
public class AuthService extends AbstractService<UserEntity, Long> {
	/** 사용자 관리  mapper */
    @Autowired
    private AuthMapper mapper;

    /** 사용자 관리 레파지토리 */
    @Autowired
    private UserRepository repository;

    /** ModelMapper */
    @Autowired
    private ModelMapper modelMapper;
   
    /** 관제포털 로그인 경로 */
    @Value("${auth.login}")
    private String loginApiUrl;

    /** 관제포털 로그아웃 경로 */
    @Value("${auth.logout}")
    private String logoutApiUrl;

    /** SMS 전송 요청 경로 */ 
//    @Value("${auth.sms}")
//    private String smsRequestUrl;

    /** MPASS OTP 요청 경로 */ 
    @Value("${auth.mpass-otp-url}")
    private String mpassOtpUrl;
    
    /** MPASS FIDO 요청 경로 */ 
    @Value("${auth.mpass-fido-url}")
    private String mpassFidoUrl;

    /** MPASS OTP/FIDO 서버 키 */ 
    @Value("${auth.mpass-secret}")
    private String mpassSecretKey;

    /** MPASS FIDO 콜백 경로 */ 
    @Value("${auth.mpass-fido-return}")
    private String mpassFidoReturnUrl;

    /** MPASS FIDO 콜백 경로 */ 
    @Value("${auth.mpass-auth-myip}")
    private String mpassAuthMyIp;

    @Override
    protected JpaRepository<UserEntity, Long> getRepository() {
        return repository;
    }

    
    public String getLoginApiUrl() {
    	return loginApiUrl;
    }
    
    public String getLogoutApiUrl() {
    	return logoutApiUrl;
    }  
    
//    public String getSmsRequestUrl() {
//    	return smsRequestUrl;
//    }

    public String getMpassOtpUrl() {
    	return mpassOtpUrl;
    }  

    public String getMpassFidoUrl() {
    	return mpassFidoUrl;
    }  
    
    public String getMpassSecretKey() {
    	return mpassSecretKey;
    }
    
    public String getMpassFidoReturnUrl() {
    	return mpassFidoReturnUrl;
    }
    
    public String getMpassFidoAuthMyIp() {
    	return mpassAuthMyIp;
    }
    
    
    // -------------------------------
    //   JPA Style
    // -------------------------------
    /** 사용자 식별자로 조회 */
	public Optional<UserEntity> findById(final long userId) {
		
		 return repository.findById(userId); 
	}
	
	/** 사용자 전체 반환 */
	public List<UserEntity> findAll() {
        return repository.findAll().stream().map(user -> modelMapper.map(user, UserEntity.class))
                .collect(Collectors.toList());
	}
	
    // -------------------------------
    //  MyBatis Mapper Style
    // -------------------------------
	/** 사용자 식별자로 조회 */
	public Optional<UserEntity> getUserById(final long userId) {
		
		return Optional.ofNullable(mapper.getUserInfo(userId));
	}
	
	/** 사용자 전체 반환 */
	public List<UserEntity> getUserAll() {
		
		return mapper.getUserAll();
	}
	
	
	
}
