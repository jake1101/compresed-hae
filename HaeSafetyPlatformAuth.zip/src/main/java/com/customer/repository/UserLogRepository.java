package com.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customer.entity.UserLog;

/**
 * 사용자 로그 관리 레파지토리
 * 
 * @author : david
 * @param
 * @return void
 * @Date : 2022. 02. 24
 */
public interface UserLogRepository extends JpaRepository<UserLog, Long>{
	
}
