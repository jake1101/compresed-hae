package com.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.customer.entity.UserJwt;

/**
 * 사용자 JWT 관리 레파지토리
 * 
 * @author : david
 * @param
 * @return void
 * @Date : 2022. 02. 24
 */
public interface UserJwtRepository extends JpaRepository<UserJwt, String> {

	/** 이름으로 조회 */
	UserJwt findByUserName(String userName);

	/** AccJwt 로 조회 */
	UserJwt findByAccJwt(String accJwt);
}
