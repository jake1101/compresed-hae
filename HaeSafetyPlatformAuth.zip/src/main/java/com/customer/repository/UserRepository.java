package com.customer.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customer.entity.UserEntity;

/**
 * 사용자 관리 레파지토리
 * 
 * @author : david
 * @param
 * @return void
 * @Date : 2022. 02. 24
 */
public interface UserRepository extends JpaRepository<UserEntity, Long>{

	/** 식별자로 조회 */
	@Override
	Optional<UserEntity> findById(Long userId);
	
	/** 모두 조회 */
	@Override
	List<UserEntity> findAll();
	
	/** 이름으로 조회 */
	UserEntity findByUsername(String username);
	
}
