package com.customer.controller;

import java.io.BufferedReader;


import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.customer.config.jwt.JwtProperties;
import com.customer.dto.Check2AuthDto;
import com.customer.dto.ReissueDto;
import com.customer.service.AuthService;
import com.customer.service.FidoCacheService;
import com.customer.service.UserCacheService;
import com.customer.util.AES256Cipher;
import com.customer.util.Const;
//import com.customer.type.MediaType;
//import com.customer.type.MediaTypeConverter;
import com.customer.util.DtoBuilder;
import com.customer.vo.CheckSmsVo;
import com.customer.vo.FidoCallbackVo;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 2차인증 컨트롤러
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})
@RestController
@RequestMapping("api/v1")
@Api(tags = {"2차 인증"})
public class FidoController {
	
	/** SUCCESS */
	private final static String SUCCESS = "SUCCESS";
	/** FAIL */
	private final static String FAIL = "FAIL";
	
	/** 사용자 정보 임시 저장 서비스 */
	@Autowired
	private UserCacheService userCacheService;
	
	/** FIDO 정보 임시 저장 서비스 */ 
	private FidoCacheService fidoCacheService = FidoCacheService.getSingletoneService();
	
	/** 인증 서비스 */
	@Autowired
	private AuthService authService;

	/** DTO 생성 헬퍼 클래스 */
	@Autowired
	private DtoBuilder dtoBuilder;
	
	/** 로거 */
	private final static Logger LOGGER = LoggerFactory.getLogger(FidoController.class);

	/**
	 * 2차인증  FIDO Return URL
	 * 
	 * @author : david
	 * @param : HttpServletRequest, HttpServletResponse
	 * @return ResponseEntity
	 * @Date : 2022. 02. 24
	 * @Method Name : checkSms
	 */
	@PostMapping("/fido_callback")
	@ApiOperation(value = "FIDO 콜백 API", response = ReissueDto.class)
	public ResponseEntity<?> fidoCallback(final HttpServletRequest request, final HttpServletResponse response) {
		
		LOGGER.info("fido_callback : Start");
		// AES256Cipher aes = new AES256Cipher(authService.getMpassSecretKey());
		ObjectMapper om = new ObjectMapper();
		StringBuffer sb = new StringBuffer();
		FidoCallbackVo fidoCallbackVo;
		String fidoDecrypted;
		String fidoEncrypted = null;
		AES256Cipher.setKey(authService.getMpassSecretKey());
		
		try (
			InputStream		is = request.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);	
		){

			String line;
			while((line = br.readLine()) != null) {
				sb.append(line);
			}
			
			fidoEncrypted = sb.toString();
			fidoDecrypted = AES256Cipher.decode(fidoEncrypted);
			
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug("FIDO CALLBACK Decrypted : " + fidoDecrypted);
			}

			fidoCallbackVo = om.readValue(fidoDecrypted, FidoCallbackVo.class);
			
			/* 호출 실제 예시  
				{
					"uid":"H19900SWPSTL1",	// 사번
					"fid":"eyJ0eXAiOi....hAS7cWmPA-gFehCQ", // FIDO 요청시 보냈던 userKey
					"result":"S", // S or F
					"company":"H199_W",	// 회사코드
					"did":"355500076545938", // 단말 식별자
					"msg":"Operation completed successfully."
				}
			 */
			
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug("FIDO CALLBACK SAVE : ]" + fidoCallbackVo.getResult() + "[" + fidoCallbackVo.getFid().length() + "] " + fidoCallbackVo.getFid());
			}
			
			
			fidoCacheService.setFidoResult(fidoCallbackVo.getFid(), fidoCallbackVo.getResult());

		} catch(Exception e) {
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug(e.getMessage());
			}
		} 
		
		return ResponseEntity.status(HttpStatus.OK).header("Content-Type", "application/json").body(fidoEncrypted);
	}
	
	/**
	 * 2차인증  SMS 코드 일치여부 확인
	 * 
	 * @author : david
	 * @param : CheckSmsVo
	 * @return Check2AuthDto
	 * @Date : 2022. 02. 24
	 * @Method Name : checkSms
	 */
	@PostMapping("checkSms")
	@ApiOperation(value = "2차인증  SMS 코드 일치여부 확인", response = Check2AuthDto.class)
	public Check2AuthDto checkSms(@RequestBody final CheckSmsVo checkVo) {
		
		Check2AuthDto dto = new Check2AuthDto();
		Check2AuthDto.Payload payload = dto.getData();
//		ServletRequestAttributes attr = (ServletRequestAttributes)RequestContextHolder.currentRequestAttributes();
//		HttpServletResponse response = attr.getResponse();
		Long userId;
		
		try {
			DecodedJWT decodedJwt = JWT.require(Algorithm.HMAC512(JwtProperties.SECRET)).build().verify(checkVo.getRefJwt());
			userId = decodedJwt.getClaim("id").asLong();
		} catch(JWTVerificationException e) {
			return dtoBuilder.buildCheck2AuthDto(FAIL, "유효하지 않는 JWT 입니다", null);
		}
		
		if(userId != null) {	
			String savedCode = userCacheService.getSMSCode(checkVo.getRefJwt());
			
			if(savedCode == null) {
				payload.setResult(2);
				return dtoBuilder.buildCheck2AuthDto(FAIL, "발송된 SMS 코드가 없습니다.", payload);
			}
			 
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug("Check SMS " + savedCode + " " + checkVo.getCode());
			}
			
				
			if(!savedCode.equals(checkVo.getCode())) {
				payload.setResult(1);
				return dtoBuilder.buildCheck2AuthDto(FAIL, "SMS 인증코드가 일치하지 않습니다.", payload);
			}
			
			payload.setResult(0);
			return dtoBuilder.buildCheck2AuthDto(SUCCESS, "SMS 인증코드가 일치합니다.", payload);
		}

		return dtoBuilder.buildCheck2AuthDto(FAIL, "유효하지 않거나 만료된 Refresh JWT 입니다", null);
	}
	
	
	/**
	 * 2차인증  Fido 결과조회
	 * 
	 * @author : david
	 * @param : CheckSmsVo
	 * @return Check2AuthDto
	 * @Date : 2022. 02. 24
	 * @Method Name : checkFido
	 */
	@PostMapping("checkFido")
	@ApiOperation(value = "2차인증  Fido 결과조회", response = Check2AuthDto.class)
	public Check2AuthDto checkFido(@RequestBody final CheckSmsVo checkVo) {
		
		Check2AuthDto.Payload payload = new Check2AuthDto().getData();
//		ServletRequestAttributes attr = (ServletRequestAttributes)RequestContextHolder.currentRequestAttributes();
//		HttpServletResponse response = attr.getResponse();
		Long userId;
		
//		if(LOGGER.isDebugEnabled()) {
//			LOGGER.debug("Check FIDO Request JWT " + checkVo.getRefJwt());
//		}
		
		try {
			DecodedJWT decodedJwt = JWT.require(Algorithm.HMAC512(JwtProperties.SECRET)).build().verify(checkVo.getRefJwt());
			userId = decodedJwt.getClaim("id").asLong();
		} catch(JWTVerificationException e) {
			payload.setResult(2);
			return dtoBuilder.buildCheck2AuthDto(FAIL, "요청되지 않은 JWT 입니다", payload);
		}
		
		/*
		 * 
		 * 0: FIDO 인증 완료
		 * 1: 인증안됨.
		 * 2: 요청되지 않은 사용자
		 * 
		 */
		if(userId != null) {	
			String savedCode = fidoCacheService.getFidoResult(checkVo.getRefJwt());
				
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug("FIDO Check Result ]" + savedCode + "[" + checkVo.getRefJwt().length() + "] " + checkVo.getRefJwt());
			}
			
			if(savedCode == null) {
				payload.setResult(1);
				return dtoBuilder.buildCheck2AuthDto(FAIL, "사용자 인증이 완료되지 않았습니다.", payload);
			}
	
			if(Const.FIDO_AUTH_SUCCESS.equals(savedCode)) {
				payload.setResult(0);
				return dtoBuilder.buildCheck2AuthDto(SUCCESS, "사용자가 인증되었습니다.", payload);
			}
			
			payload.setResult(3);
			return dtoBuilder.buildCheck2AuthDto(FAIL, "사용자 인증이 실패했습니다.", payload);
		}

		payload.setResult(2);
		return dtoBuilder.buildCheck2AuthDto(FAIL, "유효하지 않거나 만료된 Refresh JWT 입니다", null);
	}
}
