package com.customer.controller;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.customer.config.jwt.JwtProperties;
import com.customer.dto.LogoutDto;
import com.customer.dto.ReissueDto;
import com.customer.dto.UserInfoDto;
import com.customer.entity.UserJwt;
import com.customer.entity.UserLog;
import com.customer.repository.UserJwtRepository;
import com.customer.repository.UserLogRepository;
import com.customer.service.AuthService;
import com.customer.util.Const;
import com.customer.util.DtoBuilder;
import com.customer.vo.ReissueJwtVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;



/**
 * 사용자 인증 컨트롤러
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

@RestController
@RequestMapping("api/v1")
@Api(tags = {"사용자 인증 API"})
public class AuthController {
	

	
	/** 사용자 인증 서비스 */
	@Autowired
	private AuthService authService;

	/** 사용자 인증 로그 저장 */
	@Autowired
	private UserLogRepository userLogRepository;
	
	/** 사용자 JWT 저장 */
	@Autowired
	private UserJwtRepository userJwtRepository;

	/**  DTO 생성 헬퍼 클래스 */
	@Autowired
	private DtoBuilder dtoBuilder;
	
	/** 로거 */
	private final static Logger LOGGER = LoggerFactory.getLogger(AuthController.class);
	
	/**
	 * 사용자 로그아웃
	 * 
	 * @author : david
	 * @param : RequestHeader
	 * @return LogoutDto
	 * @Date : 2022. 02. 24
	 * @Method Name : logout
	 */
	@PostMapping("logout")
	@ResponseBody
	@ApiOperation(value = "로그아웃", response = LogoutDto.class)
	public LogoutDto logout(
			@RequestHeader(value = "acsJwt") final String authorization
	) {
		String acsToken = authorization.replace(JwtProperties.TOKEN_PREFIX, "");
		Long userId;
		String userName;
		
		try {
			DecodedJWT decodedJwt = JWT.require(Algorithm.HMAC512(JwtProperties.SECRET)).build().verify(acsToken);
			userId = decodedJwt.getClaim("id").asLong();
			userName = decodedJwt.getClaim("username").asString();
		} catch(Exception e) {
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug(e.getMessage());
			}
			return dtoBuilder.buildLogoutDto(Const.RESULT_FAIL, "유효하지 않는 JWT 입니다");
		}
		
		if (userId != null) {

			try {
				// Optional<UserEntity> opt = authService.findById(userId);
				// 로그아웃 히스토리 저장
				UserLog userLog = new UserLog();
				// userLog.setUserId(opt.get().getId());
				userLog.setUserName(userName);
				userLog.setEvtTpCd(2);	// 1 : login, 2: logout
				userLog.setCltTpCd(3);	// 1 : Android, 2 : iOS, 3 : Web
				userLog.setEvtDate(new Date());
				userLogRepository.save(userLog);
	
				// JWT 정보 삭제 
				UserJwt userJwt = userJwtRepository.findByAccJwt(acsToken);
				if(userJwt != null) {
					userJwtRepository.delete(userJwt);
				}
			} catch(Exception e) {
				
				// 사용자 db 가 없으므로 예외가 발생한다.
			}
			
			SecurityContextHolder.getContext().setAuthentication(null);
			
			// writeResultPayload(RESULT_SUCCESS, "로그아웃 성공", null);
			return dtoBuilder.buildLogoutDto(Const.RESULT_SUCCESS, "로그아웃 성공");
		} else {
			// writeResultPayload(RESULT_SUCCESS, "존재하지 않는 사용자입니다", null);
			return dtoBuilder.buildLogoutDto("002", "존재하지 않는 사용자입니다");
		}
	}
	

	/**
	 * 사용자 정보 조회
	 * 
	 * @author : david
	 * @param : RequestHeader
	 * @return UserInfoDto
	 * @Date : 2022. 02. 24
	 * @Method Name : info
	 */
	@PostMapping("userinfo")
	@ApiOperation(value = "사용자 정보 조회", response = UserInfoDto.class)
	public UserInfoDto info(@RequestHeader(value = "Authorization") final String authorization) {
		Long userId;

		// LOGGER.info("authorization " + authorization);
		// Bearer ......acsToken......  에서 'Bearer ' 를 제거하여 AccessToken 만 추출. 
		String acsToken = authorization.replace(JwtProperties.TOKEN_PREFIX, "");
		if(acsToken == null) {
			return dtoBuilder.buildUserInfoDto(Const.RESULT_FAIL, "Access JWT 는 필수입니다", null);
		} 		

		
		try {
			DecodedJWT decodedJwt = JWT.require(Algorithm.HMAC512(JwtProperties.SECRET)).build().verify(acsToken);
			userId = decodedJwt.getClaim("id").asLong();
		} catch(JWTVerificationException e) {
			return dtoBuilder.buildUserInfoDto(Const.RESULT_FAIL, "유효하지 않는 JWT 입니다", null);
		}
		
		if (userId != null) {
//			
			UserInfoDto.Payload payload = new UserInfoDto().getData();
//			payload.from(user);
			
			return dtoBuilder.buildUserInfoDto(Const.RESULT_SUCCESS, "조회 성공", payload);
		}
		else
		{
			return dtoBuilder.buildUserInfoDto("0001", "존재하지 않는 사용자 입니다", null);
		}
	}

	/**
	 * 사용자 Access JWT 갱신
	 * 
	 * @author : david
	 * @param : @RequestHeader, @RequestBody
	 * @return ReissueDto
	 * @Date : 2022. 02. 24
	 * @Method Name : reissueJwt
	 */
	@PostMapping("reissueJwt")
	@ApiOperation(value = "사용자 Access JWT 갱신", response = ReissueDto.class)
	public ReissueDto reissueJwt(
			@RequestHeader(value="acsJwt") final String authorization, 
			@RequestBody final ReissueJwtVo jwtVo) {
		
		LocalDateTime acsLTime = LocalDateTime.now().plusHours(JwtProperties.ACS_EXP_HOUR);
		LocalDateTime refLTime = LocalDateTime.now().plusHours(JwtProperties.REF_EXP_HOUR);
		Date acsTime = Timestamp.valueOf(acsLTime);
		Date refTime = Timestamp.valueOf(refLTime);
		
		ServletRequestAttributes attr = (ServletRequestAttributes)RequestContextHolder.currentRequestAttributes();
		HttpServletResponse response = attr.getResponse();
		String acsToken = authorization.replace(JwtProperties.TOKEN_PREFIX, "");
		Long userId;
		String username;
		String realname;
		String email;
		String phoneNumber;
		String userToken;
		String siteId;
		String type;
		
		DecodedJWT decodedJwt;
		
		try {
			decodedJwt = JWT.require(Algorithm.HMAC512(JwtProperties.SECRET)).build().verify(acsToken);
			userId = decodedJwt.getClaim("id").asLong();
			username = decodedJwt.getClaim("username").asString();
			realname = decodedJwt.getClaim("realname").asString();
			email = decodedJwt.getClaim("email").asString();
			phoneNumber = decodedJwt.getClaim("phoneNumber").asString();
			userToken = decodedJwt.getClaim("userToken").asString();
			siteId = decodedJwt.getClaim("siteId").asString();
			type = decodedJwt.getClaim("type").asString();
	
			
		} catch(JWTVerificationException e) {
			return dtoBuilder.buildReissueDto(Const.RESULT_FAIL, "유효하지 않는 JWT 입니다", null);
		}
		
		if(userId != null) {	

			String acsJwt = JWT.create()
					.withSubject(username)
					.withExpiresAt(acsTime)
					.withClaim("id", userId)
					.withClaim("username", username)
					.withClaim("realname", realname)
					.withClaim("email", email)
					.withClaim("phoneNumber", phoneNumber)
					.withClaim("siteId", siteId)
					.withClaim("type", type)
					.sign(Algorithm.HMAC512(JwtProperties.SECRET));
			
			String refJwt = JWT.create()
					.withSubject(username)
					.withExpiresAt(refTime)
					.withClaim("id", userId)
					.withClaim("username", username)
//					.withClaim("realname", realname)
//					.withClaim("email", email)
//					.withClaim("phoneNumber", phoneNumber)
//					.withClaim("siteId", siteId)
					.withClaim("type", type)
					.sign(Algorithm.HMAC512(JwtProperties.SECRET));
			
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug("생성된 acsJwt : " + acsJwt);
				LOGGER.debug("생성된 refJwt : " + refJwt);
			}
			
			UserJwt userJwt = userJwtRepository.findByUserName(username); // .getId());
			
			// 여기서 없으면 로그인을 거치지 않거나 논리적인 오류.
			if(userJwt == null) {
				return dtoBuilder.buildReissueDto(Const.RESULT_FAIL, "유효하지 않거나 만료된 Access JWT 입니다", null);
			}
			
			userJwt.setUserName(username);
		    userJwt.setAccJwt(acsJwt);
		    userJwt.setAccJwtExp(acsTime);
		    userJwt.setRefJwt(refJwt);
		    userJwt.setRefJwtExp(refTime);
		    userJwt.setRefDate(new Date());
		    
			userJwtRepository.save(userJwt);
			
			response.addHeader(JwtProperties.HEADER_STRING, JwtProperties.TOKEN_PREFIX + acsJwt);

			ReissueDto.Payload payload = new ReissueDto().getData();
			payload.setAcsJwt(acsJwt);
			payload.setAcsJwtExpired(acsTime.getTime());
			payload.setRefJwt(refJwt);
			payload.setRefJwtExpired(refTime.getTime());
			
			return dtoBuilder.buildReissueDto(Const.RESULT_SUCCESS, "JWT 갱신 성공", payload);
		}

		return dtoBuilder.buildReissueDto(Const.RESULT_FAIL, "유효하지 않거나 만료된 Access JWT 입니다", null);
	}
	

	
}
