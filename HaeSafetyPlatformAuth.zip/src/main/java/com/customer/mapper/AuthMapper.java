package com.customer.mapper;

import java.util.List;

import org.springframework.stereotype.Component;

import com.customer.entity.UserEntity;
/**
 * 사요앚 정보 조회용 Mapper 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */

@Component
public interface AuthMapper {

	/** 사용자 정보 조회*/
    UserEntity getUserInfo(long userId);
    
	/** 사용자 목록 조회*/
    List<UserEntity> getUserAll();
}
