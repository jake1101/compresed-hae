package com.customer.mapper;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * Wisecan SMS 발송용 Mapper 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

@Component
public interface WisecanMapper {

	/**
	 * Wisecan SMS 발송 저장
	 * 
	 * @author : david
	 * @param : phoneNo, content
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : insertSMS
	 */
    void insertSMS(@Param("fcallback") String smsSender, @Param("fdestine") String phoneNo, @Param("ftext") String content);
}
