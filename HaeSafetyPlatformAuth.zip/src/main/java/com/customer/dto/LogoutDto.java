package com.customer.dto;

import lombok.Data;

/**
 * 2차인증 경과 DTO 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@Data
public class LogoutDto extends BaseDto {

}

