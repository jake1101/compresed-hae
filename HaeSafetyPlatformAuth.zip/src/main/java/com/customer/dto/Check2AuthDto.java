package com.customer.dto;

import lombok.Data;

/**
 * 2차인증 경과 DTO 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@Data
public class Check2AuthDto extends BaseDto {

	/** 결과 데이터 */
    public Payload data = new Payload();
    
	/** 결과 데이터 */
	@Data
	public class Payload {
		/** 결과 코드 */
	    private Integer result;
	}
	
}

