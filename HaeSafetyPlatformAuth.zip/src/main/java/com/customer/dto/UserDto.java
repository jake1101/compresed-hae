package com.customer.dto;

import lombok.Data;


/**
 * 사용자 정보  DTO 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@Data
public class UserDto extends BaseDto {

	/** 결과 데이터 */
    public Payload data = new Payload();

	/** 결과 데이터 */
	@Data
	public class Payload {

		/** 사용자 이름 */
	    private String username;

		/** 전화번호 */
	    private String phoneNo;

		/** 이메일 주소 */
	    private String email;

		/** 회사 코드 */
	    private String cmpCd;

		/** 역할 */
	    private String roles;
	}
	
}

