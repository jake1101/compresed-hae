package com.customer.dto;

import com.customer.dto.UserDto.Payload;
import com.customer.entity.UserEntity;

import lombok.Data;

/**
 * 사용자 정보  DTO 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

@Data
public class UserInfoDto extends BaseDto {
	/** 결과 데이터 */
    public Payload data = new Payload();

	/** 결과 데이터 */
	@Data
	public class Payload {

		/** 사용자 이름 */
	    private String username;

		/** 전화번호 */
	    private String phoneNumber;

		/** 이메일 주소 */
	    private String email;

		/** 회사 코드 */
	    private String cmpCd;

		/** 역할 */
	    private String roles;
	    
		/**
		 * UserDTO 로부터 데이터 복제
		 * 
		 * @author : david
		 * @param : HttpServletRequest, HttpServletResponse
		 * @return ResultDto
		 * @Date : 2022. 02. 24
		 * @Method Name : reqAccessJwt
		 */
	    public void from(final UserEntity dto) {
			
	    	setUsername(dto.getUsername());
	    	setPhoneNumber(dto.getPhoneNumber());
	    	setEmail(dto.getEmail());
	    	setCmpCd(dto.getCmpCd());
	    	setRoles(dto.getRoles());
	    }
	}
}

