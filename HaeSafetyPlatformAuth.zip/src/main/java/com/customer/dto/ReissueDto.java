package com.customer.dto;

import lombok.Data;

/**
 *  JWT 갱신 결과 DTO 
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */
@Data
public class ReissueDto extends BaseDto {

	/** 결과 데이터 */
    public Payload data = new Payload();
    
	/** 결과 데이터 */
	@Data
	public class Payload {

		/**AccessJWT */
	    private String acsJwt;
		/** AccessJWT Expire */
	    private Long acsJwtExpired;
		/** RefreshJWT */
	    private String refJwt;
		/** RefreshJWT Expire */
	    private Long refJwtExpired;
	}
	
}

