package com.customer.vo;

import lombok.Data;

/**
 * ReissueJwtVo 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class ReissueJwtVo {
	/** Refresh JWT */
	private String refJwt;
}
