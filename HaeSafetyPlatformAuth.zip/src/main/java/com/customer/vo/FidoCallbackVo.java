package com.customer.vo;

import lombok.Data;

/**
 * FidoCallbackVo 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class FidoCallbackVo {
	/** 사번 */
	private String uid; 	// "H19900SWPSTL1",	// 사번
	/** FIDO 서버 식벽자 */
	private String fid; 	// "eyJ0eXAiOi....hAS7cWmPA-gFehCQ", // FIDO 요청시 보냈던 userKey
	/** 처리 결과 */
	private String result; 	// "S", // S or F
	/** 회사 코드 */
	private String company; // "H199_W",	// 회사코드
	/** 단말 식별자 */
	private String did; 	// "355500076545938", // 단말 식별자
	/** 결과 메시지 */
	private String msg;	 	// "Operation completed successfully."
}
