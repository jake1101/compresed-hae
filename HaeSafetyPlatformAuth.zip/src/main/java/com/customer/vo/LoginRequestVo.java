package com.customer.vo;

import lombok.Data;

/**
 * LoginRequestVo 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class LoginRequestVo {
	/** 사용자 아이디 */
	private String username;
	/** 비밀번호 */
	private String password;
//	private boolean encrypted;
}
