package com.customer.vo;

import lombok.Data;

/**
 * CheckSmsVo 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class CheckSmsVo {
	/** Access JWT */
	private String refJwt;
	/** SMS code */
	private String code;
}
