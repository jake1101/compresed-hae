package com.customer.vo;

import lombok.Data;

/**
 * UserVo 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

@Data
public class UserVo {

	/** 사용자 이름 */
    private String username;
    /** 핸드폰 번호 */
    private String phoneNo;
    /** 이메일 주소 */
    String email;
    /** 회사 코드 */
    private String cmpCd;
    /** 역할 목록 */
    private String roles;

}

