package com.customer.vo;

import lombok.Data;


/**
 * OtpVo 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class OtpVo {
	/** 인증 결과 코드 */
	private String result;
	/** 결과 메시지 */
	private String msg;
	/** 인증타입 */
	private String authType;
}
