package com.customer.vo;

import lombok.Data;

/**
 * FidoVo 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class FidoVo {
	/** 단말 식별자 */
	private String deviceid; // 355500076545938
	/** 계열사 식별자 */
	private String site; // H199_W
	/** 처리 결과 */
	private String status; // 1200: 성공 1500: 임시사용자, 9025: 등록되지 않은 사용자
	/** 사번 */
	private String userid; // H19900SWPSTL1
}
