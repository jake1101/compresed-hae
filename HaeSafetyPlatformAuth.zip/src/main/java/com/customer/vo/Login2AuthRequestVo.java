package com.customer.vo;

import lombok.Data;

/**
 * Login2AuthRequestVo 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class Login2AuthRequestVo {
	/** 사용자 이름 */
	private String username;
	/** 비밀번호 */
	private String password;
	/** 인증 종류 */
	private String authType;
	/** OTP 코드값 */
	private String otpCode;
}
