package com.customer.type;

/**
 *   MediaType enum
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
public enum MediaType {
    EMAIL("EMAIL"),
    SMS("SMS"),
    KAKAO("KAKAO"),
    APP("APP"),
    WEB("WEB");

	/** MediaType 코드 */
    String code;

    MediaType(final String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
