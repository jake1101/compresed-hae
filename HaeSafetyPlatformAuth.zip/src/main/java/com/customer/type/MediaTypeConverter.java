package com.customer.type;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
//import java.util.stream.Stream;


/**
 *   MediaTypeConverter 
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UnnecessaryAnnotationValueElement",
	"PMD.PrematureDeclaration"
})

@Converter(autoApply = true)
public class MediaTypeConverter implements AttributeConverter<MediaType, String> {
 
    @Override
    public String convertToDatabaseColumn(final MediaType category) {
        if (category == null) {
            return null;
        }
        return category.getCode();
    }

    @Override
    public MediaType convertToEntityAttribute(final String code) {
        if (code == null) {
            return null;
        }

//        return Stream.of(MediaType.values())
//          .filter(c -> c.getCode().equals((code)))
//          .findFirst()
//          .orElseThrow(IllegalArgumentException::new);
        
        return null;
    }
}