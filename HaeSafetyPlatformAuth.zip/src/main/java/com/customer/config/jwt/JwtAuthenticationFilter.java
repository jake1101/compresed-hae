package com.customer.config.jwt;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.client.RestTemplate;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.customer.config.auth.PrincipalDetails;
import com.customer.entity.UserJwt;
import com.customer.entity.UserLog;
import com.customer.repository.UserJwtRepository;
import com.customer.repository.UserLogRepository;
import com.customer.service.AuthService;
import com.customer.service.UserCacheService;
import com.customer.util.Const;
import com.customer.vo.LoginRequestVo;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.RequiredArgsConstructor;


/**
 * JwtAuthentication2Filter 2차 인증
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UseShortArrayInitializer",
	"PMD.CloseResource"
})

@RequiredArgsConstructor
public class JwtAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

	
	/** 사용자 인증 로그 */
	private UserLogRepository userLogRepository;
	/** 사용자 JWT */
	private UserJwtRepository userJwtRepository;
	/** 인증관리자 */
	private AuthenticationManager authenticationManager;
	/** 인증서비스 */
	private AuthService authService;
	/** 사용자 정보 임시 저장 */
	private UserCacheService userCacheService;

	/**
	 * JwtAuthenticationFilter 필터 생성자 
	 * 
	 * @author : david
	 * @param AuthenticationManager, UserLogRepository, UserJwtRepository, AuthService, WisecanService, UserCacheService
	 * @Date : 2022. 02. 24
	 * @Method Name : loadUserByUsername
	 */
	public JwtAuthenticationFilter(final AuthenticationManager authenticationManager,
			final UserLogRepository userLogRepository, final UserJwtRepository userJwtRepository,
			final AuthService authService, final UserCacheService userCacheService) {

		super();

		this.authenticationManager = authenticationManager;
		this.userLogRepository = userLogRepository;
		this.userJwtRepository = userJwtRepository;
		this.authService = authService;
		this.userCacheService = userCacheService;
	}

	private String asText(final JsonNode node) {

		if (node == null) {
			return "";
		}

		return node.asText();
	}

	private void procLoginError(final HttpServletResponse response, final String message) {

		JSONObject loginResult = new JSONObject();

		loginResult.put(Const.RESULT, "0001");
		loginResult.put(Const.MESSAGE, message);

		try (PrintWriter w = response.getWriter()) {

			w.print(loginResult.toJSONString());
			w.flush();
		} catch (Exception e) {

			if (logger.isDebugEnabled()) {
				logger.debug(e.getMessage());
			}
		}
	}

	@Override
	public Authentication attemptAuthentication(final HttpServletRequest request, final HttpServletResponse response)
			throws AuthenticationException {

		ObjectNode headerNode;
		ObjectNode bodyNode;

		logger.debug("JwtAuthenticationFilter : Start");
		ObjectMapper om = new ObjectMapper();
		LoginRequestVo loginRequestDto = null;
		StringBuffer sb = new StringBuffer();

		try (InputStream is = request.getInputStream();
				InputStreamReader isr = new InputStreamReader(is);
				BufferedReader br = new BufferedReader(isr);) {

			String line;
			while ((line = br.readLine()) != null) {

				if (logger.isDebugEnabled()) {
					logger.debug(">>> " + line);
				}
				sb.append(line);
			}

			loginRequestDto = om.readValue(sb.toString(), LoginRequestVo.class);

		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				logger.debug(e.getMessage());
			}
		}

		if(logger.isDebugEnabled()) {
			logger.debug("JwtAuthenticationFilter : " + loginRequestDto);
		}

		userCacheService.setPassword(loginRequestDto.getUsername(), loginRequestDto.getPassword());

		ObjectMapper objectMapper = new ObjectMapper();
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		String pwdEncrypted = loginRequestDto.getPassword();

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("userId", loginRequestDto.getUsername());
		jsonObject.put("password", pwdEncrypted);

		HttpEntity<String> jsonRequest = new HttpEntity<String>(jsonObject.toString(), headers);

		if(logger.isDebugEnabled()) {
			logger.debug("loginApiUrl : " + authService.getLoginApiUrl());
		}
		
		String personResultAsJsonStr = restTemplate.postForObject(authService.getLoginApiUrl(), jsonRequest,
				String.class);
		JsonNode root;

		try {
			root = objectMapper.readTree(personResultAsJsonStr);
			if(logger.isDebugEnabled()) {
				logger.debug("Raycom API : " + root);
			}
			
			headerNode = (ObjectNode) root.get("header");
			if (headerNode.get("code").asInt() != Const.RAYCOM_SUCCESS) {
				// procLoginError(response, headerNode.get("message").asText());
				procLoginError(response, "로그인 실패");
				return null;
			}

			if (!(root.get("body") instanceof ObjectNode)) {
				procLoginError(response, "로그인 실패");
				return null;
			}

			bodyNode = (ObjectNode) root.get("body");

			/*
			 * logger.debug("Header.code 	: " + headerNode.get("code").asInt());
			 * logger.debug("Header.message 	: " + asText(headerNode.get("message")));
			 * logger.debug("Header.krMessage: " + asText(headerNode.get("krMessage")));
			 * 
			 * logger.debug("Body.krMessage	: " + asText(bodyNode.get("name")));
			 * logger.debug("Body.email		: " + asText(bodyNode.get("email")));
			 * logger.debug("Body.phoneNumber: " + asText(bodyNode.get("phoneNumber")));
			 * logger.debug("Body.userToken	: " + asText(bodyNode.get("userToken")));
			 * logger.debug("Body.accessLevel: " + asText(bodyNode.get("accessLevel")));
			 * logger.debug("Body.siteId		: " + asText(bodyNode.get("siteId")));
			 */

		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				logger.debug(e.getMessage());
			}
			return null;
		}

		UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
				loginRequestDto.getUsername(), loginRequestDto.getPassword());

		if(logger.isDebugEnabled()) {
			logger.debug("JwtAuthenticationFilter : " + authenticationToken);
		}
		
		Authentication authentication = authenticationManager.authenticate(authenticationToken);
		
		
		/* 삭제 예정
		PrincipalDetails principalDetails = (PrincipalDetails) authentication.getPrincipal();

		UserEntity user = principalDetails.getUser();

		user.setRealname(asText(bodyNode.get("name")));
		user.setEmail(asText(bodyNode.get("email")));
		user.setPhoneNumber(asText(bodyNode.get("phoneNumber")));
		user.setUserToken(asText(bodyNode.get("userToken")));
		user.setAccessLevel(asText(bodyNode.get("accessLevel")));
		user.setSiteId(asText(bodyNode.get("siteId")));

		if(logger.isDebugEnabled()) {
			logger.debug("Authentication :  " + user);
		}*/ 

		return authentication;
	}

	@Override
	protected void successfulAuthentication(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain chain, final Authentication authResult) throws IOException, ServletException {

		PrincipalDetails principalDetails = (PrincipalDetails) authResult.getPrincipal();

		LocalDateTime acsLTime = LocalDateTime.now().plusHours(JwtProperties.ACS_EXP_HOUR);
		LocalDateTime refLTime = LocalDateTime.now().plusHours(JwtProperties.REF_EXP_HOUR);
		Date acsTime = Timestamp.valueOf(acsLTime);
		Date refTime = Timestamp.valueOf(refLTime);

		String acsJwt = JWT.create().withSubject(principalDetails.getUsername())
				.withExpiresAt(acsTime)
				.withClaim("id", principalDetails.getUser().getId())
				.withClaim("username", principalDetails.getUser().getUsername())
				.withClaim("realname", principalDetails.getUser().getRealname())
				.withClaim("email", principalDetails.getUser().getEmail())
				.withClaim("phoneNumber", principalDetails.getUser().getPhoneNumber())
				.withClaim("userToken", principalDetails.getUser().getUserToken())
				.withClaim("siteId", principalDetails.getUser().getSiteId()).withClaim("type", "acs")
				.sign(Algorithm.HMAC512(JwtProperties.SECRET));

		String refJwt = JWT.create().withSubject(principalDetails.getUsername())
				.withExpiresAt(refTime)
				.withClaim("id", principalDetails.getUser().getId())
				.withClaim("username", principalDetails.getUser().getUsername())
				.withClaim("realname", principalDetails.getUser().getRealname())
				.withClaim("email", principalDetails.getUser().getEmail())
				.withClaim("phoneNumber", principalDetails.getUser().getPhoneNumber())
				.withClaim("siteId", principalDetails.getUser().getSiteId()).withClaim("type", "ref")
				.sign(Algorithm.HMAC512(JwtProperties.SECRET));
		
		UserLog userLog = new UserLog();
		userLog.setUserName(principalDetails.getUser().getUsername());
		userLog.setEvtTpCd(1); // 1 : login, 2: logout
		userLog.setCltTpCd(3); // 1 : Android, 2 : iOS, 3 : Web
		userLog.setEvtDate(new Date());
		userLogRepository.save(userLog);

		UserJwt userJwt = userJwtRepository.findByUserName(principalDetails.getUser().getUsername());

		if (userJwt == null) {
			userJwt = new UserJwt();
			userJwt.setIssDate(new Date());
		}

		userJwt.setUserName(principalDetails.getUser().getUsername());
		userJwt.setAccJwt(acsJwt);
		userJwt.setAccJwtExp(acsTime);
		userJwt.setRefJwt(refJwt);
		userJwt.setRefJwtExp(refTime);
		userJwt.setRefDate(new Date());
		
		userJwtRepository.save(userJwt);

		response.addHeader(JwtProperties.HEADER_STRING, JwtProperties.TOKEN_PREFIX + acsJwt);
		response.setContentType("application/json");

		JSONObject loginResult = new JSONObject();
		JSONObject joData = new JSONObject();
		joData.put("acsJwt", acsJwt);
		joData.put("acsJwtExpired", acsTime.getTime());
		joData.put("refJwt", refJwt);
		joData.put("refJwtExpired", refTime.getTime());

		loginResult.put("result", "0000");
		loginResult.put("message", "로그인 성공");
		loginResult.put("data", joData);

		PrintWriter w = response.getWriter();
		w.print(loginResult.toJSONString());
		w.flush();
		w.close();
	}
}
