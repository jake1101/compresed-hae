package com.customer.config.jwt;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Locale;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.springframework.http.*;
import org.springframework.security.authentication.*;
import org.springframework.security.core.*;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.client.RestTemplate;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.customer.config.auth.PrincipalDetails;
import com.customer.entity.*;
import com.customer.repository.*;
import com.customer.service.*;
import com.customer.util.AES256Cipher;
import com.customer.util.Const;
import com.customer.util.SslUtil;
import com.customer.vo.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.RequiredArgsConstructor;

/**
 * JwtAuthentication2Filter 2차 인증 
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UseShortArrayInitializer",
	"PMD.CloseResource"
})

@RequiredArgsConstructor
public class JwtAuthentication2Filter extends UsernamePasswordAuthenticationFilter {

	
	private transient String smsSender;
	
	/** 사용자 인증 로그 */
	private UserLogRepository userLogRepository;
	/** 사용자 JWT  */
	private UserJwtRepository userJwtRepository;
	/** 인증관리자 */
	private AuthenticationManager authMan;
	/** 인증서비스 */
	private AuthService authService;
	/** Wisecan SMS 발송  */
	private WisecanService wisecanService;
	/** 사용자 정보 임시 저장 */
	private UserCacheService userCacheService;

		
	/**
	 * JwtAuthentication2Filter 필터 생성자 
	 * 
	 * @author : david
	 * @param AuthenticationManager, UserLogRepository, UserJwtRepository, AuthService, WisecanService, UserCacheService
	 * @Date : 2022. 02. 24
	 * @Method Name : loadUserByUsername
	 */
	public JwtAuthentication2Filter(final AuthenticationManager authMan, final UserLogRepository userLogRepository,
			final UserJwtRepository userJwtRepository, final AuthService authService, final WisecanService wisecanService,
			final UserCacheService userCacheService, final String smsSender) {

		super();
		this.authMan = authMan;
		this.userLogRepository = userLogRepository;
		this.userJwtRepository = userJwtRepository;
		this.authService = authService;
		this.wisecanService = wisecanService;
		this.userCacheService = userCacheService;
		this.smsSender = smsSender;
		
		this.setFilterProcessesUrl("/login2auth");
	}

	private void procLoginError(final HttpServletResponse response, final String message) {

		JSONObject loginResult = new JSONObject();

		loginResult.put(Const.RESULT, "0001");
		loginResult.put(Const.MESSAGE, message);

		try (PrintWriter writer = response.getWriter()) {

			writer.print(loginResult.toJSONString());
			writer.flush();
		} catch (Exception e) {
			
			if(logger.isDebugEnabled()) {
				logger.debug(e.getMessage());
			}
		}
	}

	@Override
	public Authentication attemptAuthentication(final HttpServletRequest request, final HttpServletResponse response)
			throws AuthenticationException {

		ObjectNode headerNode;
		ObjectNode bodyNode = null;

		ObjectMapper omapper = new ObjectMapper();
		Login2AuthRequestVo loginRequestDto = null;
		StringBuffer sbuffer = new StringBuffer();

		try (InputStream istream = request.getInputStream();
			InputStreamReader isreader = new InputStreamReader(istream);
			BufferedReader breader = new BufferedReader(isreader);
		) {

			String line = null;
			while (true) {
				if (logger.isDebugEnabled()) {
					logger.debug(">>> " + line);
				}
				line = breader.readLine();
				if(line != null) {
					sbuffer.append(line);
				} else { 
					break;
				}
			}
			
			/* OLD Style 
			while ((line = breader.readLine()) != null) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(">>> " + line);
				}
				sbuffer.append(line);
			} */

			loginRequestDto = omapper.readValue(sbuffer.toString(), Login2AuthRequestVo.class);

		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				logger.debug(e.getMessage());
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug("JwtAuthenticationFilter : " + loginRequestDto);
		}

		userCacheService.setPassword(loginRequestDto.getUsername(), loginRequestDto.getPassword());
		userCacheService.setAuthType(loginRequestDto.getUsername(), loginRequestDto.getAuthType(),
				loginRequestDto.getOtpCode());

		ObjectMapper objectMapper = new ObjectMapper();
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		String pwdEncrypted = loginRequestDto.getPassword();

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("userId", loginRequestDto.getUsername());
		jsonObject.put("password", pwdEncrypted);

		HttpEntity<String> jsonRequest = new HttpEntity<String>(jsonObject.toString(), headers);

		if (logger.isDebugEnabled()) {
			logger.debug("loginApiUrl : " + authService.getLoginApiUrl());
		}

		String jsonStr = restTemplate.postForObject(authService.getLoginApiUrl(), jsonRequest,
				String.class);
		JsonNode root;

		try {
			root = objectMapper.readTree(jsonStr);

			if (logger.isDebugEnabled()) {
				logger.debug("Raycom API : " + root);
			}

			headerNode = (ObjectNode) root.get("header");
			if (headerNode.get(Const.CODE).asInt() != Const.RAYCOM_SUCCESS) {
				procLoginError(response, "로그인 실패");
				return null;
			}

			if (!(root.get("body") instanceof ObjectNode)) {
				procLoginError(response, "로그인 실패");
				return null;
			}

			bodyNode = (ObjectNode) root.get("body");

		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				logger.debug(e.getMessage());
			}
		}

		UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
				loginRequestDto.getUsername(), loginRequestDto.getPassword());

		Authentication authentication = authMan.authenticate(authToken);
		PrincipalDetails principalDetails = (PrincipalDetails) authentication.getPrincipal();

		UserEntity user = principalDetails.getUser();

		user.setRealname(bodyNode.get("name").asText());
		user.setEmail(bodyNode.get("email").asText());
		user.setPhoneNumber(bodyNode.get("phoneNumber").asText());
		user.setUserToken(bodyNode.get("userToken").asText());
		user.setAccessLevel(bodyNode.get("accessLevel").asText());
		user.setSiteId(bodyNode.get("siteId").asText());
		user.setInstituteId1(bodyNode.get("instituteId1").asText());
		user.setInstituteId2(bodyNode.get("instituteId2").asText());

		if (logger.isDebugEnabled()) {
			logger.debug("Authentication :  " + user);
		}

		return authentication;
	}

	@Override
	protected void successfulAuthentication(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain chain, final Authentication authResult) throws IOException, ServletException {

		LocalDateTime acsLTime = LocalDateTime.now().plusHours(JwtProperties.ACS_EXP_HOUR);
		LocalDateTime refLTime = LocalDateTime.now().plusHours(JwtProperties.REF_EXP_HOUR);
		Date acsTime = Timestamp.valueOf(acsLTime);
		Date refTime = Timestamp.valueOf(refLTime);

		JSONObject loginResult = new JSONObject();
		JSONObject joData = new JSONObject();
		ObjectMapper om = new ObjectMapper();
		AES256Cipher.setKey(authService.getMpassSecretKey());
		PrintWriter writer = response.getWriter();
		RestTemplate restTemplate = new RestTemplate();
		PrincipalDetails principalDetails = (PrincipalDetails) authResult.getPrincipal();

		// SSL Handshaking 무효화
		SslUtil.disableSslVerification();

		// 응답 설정
		response.setContentType("application/json");

		String acsJwt = JWT.create().withSubject(principalDetails.getUsername())
				.withExpiresAt(acsTime)
				.withClaim("id", principalDetails.getUser().getId())
				.withClaim("username", principalDetails.getUser().getUsername())
				.withClaim("realname", principalDetails.getUser().getRealname())
				.withClaim("email", principalDetails.getUser().getEmail())
				.withClaim("phoneNumber", principalDetails.getUser().getPhoneNumber())
				.withClaim("userToken", principalDetails.getUser().getUserToken())
				.withClaim("siteId", principalDetails.getUser().getSiteId())
				.withClaim("type", "acs")
				.sign(Algorithm.HMAC512(JwtProperties.SECRET));

		String refJwt = JWT.create().withSubject(principalDetails.getUsername())
				.withExpiresAt(refTime)
				.withClaim("id", principalDetails.getUser().getId())
				.withClaim("username", principalDetails.getUser().getUsername())
//				.withClaim("realname", principalDetails.getUser().getRealname())
//				.withClaim("email", principalDetails.getUser().getEmail())
//				.withClaim("phoneNumber", principalDetails.getUser().getPhoneNumber())
//				.withClaim("siteId", principalDetails.getUser().getSiteId())
				.withClaim("type", "ref")
				.sign(Algorithm.HMAC512(JwtProperties.SECRET));

		UserLog userLog = new UserLog();
		userLog.setUserName(principalDetails.getUser().getUsername());
		userLog.setEvtTpCd(1); // 1 : login, 2: logout
		userLog.setCltTpCd(3); // 1 : Android, 2 : iOS, 3 : Web
		userLog.setEvtDate(new Date());
		userLogRepository.save(userLog);

		UserJwt userJwt = userJwtRepository.findByUserName(principalDetails.getUser().getUsername());

		if (userJwt == null) {
			userJwt = new UserJwt();
			userJwt.setIssDate(new Date());
		}

		userJwt.setUserName(principalDetails.getUser().getUsername());
		userJwt.setAccJwt(acsJwt);
		userJwt.setAccJwtExp(acsTime);
		userJwt.setRefJwt(refJwt);
		userJwt.setRefJwtExp(refTime);
		userJwt.setRefDate(new Date());

		userJwtRepository.save(userJwt);

		// 2차 인증 처리 
		String authType = userCacheService.getAuthType(principalDetails.getUser().getUsername());

		if (authType != null) {

			if ("SMS".equals(authType)) {

				StringBuffer sbuffer = new StringBuffer(String.valueOf(System.currentTimeMillis()));
				String authCode = sbuffer.reverse().toString().substring(0, 3) + (Math.round(Math.random() * 1000));
				String phoneNo = principalDetails.getUser().getPhoneNumber().replaceAll("-", "");

				if (logger.isDebugEnabled()) {
					logger.debug("SMS " + smsSender + " " + phoneNo + " " + String.format(JwtProperties.SMS_STRING, authCode));
				}
				
				wisecanService.insertSMS(smsSender, phoneNo, String.format(JwtProperties.SMS_STRING, authCode));

				userCacheService.setSMSCode(acsJwt, authCode);

				if (logger.isDebugEnabled()) {
					logger.debug("SMS " + smsSender + " " + phoneNo + " " + String.format(JwtProperties.SMS_STRING, authCode));
				}

			}
			else if ("FIDO".equals(authType)) {

				try {

					HttpHeaders headers = new HttpHeaders();
					// 오토에버 가이드문서에는 application/json 으로 되어 있으나 지정하면 오류가 발생함.
					headers.add("Content-Type", "application/xxx");

					JSONObject jsonObject = new JSONObject();
					jsonObject.put("site", principalDetails.getUser().getInstituteId2());
					
					// H19900SWPSTL1 = instituteId1 + userId = H19900 + SWPSTL1
					jsonObject.put("userId",principalDetails.getUser().getInstituteId1() + principalDetails.getUser().getUsername());
					// jsonObject.put("deviceId", "........."); / Optional
					jsonObject.put("returnurl", authService.getMpassFidoReturnUrl());
					jsonObject.put("fid", refJwt); // acsJwt);

					if (logger.isDebugEnabled()) {
						logger.debug("FIDO Request Plain : " + jsonObject.toString());
						logger.debug("FIDO Request Encr : " + AES256Cipher.encode(jsonObject.toString()));
					}

					String resultAsJsonStr = restTemplate.postForObject(authService.getMpassFidoUrl(),
							AES256Cipher.encode(jsonObject.toString()), String.class);

					/*
					 * { "SITE" : "H199_W", "USERID" : "H19900SWPSTL1", "STATUS": "1200", : 정상 1500:
					 * 임시 사용자 9025 : 등록되지 않은 사용자. "DEVICEID": "355500076545938" }
					 */

					if (logger.isDebugEnabled()) {
						logger.debug("FIDO Result : " + AES256Cipher.decode(resultAsJsonStr));
					}

					FidoVo fidoVo = om.readValue(AES256Cipher.decode(resultAsJsonStr).trim().toLowerCase(Locale.KOREA),
							FidoVo.class);

					if (logger.isDebugEnabled()) {
						logger.debug("FIDO Result : " + fidoVo.getStatus());
					}					
				
					if (!Const.FIDO_1200.equals(fidoVo.getStatus())) {

						String message = null;
						if (Const.FIDO_1500.equals(fidoVo.getStatus())) {
							message = "임시번호 사용자 입니다. 부가인증 OTP를 선택 후 발급된 임시 번호를 사용하여 로그인 부탁드립니다";
						}

						else if (Const.FIDO_9025.equals(fidoVo.getStatus())) {
							message = "등록되지 않은 FIDO 사용자입니다.";
						}

						loginResult.put(Const.RESULT, Const.FAIL);
						loginResult.put(Const.CODE, fidoVo.getStatus());
						loginResult.put(Const.MESSAGE, message);

						writer.print(loginResult.toJSONString());
						writer.flush();
						if(writer != null) { writer.close(); }
						return;
					}

				} catch (Exception e) {

					if (logger.isDebugEnabled()) {
						logger.debug(e.getMessage());
					}

					loginResult.put(Const.RESULT, Const.PENDING);
					loginResult.put(Const.CODE, "");
					loginResult.put(Const.MESSAGE, "");
					loginResult.put(Const.DATA, joData);

					writer.print(loginResult.toJSONString());
					writer.flush();
					if(writer != null) { writer.close(); }
					return;
				}
			} else if ("OTP".equals(authType)) {

				try {

					String otpCode = userCacheService.getOtpCode(principalDetails.getUser().getUsername());

					HttpHeaders headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_JSON);

					JSONObject jsonObject = new JSONObject();
					jsonObject.put("site", principalDetails.getUser().getInstituteId2()); // H199_W
					jsonObject.put("userid", principalDetails.getUser().getUsername()); // "SWPSTL1");
					jsonObject.put("otp", otpCode);
					jsonObject.put("servicename", "SCP");
					jsonObject.put("ip", authService.getMpassFidoAuthMyIp());

					if (logger.isDebugEnabled()) {
						logger.debug("OTP Request Plain : " + jsonObject.toString());
						logger.debug("OTP Request Encr : " + AES256Cipher.encode(jsonObject.toString()));
					}

					String otpStr = restTemplate.postForObject(authService.getMpassOtpUrl(),
							AES256Cipher.encode(jsonObject.toString()), String.class);

					if (logger.isDebugEnabled()) {
						logger.debug("OTP Raw Result : " + otpStr.trim());
					}

					OtpVo fidoOtpVo = om.readValue(otpStr.trim(), OtpVo.class);

					if (logger.isDebugEnabled()) {
						logger.debug("OTP Result : " + fidoOtpVo.getResult() + " / " + fidoOtpVo.getMsg());
					}

					if (!Const.RAYCOM_TRUE.equals(fidoOtpVo.getResult())) {
						loginResult.put(Const.RESULT, Const.FAIL);
						loginResult.put(Const.CODE,  Const.OTP_9024);
						loginResult.put(Const.MESSAGE,
								fidoOtpVo.getMsg().indexOf("OTP") >= 0 ? fidoOtpVo.getMsg() : "등록되지 않은 OTP 사용자입니다");

						writer.print(loginResult.toJSONString());
						writer.flush();
						return;
					}

				} catch (Exception e) {

					if (logger.isDebugEnabled()) {
						logger.debug(e.getMessage());
					}

					loginResult.put(Const.RESULT, Const.FAIL);
					loginResult.put(Const.CODE, "");
					loginResult.put(Const.MESSAGE, "");
					loginResult.put(Const.DATA, joData);

					writer.print(loginResult.toJSONString());
					writer.flush();
					if(writer != null) { writer.close(); }
					return;
				}
			}
		}

		response.addHeader(JwtProperties.HEADER_STRING, JwtProperties.TOKEN_PREFIX + acsJwt);
		joData.put("acsJwt", acsJwt);
		joData.put("acsJwtExpired", acsTime.getTime());
		joData.put("refJwt", refJwt);
		joData.put("refJwtExpired", refTime.getTime());

		if ("FIDO".equals(authType)) {
			loginResult.put(Const.RESULT, Const.PENDING);
			loginResult.put(Const.MESSAGE, "FIDO 인증 요청함.");
			loginResult.put(Const.DATA, joData);
		} else {
			loginResult.put(Const.RESULT, Const.SUCCESS);
			loginResult.put(Const.MESSAGE, "로그인 성공");
			loginResult.put(Const.DATA, joData);
		}

		writer.print(loginResult.toJSONString());
		writer.flush();
		writer.close();
	}
}
