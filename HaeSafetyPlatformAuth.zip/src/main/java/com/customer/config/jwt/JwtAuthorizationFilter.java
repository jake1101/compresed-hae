package com.customer.config.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.customer.config.auth.PrincipalDetails;
import com.customer.entity.UserEntity;
import com.customer.repository.UserRepository;



/**
 * JwtAuthorizationFilter 
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UseShortArrayInitializer",
	"PMD.UseUtilityClass"
})
public class JwtAuthorizationFilter extends BasicAuthenticationFilter{
	
	/**  사용자 정보 조회용 */
	private UserRepository userRepository;
	
	/**
	 * JwtAuthorizationFilter 필터 생성자 
	 * 
	 * @author : david
	 * @param AuthenticationManager, UserRepository
	 * @Date : 2022. 02. 24
	 * @Method Name : loadUserByUsername
	 */
	public JwtAuthorizationFilter(final AuthenticationManager authenticationManager, final UserRepository userRepository) {
		super(authenticationManager);
		this.userRepository = userRepository;
	}
	
	@Override
	protected void doFilterInternal (final HttpServletRequest request, final HttpServletResponse response, final FilterChain chain)
			throws IOException, ServletException {

		String header = request.getHeader(JwtProperties.HEADER_STRING);
		if(header == null || !header.startsWith(JwtProperties.TOKEN_PREFIX)) {
			chain.doFilter(request, response);
                        return;
		}

		String token = request.getHeader(JwtProperties.HEADER_STRING).replace(JwtProperties.TOKEN_PREFIX, "");
		
		DecodedJWT decodedJwt = JWT.require(Algorithm.HMAC512(JwtProperties.SECRET)).build().verify(token);
		
		String username = decodedJwt.getClaim("username").asString();
		Long userId = decodedJwt.getClaim("id").asLong();
		
		if(username != null) {	
			UserEntity user = userRepository.findById(userId).get();
			
			PrincipalDetails principalDetails = new PrincipalDetails(user);
			Authentication authentication =
					new UsernamePasswordAuthenticationToken(
							principalDetails,
							null, 
							principalDetails.getAuthorities());
			
			SecurityContextHolder.getContext().setAuthentication(authentication);
		}
	
		chain.doFilter(request, response);
	}
	
}
