package com.customer.config.auth;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.customer.entity.UserEntity;

/**
 * PrincipalDetails 
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UseShortArrayInitializer",
	"PMD.UseUtilityClass"
})

public class PrincipalDetails implements UserDetails{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5639318214668819089L;
	/**
	 * 사용자 정보
	 */
	private transient UserEntity user;

	/**
	 * PrincipalDetails 생성자
	 * 
	 * @author : david
	 * @param UserEntity
	 * @Date : 2022. 02. 24
	 * @Method Name : configureViewResolvers
	 */
    public PrincipalDetails(final UserEntity user){
        this.user = user;
    }

	/**
	 * User 반환
	 * 
	 * @author : david
	 * @param void
	 * @return User
	 * @Date : 2022. 02. 24
	 * @Method Name : getUser
	 */
    public UserEntity getUser() {
		return user;
	}
    
	/**
	 * Password 반환
	 * 
	 * @author : david
	 * @param void
	 * @return String
	 * @Date : 2022. 02. 24
	 * @Method Name : getPassword
	 */
    @Override
    public String getPassword() {
        return user.getPassword();
    }
    
 	/**
 	 * Username 반환
 	 * 
 	 * @author : david
 	 * @param void
 	 * @return String
 	 * @Date : 2022. 02. 24
 	 * @Method Name : getUsername
 	 */
    @Override
    public String getUsername() {
        return user.getUsername();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
    
	@Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
		final Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        user.getRoleList().forEach(r -> {
        	authorities.add(()->{ return r;});
        });
        return authorities;
    }
}
