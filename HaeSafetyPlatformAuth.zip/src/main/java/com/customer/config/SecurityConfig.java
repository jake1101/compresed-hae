package com.customer.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;

import com.customer.config.jwt.JwtAuthentication2Filter;
import com.customer.config.jwt.JwtAuthenticationFilter;
import com.customer.config.jwt.JwtAuthorizationFilter;
import com.customer.repository.UserJwtRepository;
import com.customer.repository.UserLogRepository;
import com.customer.repository.UserRepository;
import com.customer.service.AuthService;
import com.customer.service.UserCacheService;
import com.customer.service.WisecanService;

/**
 * SpringSecurity 클래스
 * 
 * @author : david
 * @param 
 * @return void
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.AvoidCatchingGenericException",
	"PMD.AvoidDuplicateLiterals",
	"PMD.AvoidUncheckedExceptionsInSignatures",
	"PMD.BeanMembersShouldSerialize",
	"PMD.CommentDefaultAccessModifier",
	"PMD.CommentRequired",
	"PMD.CommentSize",
	"PMD.DataflowAnomalyAnalysis",
	"PMD.DefaultPackage",
	"PMD.ExcessiveImports",
	"PMD.ExcessiveMethodLength",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.LocalVariableCouldBeFinal",
	"PMD.LongVariable",
	"PMD.ModifiedCyclomaticComplexity",
	"PMD.NcssCount",
	"PMD.NonThreadSafeSingleton",
	"PMD.NPathComplexity",
	"PMD.OnlyOneReturn",
	"PMD.ReturnEmptyArrayRatherThanNull",
	"PMD.ReturnEmptyCollectionRatherThanNull",
	"PMD.ShortVariable",
	"PMD.SignatureDeclareThrowsException",
	"PMD.UnnecessaryLocalBeforeReturn",
	"PMD.UnusedAssignment",
	"PMD.UnusedPrivateField",
	"PMD.UnusedPrivateMethod",
	"PMD.UseDiamondOperator",
	"PMD.UseShortArrayInitializer",
	"PMD.UseUtilityClass"
})

@Configuration
@EnableWebSecurity 
public class SecurityConfig extends WebSecurityConfigurerAdapter{	
	
	/** SMS 발신자 번호 */
	@Value("${auth.sms-sender}")
	private transient String smsSender;
	
	/** 사용자 관리 레파지토리 */
	@Autowired
	private transient UserRepository userRepository;

	/** 로그 관리 레파지토리 */
	@Autowired
	private transient UserLogRepository userLogRepository;

	/** 사용자 JWT 관리 레파지토리 */
	@Autowired
	private transient UserJwtRepository userJwtRepository;
	
	/**  Cors 설정 */
	@Autowired
	private transient CorsConfig corsConfig;

	/** 사용자 인증 서비스 */
	@Autowired
	private transient AuthService authService;
	
	/** Wisecan SMS 저장 서비스 */
	@Autowired
	private transient WisecanService wisecanService;
	
	/** 사용자 정보 임시 저장 서비스 */
	@Autowired
	private transient UserCacheService userCacheService;
	
	/**
	 * SpringSecurity 설정을 초기화한다.
	 * 
	 * @author : david
	 * @param HttpSecurity
	 * @param 
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : configure
	 */
	@Override
	protected void configure(final HttpSecurity http) throws Exception {
		http.addFilter(corsConfig.corsFilter())
			.csrf().disable()
			.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
			.and()
			.formLogin().disable()
			.httpBasic().disable()
			
			.addFilter(new JwtAuthenticationFilter(authenticationManager(), userLogRepository, userJwtRepository, authService, userCacheService))
			.addFilter(new JwtAuthentication2Filter(authenticationManager(), userLogRepository, userJwtRepository, authService, wisecanService, userCacheService, smsSender))
			.addFilter(new JwtAuthorizationFilter(authenticationManager(), userRepository))
			.authorizeRequests()
			.anyRequest().permitAll()
			;
			
	}
}






