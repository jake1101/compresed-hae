package com.customer.util;

import org.springframework.stereotype.Service;

import com.customer.dto.NotifyDto;

/**
 *  DTO 생성 헬퍼 클래스
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */

@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.CommentSize",
//	"PMD.DataflowAnomalyAnalysis",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.ShortVariable",
	"PMD.UncommentedEmptyConstructor",
	"PMD.UnnecessaryConstructor"
})
@Service
public class DtoBuilder {

	/**
	 * 이메일 전파 요청 응답 DTO 생성
	 * 
	 * @author : david
	 * @param final String result, final String message
	 * @return NotifyDto
	 * @Date : 2022. 02. 24
	 * @Method Name : buildReissueDto
	 */
	public NotifyDto buildReissueDto(final String result, final String message) {
		
		final NotifyDto dto = new NotifyDto();
		dto.setResult(result);
		dto.setMessage(message);
		
		return dto;
	}
}
