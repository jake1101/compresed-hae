package com.customer.controller;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.customer.dto.NotifyDto;
import com.customer.util.DtoBuilder;
import com.customer.vo.RequestEmailVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 이메일 대리 발송 요청 컨트롤러
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.CommentSize",
//	"PMD.DataflowAnomalyAnalysis",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.ShortVariable",
	"PMD.UncommentedEmptyConstructor",
	"PMD.UnnecessaryConstructor"
})
@RestController
@RequestMapping("notify")
@Api(tags = { "이메일 발송 API" })
public class NotifyController {

	/** SMTP 주소 */
	@Value("${notify.mail.host}")
	private transient String smtpHost;

	/** SMTP 포트 */
	@Value("${notify.mail.port}")
	private transient int smtpPort;

	/** SMTP 인증여부 */
	@Value("${notify.mail.smtp.auth}")
	private transient boolean requireSmtpAuth;

	/** 발신자 이메일 주소 */
	@Value("${notify.mail.from}")
	private transient String fromAddress;

	/** 발신자 SMTP 계정 */
	@Value("${notify.mail.account}")
	private transient String smtpAccount;
	
	/** 발신자 SMTP 비밀번호 */
	@Value("${notify.mail.password}")
	private transient String smtpPassword;

	/** DTO 헬퍼 클래스 */
	@Autowired
	private transient DtoBuilder dtoBuilder;

	private void sendMessage(final String title, final String content, final String tos) throws AddressException, MessagingException {

		final Properties prop = new Properties();
		prop.put("mail.smtp.host", smtpHost);
		prop.put("mail.smtp.port", smtpPort);
		prop.put("mail.smtp.auth", requireSmtpAuth);

		prop.put("mail.transport.protocols", "smtp");
		prop.put("mail.debug", "true");

		final Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpAccount, smtpPassword);
			}
		});

		final MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(fromAddress));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(tos));
		message.setSubject(title);
		message.setContent(content, "text/html; charset=utf-8");
		message.saveChanges();

		Transport.send(message);
	}


	/**
	 * 이메일 발송 요청 API
	 * 
	 * @author : david
	 * @param RequestEmailVo
	 * @return NotifyDto
	 * @Date : 2022. 02. 24
	 * @Method Name : configureViewResolvers
	 */
	@PostMapping("reqEmail")
	@ApiOperation(value = "이메일 발송 요청", response = NotifyDto.class)
	public NotifyDto reqEmail(
			// @RequestHeader(value="Authorization") String authorization,
			@RequestBody final RequestEmailVo emailVo) {

		String result = "Email sent.";
		String resultCode = "0000";

		try {
			sendMessage(emailVo.getTitle(), emailVo.getContent(), emailVo.getTos());
		} catch (MessagingException e) {
			result = e.getMessage();
			resultCode = "0003";
		}

		return dtoBuilder.buildReissueDto(resultCode, result);
	}
}
