package com.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * 어플리케이션 Main
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.CommentSize",
//	"PMD.DataflowAnomalyAnalysis",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.ShortVariable",
	"PMD.UncommentedEmptyConstructor",
	"PMD.UnnecessaryConstructor"
})
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
@EnableScheduling
public class HaeSafetyPlatformNotifyApplication {

	/**
	 * HaeSafetyPlatformNotifyApplication Getter
	 * 
	 * @author : david
	 * @Date : 2022. 02. 24
	 * @Method Name : passwordEncoder
	 */
	public HaeSafetyPlatformNotifyApplication() {
		
	}
	/**
	 * BCryptPasswordEncoder Getter
	 * 
	 * @author : david
	 * @param 
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : passwordEncoder
	 */
	@Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
	
	/**
	 * Application Main
	 * 
	 * @author : david
	 * @param String[] args
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : passwordEncoder
	 */
	public static void main(final String[] args) {
		SpringApplication.run(HaeSafetyPlatformNotifyApplication.class, args);
	}
}


