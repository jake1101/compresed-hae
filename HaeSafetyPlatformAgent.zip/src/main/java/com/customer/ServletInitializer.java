package com.customer;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;


/**
 * ServletInitializer
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.CommentSize",
//	"PMD.DataflowAnomalyAnalysis",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.ShortVariable",
	"PMD.UncommentedEmptyConstructor",
	"PMD.UnnecessaryConstructor"
})
public class ServletInitializer extends SpringBootServletInitializer {

	/**
	 * ServletInitializer 
	 * 
	 * @author : david
	 * @Date : 2022. 02. 24
	 * @Method Name : configure
	 */
	public ServletInitializer() {
		super();
	}
	/**
	 * ServletInitializer configure
	 * 
	 * @author : david
	 * @param 
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : configure
	 */
	@Override
	protected SpringApplicationBuilder configure(final SpringApplicationBuilder application) {
		return application.sources(HaeSafetyPlatformNotifyApplication.class);
	}
}
