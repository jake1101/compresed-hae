package com.customer.config;

import org.springframework.boot.web.servlet.view.MustacheViewResolver;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * WebMvcConfig 초기화
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.CommentSize",
//	"PMD.DataflowAnomalyAnalysis",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.ShortVariable",
	"PMD.UncommentedEmptyConstructor",
	"PMD.UnnecessaryConstructor"
})
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

	/**
	 * 디폴트 resolver  설정
	 * 
	 * @author : david
	 * @param
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : configureViewResolvers
	 */
	@Override
	public void configureViewResolvers(final ViewResolverRegistry registry) {
		final MustacheViewResolver resolver = new MustacheViewResolver();

		resolver.setCharset("UTF-8");
		resolver.setContentType("text/html;charset=UTF-8");
		resolver.setPrefix("classpath:/templates/");
		resolver.setSuffix(".html");

		registry.viewResolver(resolver);
	}
}
