package com.customer.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * SwaggerConfig
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.CommentSize",
//	"PMD.DataflowAnomalyAnalysis",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.ShortVariable",
	"PMD.UncommentedEmptyConstructor",
	"PMD.UnnecessaryConstructor"
})
@Configuration
@EnableWebMvc
public class SwaggerConfig extends WebMvcConfigurationSupport {

	/**
	 * Swagger 문서 생성 
	 * 
	 * @author : david
	 * @param 
	 * @return Docket
	 * @Date : 2022. 02. 24
	 * @Method Name : restAPI
	 */
	@Bean
	public Docket restAPI() {
		return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select()
				.apis(RequestHandlerSelectors.basePackage("com.customer"))
//                .paths(PathSelectors.any())
				.paths(PathSelectors.ant("/api/v1/**")) // /v1/api/** 인 URL들만 필터링
				.build();
	}

	/**
	 * Swagger 문서 정보 반환
	 * 
	 * @author : david
	 * @param 
	 * @return ApiInfo
	 * @Date : 2022. 02. 24
	 * @Method Name : apiInfo
	 */
	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("HAE 안전관제 플랫폼 인증서버 API").version("0.0.1").description("HAE 안전관제 플랫폼 인증서버 API")
				.build();
	}

	/**
	 * Swagger 문서로 생성할 소스 위치 설정
	 * 
	 * @author : david
	 * @param 
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : addResourceHandlers
	 */
	@Override
	protected void addResourceHandlers(final ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

}