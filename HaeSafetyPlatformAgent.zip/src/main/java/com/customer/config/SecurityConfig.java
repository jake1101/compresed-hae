package com.customer.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;

/**
 * SpringSecurity 클래스
 * 
 * @author : david
 * @return void
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.CommentSize",
//	"PMD.DataflowAnomalyAnalysis",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.ShortVariable",
	"PMD.UncommentedEmptyConstructor",
	"PMD.UnnecessaryConstructor"
})
@Configuration
@EnableWebSecurity 
public class SecurityConfig extends WebSecurityConfigurerAdapter {	
		
	/** CorsConfig */
	@Autowired
	private transient CorsConfig corsConfig;

	/**
	 * SpringSecurity 생성자
	 * 
	 * @author : david
	 * @param 
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : configure
	 */
	public SecurityConfig() {
		super();
	}

	/**
	 * SpringSecurity 생성자
	 * 
	 * @author : david
	 * @param disableDefaults
	 * @param 
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : configure
	 */
	public SecurityConfig(final boolean disableDefaults) {
		super(disableDefaults);
	}

	/**
	 * SpringSecurity 설정을 초기화한다.
	 * 
	 * @author : david
	 * @param HttpSecurity
	 * @param 
	 * @return void
	 * @Date : 2022. 02. 24
	 * @Method Name : configure
	 */
	@Override
	protected void configure(final HttpSecurity http) throws Exception {
		
		http.addFilter(corsConfig.corsFilter())
			.csrf().disable()
			.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
			.and()
			.formLogin().disable()
			.httpBasic().disable()
			.authorizeRequests()
			.anyRequest().permitAll()
			;
	}
}






