package com.customer.vo;

import lombok.Data;

/**
 *  이메일 상황전파 요청 VO
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.CommentSize",
//	"PMD.DataflowAnomalyAnalysis",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.ShortVariable",
	"PMD.UncommentedEmptyConstructor",
	"PMD.UnnecessaryConstructor"
})
@Data
public class RequestEmailVo {
	
	/** 내부 식별자    */
	private Integer id;	
	
	/** 수신자 (컴마로 구분하여 다수 지정)   */
	private String tos;
	
	/** 전파 제목 (이메일에만 사용됨)   */
	private String title;
	
	/** 전파 내용   */
	private String content;
	
}
