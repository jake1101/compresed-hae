package com.customer.dto;

import lombok.Data;

/**
 *  공통 DTO
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class BaseDto {
	/** 결과 코드 */
    private String result;
    
    /** 결과 메시지 */
    private String message;
}
