package com.customer.dto;

import lombok.Data;

/**
 *  이메일 발송 요청 결과
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@Data
public class NotifyDto extends BaseDto {

}

