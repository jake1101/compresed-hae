package com.customer.entity;

import javax.persistence.*;

//import com.customer.type.MediaTypeConverter;

import lombok.Data;

/**
 *  상황전파 요청 Entity
 * 
 * @author : david
 * @Date : 2022. 02. 24
 */
@SuppressWarnings({
	"PMD.AtLeastOneConstructor",
	"PMD.CommentSize",
//	"PMD.DataflowAnomalyAnalysis",
	"PMD.ImmutableField",
	"PMD.LawOfDemeter",
	"PMD.ShortVariable",
	"PMD.UncommentedEmptyConstructor",
	"PMD.UnnecessaryConstructor"
})
@Entity
@Data
@Table(name="ntf_hst")
public class NotifyHost {

	/** 상황전파 식별자   */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="id", length = 10)
    private Long id;

	/** 요청 서버의 아이피 주소  */
    @Column(name="svr_ip", length = 32)
    private String svrIp;

	/** 전송매체 종류  */
    @Column(name="med_tp_cd", length = 8)
    private String medTpCd;

	/** 제목  */
    @Column(name="title", length = 256)
    private String title;

	/** 내용   */
    @Column(name="ctt", length = 1024)
    private String ctt;

	/** 수신자  */
    @Column(name="dst", length = 128)
    private String dst;

	/** 전송범위  */
    @Column(name="ntf_scp_cd", length = 128)
    private String ntfScpCd;

	/** 성공여부  */
    @Column(name="scs_yn", length = 8)
    private String scsYn;

	/** 해당서버 응답메시지  */
    @Column(name="res_msg", length = 1024)
    private String resMsg;

	/** 처리 프로세스 식별자  */
    @Column(name="prc_id", length = 16)
    private String prcId;

	/** 재시도 횟수   */
    @Column(name="prc_rtr_cnt", columnDefinition = "integer default 0")
    private Integer prcRtrCnt;

	/** 내부 처리용 임시 필드  */
    @Column(name="prc_tmp", length = 64)
    private String prcTmp;
}
